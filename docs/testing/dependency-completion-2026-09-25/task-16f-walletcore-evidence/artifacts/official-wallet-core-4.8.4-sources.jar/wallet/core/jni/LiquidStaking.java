// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * THORChain swap functions
*/
public final class LiquidStaking {
    private byte[] bytes;

    private LiquidStaking() {
    }

    static LiquidStaking createFromNative(byte[] bytes) {
        LiquidStaking instance = new LiquidStaking();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Builds a LiquidStaking transaction input.
     *
     * @param input The serialized data of LiquidStakingInput.
     * @return The serialized data of LiquidStakingOutput.
*/
    public static native byte[] buildRequest(byte[] input);
}
