// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents a Nervos address.
*/
public final class NervosAddress {
    private long nativeHandle;

    private NervosAddress() {
        nativeHandle = 0;
    }

    static NervosAddress createFromNative(long nativeHandle) {
        NervosAddress instance = new NervosAddress();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, NervosAddress::nativeDelete);
        return instance;
    }
    /**
 * Initializes an address from a sring representaion.
     *
     * @param string Bech32 string to initialize the address from.
     * @return TWNervosAddress pointer or nullptr if string is invalid.
*/
    static native long nativeCreateWithString(String string);
    static native void nativeDelete(long handle);
    /**
 * Compares two addresses for equality.
     *
     * @param lhs The first address to compare.
     * @param rhs The second address to compare.
     * @return bool indicating the addresses are equal.
*/
    public static native boolean equals(NervosAddress lhs, NervosAddress rhs);
    /**
 * Determines if the string is a valid Nervos address.
     *
     * @param string string to validate.
     * @return bool indicating if the address is valid.
*/
    public static native boolean isValidString(String string);
    /**
 * Returns the address string representation.
     *
     * @param address Address to get the string representation of.
*/
    public native String description();
    /**
 * Returns the Code hash
     *
     * @param address Address to get the keyhash data of.
*/
    public native byte[] codeHash();
    /**
 * Returns the address hash type
     *
     * @param address Address to get the hash type of.
*/
    public native String hashType();
    /**
 * Returns the address args data.
     *
     * @param address Address to get the args data of.
*/
    public native byte[] args();
    /**
 * Initializes an address from a sring representaion.
     *
     * @param string Bech32 string to initialize the address from.
     * @return TWNervosAddress pointer or nullptr if string is invalid.
*/
    public NervosAddress(String string) {
        nativeHandle = nativeCreateWithString(string);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, NervosAddress::nativeDelete);
    }

}
