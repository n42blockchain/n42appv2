// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Stellar address version byte.
*/
public enum StellarVersionByte {
    ACCOUNTID ((short) 0x30),
    SEED ((short) 0xc0),
    PREAUTHTX ((short) 0xc8),
    SHA256HASH ((short) 0x118);

    private final short value;
    StellarVersionByte(short value) {
        this.value = value;
    }
    public short value() { return value; }

    public static StellarVersionByte createFromValue(short value) {
        switch (value) {
            case (short) 0x30: return StellarVersionByte.ACCOUNTID;
            case (short) 0xc0: return StellarVersionByte.SEED;
            case (short) 0xc8: return StellarVersionByte.PREAUTHTX;
            case (short) 0x118: return StellarVersionByte.SHA256HASH;
            default: return null;
        }
    }

}
