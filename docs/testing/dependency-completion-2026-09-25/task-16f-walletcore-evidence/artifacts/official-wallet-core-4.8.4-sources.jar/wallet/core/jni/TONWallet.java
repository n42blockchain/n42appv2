// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class TONWallet {
    private long nativeHandle;

    private TONWallet() {
        nativeHandle = 0;
    }

    static TONWallet createFromNative(long nativeHandle) {
        TONWallet instance = new TONWallet();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Constructs a TON Wallet V4R2 stateInit encoded as BoC (BagOfCells) for the given `public_key`.
     * 
     * @param public_key wallet's public key.
     * @param workchain TON workchain to which the wallet belongs. Usually, base chain is used (0).
     * @param wallet_id wallet's ID allows to create multiple wallets for the same private key.
     * @return Pointer to a base64 encoded Bag Of Cells (BoC) StateInit. Null if invalid public key provided.
*/
    public static native String buildV4R2StateInit(PublicKey publicKey, int workchain, int walletId);
    /**
 * 
     * @param public_key wallet's public key.
     * @param workchain TON workchain to which the wallet belongs. Usually, base chain is used (0).
     * @param wallet_id wallet's ID allows to create multiple wallets for the same private key.
     * @return Pointer to a base64 encoded Bag Of Cells (BoC) StateInit. Null if invalid public key provided.
*/
    public static native String buildV5R1StateInit(PublicKey publicKey, int workchain, int walletId);
}
