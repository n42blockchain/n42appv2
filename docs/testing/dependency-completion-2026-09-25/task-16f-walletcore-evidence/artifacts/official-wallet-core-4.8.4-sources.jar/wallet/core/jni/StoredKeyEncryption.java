// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Preset encryption kind
*/
public enum StoredKeyEncryption {
    AES128CTR (0),
    AES192CTR (2),
    AES256CTR (3);

    private final int value;
    StoredKeyEncryption(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static StoredKeyEncryption createFromValue(int value) {
        switch (value) {
            case 0: return StoredKeyEncryption.AES128CTR;
            case 2: return StoredKeyEncryption.AES192CTR;
            case 3: return StoredKeyEncryption.AES256CTR;
            default: return null;
        }
    }

}
