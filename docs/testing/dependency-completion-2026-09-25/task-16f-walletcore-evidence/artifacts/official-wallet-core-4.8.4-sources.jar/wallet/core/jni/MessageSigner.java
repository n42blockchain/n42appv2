// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class MessageSigner {
    private long nativeHandle;

    private MessageSigner() {
        nativeHandle = 0;
    }

    static MessageSigner createFromNative(long nativeHandle) {
        MessageSigner instance = new MessageSigner();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Signs an arbitrary message to prove ownership of an address for off-chain services.
     * 
     * @param coin The given coin type to sign the message for.
     * @param input The serialized data of a signing input (e.g. TW.Ethereum.Proto.MessageSigningInput).
     * @return The serialized data of a `SigningOutput` proto object. (e.g. TW.Ethereum.Proto.MessageSigningOutput).
*/
    public static native byte[] sign(CoinType coin, byte[] input);
    /**
 * Verifies a signature for a message.
     * 
     * @param coin The given coin type to sign the message for.
     * @param input The serialized data of a verifying input (e.g. TW.Ethereum.Proto.MessageVerifyingInput).
     * @return whether the signature is valid.
*/
    public static native boolean verify(CoinType coin, byte[] input);
    /**
 * Computes preimage hashes of a message.
     * 
     * @param coin The given coin type to sign the message for.
     * @param input The serialized data of a signing input (e.g. TW.Ethereum.Proto.MessageSigningInput).
     * @return The serialized data of TW.TxCompiler.PreSigningOutput.
*/
    public static native byte[] preImageHashes(CoinType coin, byte[] input);
}
