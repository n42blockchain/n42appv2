// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class TONAddressConverter {
    private long nativeHandle;

    private TONAddressConverter() {
        nativeHandle = 0;
    }

    static TONAddressConverter createFromNative(long nativeHandle) {
        TONAddressConverter instance = new TONAddressConverter();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Converts a TON user address into a Bag of Cells (BoC) with a single root Cell.
     * The function is mostly used to request a Jetton user address via `get_wallet_address` RPC.
     * https://docs.ton.org/develop/dapps/asset-processing/jettons#retrieving-jetton-wallet-addresses-for-a-given-user
     * 
     * @param address Address to be converted into a Bag Of Cells (BoC).
     * @return Pointer to a base64 encoded Bag Of Cells (BoC). Null if invalid address provided.
*/
    public static native String toBoc(String address);
    /**
 * Parses a TON address from a Bag of Cells (BoC) with a single root Cell.
     * The function is mostly used to parse a Jetton user address received on `get_wallet_address` RPC.
     * https://docs.ton.org/develop/dapps/asset-processing/jettons#retrieving-jetton-wallet-addresses-for-a-given-user
     * 
     * @param boc Base64 encoded Bag Of Cells (BoC).
     * @return Pointer to a Jetton address.
*/
    public static native String fromBoc(String boc);
    /**
 * Converts any TON address format to user friendly with the given parameters.
     * 
     * @param address raw or user-friendly address to be converted.
     * @param bounceable whether the result address should be bounceable.
     * @param testnet whether the result address should be testnet.
     * @return user-friendly address str.
*/
    public static native String toUserFriendly(String address, boolean bounceable, boolean testnet);
}
