// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;


public final class TransactionUtil {
    private byte[] bytes;

    private TransactionUtil() {
    }

    static TransactionUtil createFromNative(byte[] bytes) {
        TransactionUtil instance = new TransactionUtil();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Calculate the TX hash of a transaction.
     *
     * @param coin coin type.
     * @param encodedTx encoded transaction data.
     * @return The TX hash of a transaction, If the input is invalid or the chain is unsupported, null is returned.
*/
    public static native String calcTxHash(CoinType coinType, String encodedTx);
}
