// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents a private key.
*/
public final class PrivateKey {
    private long nativeHandle;

    static PrivateKey createFromNative(long nativeHandle) {
        PrivateKey instance = new PrivateKey();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, PrivateKey::nativeDelete);
        return instance;
    }
    /**
 * Create a random private key
     *
     * @note Should be deleted with \TWPrivateKeyDelete
     * @return Non-null Private key
*/
    static native long nativeCreate();
    /**
 * Create a private key with the given block of data
     *
     * @param data a block of data
     * @note Should be deleted with \TWPrivateKeyDelete
     * @return Nullable pointer to Private Key
*/
    static native long nativeCreateWithData(byte[] data);
    /**
 * Deep copy a given private key
     *
     * @param key Non-null private key to be copied
     * @note Should be deleted with \TWPrivateKeyDelete
     * @return Deep copy, Nullable pointer to Private key
*/
    static native long nativeCreateCopy(PrivateKey key);
    static native void nativeDelete(long handle);
    /**
 * Determines if the given private key is valid or not.
     *
     * @param data block of data (private key bytes)
     * @param curve Eliptic curve of the private key
     * @return true if the private key is valid, false otherwise
*/
    public static native boolean isValid(byte[] data, Curve curve);
    /**
 * Convert the given private key to raw-bytes block of data
     *
     * @param pk Non-null pointer to the private key
     * @return Non-null block of data (raw bytes) of the given private key
*/
    public native byte[] data();
    /**
 * Returns the public key associated with the given coinType and privateKey
     *
     * @param pk Non-null pointer to the private key
     * @param coinType coinType of the given private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKey(CoinType coinType);
    /**
 * Returns the public key associated with the given pubkeyType and privateKey
     *
     * @param pk Non-null pointer to the private key
     * @param pubkeyType pubkeyType of the given private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeyByType(PublicKeyType pubkeyType);
    /**
 * Returns the Secp256k1 public key associated with the given private key
     *
     * @param pk Non-null pointer to the private key
     * @param compressed if the given private key is compressed or not
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeySecp256k1(boolean compressed);
    /**
 * Returns the Nist256p1 public key associated with the given private key
     *
     * @param pk Non-null pointer to the private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeyNist256p1();
    /**
 * Returns the Ed25519 public key associated with the given private key
     *
     * @param pk Non-null pointer to the private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeyEd25519();
    /**
 * Returns the Ed25519Blake2b public key associated with the given private key
     *
     * @param pk Non-null pointer to the private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeyEd25519Blake2b();
    /**
 * Returns the Ed25519Cardano public key associated with the given private key
     *
     * @param pk Non-null pointer to the private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeyEd25519Cardano();
    /**
 * Returns the Curve25519 public key associated with the given private key
     *
     * @param pk Non-null pointer to the private key
     * @return Non-null pointer to the corresponding public key
*/
    public native PublicKey getPublicKeyCurve25519();
    /**
 * Signs a digest using ECDSA and given curve.
     *
     * @param pk  Non-null pointer to a Private key
     * @param digest Non-null digest block of data
     * @param curve Eliptic curve
     * @return Signature as a Non-null block of data
*/
    public native byte[] sign(byte[] digest, Curve curve);
    /**
 * Signs a digest using ECDSA. The result is encoded with DER.
     *
     * @param pk  Non-null pointer to a Private key
     * @param digest Non-null digest block of data
     * @return Signature as a Non-null block of data
*/
    public native byte[] signAsDER(byte[] digest);
    /**
 * Signs a digest using ECDSA and Zilliqa schnorr signature scheme.
     *
     * @param pk Non-null pointer to a Private key
     * @param message Non-null message
     * @return Signature as a Non-null block of data
*/
    public native byte[] signZilliqaSchnorr(byte[] message);
    /**
 * Create a random private key
     *
     * @note Should be deleted with \TWPrivateKeyDelete
     * @return Non-null Private key
*/
    public PrivateKey() {
        nativeHandle = nativeCreate();
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, PrivateKey::nativeDelete);
    }

    /**
 * Create a private key with the given block of data
     *
     * @param data a block of data
     * @note Should be deleted with \TWPrivateKeyDelete
     * @return Nullable pointer to Private Key
*/
    public PrivateKey(byte[] data) {
        nativeHandle = nativeCreateWithData(data);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, PrivateKey::nativeDelete);
    }

    /**
 * Deep copy a given private key
     *
     * @param key Non-null private key to be copied
     * @note Should be deleted with \TWPrivateKeyDelete
     * @return Deep copy, Nullable pointer to Private key
*/
    public PrivateKey(PrivateKey key) {
        nativeHandle = nativeCreateCopy(key);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, PrivateKey::nativeDelete);
    }

}
