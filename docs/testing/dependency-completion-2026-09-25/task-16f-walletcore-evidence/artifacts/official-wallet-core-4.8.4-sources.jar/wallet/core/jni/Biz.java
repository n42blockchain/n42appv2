// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class Biz {
    private long nativeHandle;

    private Biz() {
        nativeHandle = 0;
    }

    static Biz createFromNative(long nativeHandle) {
        Biz instance = new Biz();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Returns the encoded hash of the user operation
     * 
     * @param chain_id The chain ID of the user.
     * @param code_address The address of the smart contract wallet.
     * @param code_name The name of the smart contract wallet.
     * @param code_version The version of the smart contract wallet.
     * @param type_hash The type hash of the smart contract wallet.
     * @param domain_separator_hash The domain separator hash of the smart contract wallet.
     * @param sender The sender of the smart contract wallet.
     * @param user_op_hash The user operation hash of the smart contract wallet.
     * @return The encoded hash.
*/
    public static native byte[] getEncodedHash(byte[] chainId, String codeAddress, String codeName, String codeVersion, String typeHash, String domainSeparatorHash, String sender, String userOpHash);
    /**
 * Signs a message using the private key
     * 
     * @param hash The hash of the user.
     * @param private_key The private key of the user.
     * @return The signed hash.
*/
    public static native byte[] getSignedHash(String hash, String privateKey);
    /**
 * Signs and encodes `Biz.executeWithPasskeySession` function call to execute a batch of transactions.
     * 
     * @param input The serialized data of `Biz.ExecuteWithSignatureInput` protobuf message.
     * @return ABI-encoded function call.
*/
    public static native byte[] signExecuteWithSignatureCall(byte[] input);
}
