// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents an Account in C++ with address, coin type and public key info, an item within a keystore.
*/
public final class Account {
    private long nativeHandle;

    private Account() {
        nativeHandle = 0;
    }

    static Account createFromNative(long nativeHandle) {
        Account instance = new Account();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, Account::nativeDelete);
        return instance;
    }
    /**
 * Creates a new Account with an address, a coin type, derivation enum, derivationPath, publicKey,
     * and extendedPublicKey. Must be deleted with TWAccountDelete after use.
     *
     * @param address The address of the Account.
     * @param coin The coin type of the Account.
     * @param derivation The derivation of the Account.
     * @param derivationPath The derivation path of the Account.
     * @param publicKey hex encoded public key.
     * @param extendedPublicKey Base58 encoded extended public key.
     * @return A new Account, or null if the derivation path is invalid.
*/
    static native long nativeCreate(String address, CoinType coin, Derivation derivation, String derivationPath, String publicKey, String extendedPublicKey);
    static native void nativeDelete(long handle);
    /**
 * Returns the address of an account.
     *
     * @param account Account to get the address of.
*/
    public native String address();
    /**
 * Return CoinType enum of an account.
     *
     * @param account Account to get the coin type of.
*/
    public native CoinType coin();
    /**
 * Returns the derivation enum of an account.
     *
     * @param account Account to get the derivation enum of.
*/
    public native Derivation derivation();
    /**
 * Returns derivationPath of an account.
     *
     * @param account Account to get the derivation path of.
*/
    public native String derivationPath();
    /**
 * Returns hex encoded publicKey of an account.
     *
     * @param account Account to get the public key of.
*/
    public native String publicKey();
    /**
 * Returns Base58 encoded extendedPublicKey of an account.
     *
     * @param account Account to get the extended public key of.
*/
    public native String extendedPublicKey();
    /**
 * Creates a new Account with an address, a coin type, derivation enum, derivationPath, publicKey,
     * and extendedPublicKey. Must be deleted with TWAccountDelete after use.
     *
     * @param address The address of the Account.
     * @param coin The coin type of the Account.
     * @param derivation The derivation of the Account.
     * @param derivationPath The derivation path of the Account.
     * @param publicKey hex encoded public key.
     * @param extendedPublicKey Base58 encoded extended public key.
     * @return A new Account, or null if the derivation path is invalid.
*/
    public Account(String address, CoinType coin, Derivation derivation, String derivationPath, String publicKey, String extendedPublicKey) {
        nativeHandle = nativeCreate(address, coin, derivation, derivationPath, publicKey, extendedPublicKey);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, Account::nativeDelete);
    }

}
