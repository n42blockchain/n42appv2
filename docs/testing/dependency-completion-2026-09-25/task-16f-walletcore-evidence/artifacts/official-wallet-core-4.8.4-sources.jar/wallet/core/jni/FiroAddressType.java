// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Firo address type.
*/
public enum FiroAddressType {
    DEFAULT (0),
    EXCHANGE (1);

    private final int value;
    FiroAddressType(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static FiroAddressType createFromValue(int value) {
        switch (value) {
            case 0: return FiroAddressType.DEFAULT;
            case 1: return FiroAddressType.EXCHANGE;
            default: return null;
        }
    }

}
