// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Bitcoin message signing and verification.
 *
 * Bitcoin Core and some other wallets support a message signing & verification format, to create a proof (a signature)
 * that someone has access to the private keys of a specific address.
 * This feature currently works on old legacy addresses only.
*/
public final class BitcoinMessageSigner {
    private byte[] bytes;

    private BitcoinMessageSigner() {
    }

    static BitcoinMessageSigner createFromNative(byte[] bytes) {
        BitcoinMessageSigner instance = new BitcoinMessageSigner();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Sign a message.
     *
     * @param privateKey: the private key used for signing
     * @param address: the address that matches the privateKey, must be a legacy address (P2PKH)
     * @param message: A custom message which is input to the signing.
     * @note Address is derived assuming compressed public key format.
     * @returns the signature, Base64-encoded.  On invalid input empty string is returned. Returned object needs to be deleteed after use.
*/
    public static native String signMessage(PrivateKey privateKey, String address, String message);
    /**
 * Verify signature for a message.
     *
     * @param address: address to use, only legacy is supported
     * @param message: the message signed (without prefix)
     * @param signature: in Base64-encoded form.
     * @returns false on any invalid input (does not throw).
*/
    public static native boolean verifyMessage(String address, String message, String signature);
}
