// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Ethereum message signing and verification.
 *
 * Ethereum and some other wallets support a message signing & verification format, to create a proof (a signature)
 * that someone has access to the private keys of a specific address.
*/
public final class EthereumMessageSigner {
    private byte[] bytes;

    private EthereumMessageSigner() {
    }

    static EthereumMessageSigner createFromNative(byte[] bytes) {
        EthereumMessageSigner instance = new EthereumMessageSigner();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Sign a typed message EIP-712 V4.
     *
     * @param privateKey: the private key used for signing
     * @param messageJson: A custom typed data message in json
     * @returns the signature, Hex-encoded. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String signTypedMessage(PrivateKey privateKey, String messageJson);
    /**
 * Sign a typed message EIP-712 V4 with EIP-155 replay attack protection.
     *
     * @param privateKey: the private key used for signing
     * @param messageJson: A custom typed data message in json
     * @param chainId: chainId for eip-155 protection
     * @returns the signature, Hex-encoded. On invalid input empty string is returned or invalid chainId error message. Returned object needs to be deleted after use.
*/
    public static native String signTypedMessageEip155(PrivateKey privateKey, String messageJson, int chainId);
    /**
 * Sign a message.
     *
     * @param privateKey: the private key used for signing
     * @param message: A custom message which is input to the signing.
     * @returns the signature, Hex-encoded. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String signMessage(PrivateKey privateKey, String message);
    /**
 * Sign a message with Immutable X msg type.
     *
     * @param privateKey: the private key used for signing
     * @param message: A custom message which is input to the signing.
     * @returns the signature, Hex-encoded. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String signMessageImmutableX(PrivateKey privateKey, String message);
    /**
 * Sign a message with Eip-155 msg type.
     *
     * @param privateKey: the private key used for signing
     * @param message: A custom message which is input to the signing.
     * @param chainId: chainId for eip-155 protection
     * @returns the signature, Hex-encoded. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String signMessageEip155(PrivateKey privateKey, String message, int chainId);
    /**
 * Verify signature for a message.
     *
     * @param pubKey: pubKey that will verify and recover the message from the signature
     * @param message: the message signed (without prefix)
     * @param signature: in Hex-encoded form.
     * @returns false on any invalid input (does not throw), true if the message can be recovered from the signature
*/
    public static native boolean verifyMessage(PublicKey pubKey, String message, String signature);
}
