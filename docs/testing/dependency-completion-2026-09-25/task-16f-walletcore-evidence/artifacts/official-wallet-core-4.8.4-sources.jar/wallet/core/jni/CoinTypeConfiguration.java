// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * CoinTypeConfiguration functions
*/
public final class CoinTypeConfiguration {
    private byte[] bytes;

    private CoinTypeConfiguration() {
    }

    static CoinTypeConfiguration createFromNative(byte[] bytes) {
        CoinTypeConfiguration instance = new CoinTypeConfiguration();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Returns stock symbol of coin
     *
     * @param type A coin type
     * @return A non-null TWString stock symbol of coin
     * @note Caller must free returned object
*/
    public static native String getSymbol(CoinType type);
    /**
 * Returns max count decimal places for minimal coin unit
     *
     * @param type A coin type
     * @return Returns max count decimal places for minimal coin unit
*/
    public static native int getDecimals(CoinType type);
    /**
 * Returns transaction url in blockchain explorer
     *
     * @param type A coin type
     * @param transactionID A transaction identifier
     * @return Returns a non-null TWString transaction url in blockchain explorer
*/
    public static native String getTransactionURL(CoinType type, String transactionID);
    /**
 * Returns account url in blockchain explorer
     *
     * @param type A coin type
     * @param accountID an Account identifier
     * @return Returns a non-null TWString account url in blockchain explorer
*/
    public static native String getAccountURL(CoinType type, String accountID);
    /**
 * Returns full name of coin in lower case
     *
     * @param type A coin type
     * @return Returns a non-null TWString, full name of coin in lower case
*/
    public static native String getID(CoinType type);
    /**
 * Returns full name of coin
     *
     * @param type A coin type
     * @return Returns a non-null TWString, full name of coin
*/
    public static native String getName(CoinType type);
    /**
 * Returns native token name of coin
     *
     * @param type A coin type
     * @return Returns a non-null TWString, native token name of coin
*/
    public static native String getNativeTokenName(CoinType type);
}
