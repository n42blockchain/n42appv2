// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Represents a private key. * Represents a public key. * Coin type for Level 2 of BIP44.
 *
 * @see https://github.com/satoshilabs/slips/blob/master/slip-0044.md
*/
public enum CoinType {
    AETERNITY (457),
    AION (425),
    BINANCE (714),
    BITCOIN (0),
    BITCOINCASH (145),
    BITCOINGOLD (156),
    CALLISTO (820),
    CARDANO (1815),
    COSMOS (118),
    PIVX (119),
    DASH (5),
    DECRED (42),
    DIGIBYTE (20),
    DOGECOIN (3),
    EOS (194),
    WAX (14001),
    ETHEREUM (60),
    ETHEREUMCLASSIC (61),
    FIO (235),
    GOCHAIN (6060),
    GROESTLCOIN (17),
    ICON (74),
    IOTEX (304),
    KAVA (459),
    KIN (2017),
    LITECOIN (2),
    MONACOIN (22),
    NEBULAS (2718),
    NULS (8964),
    NANO (165),
    NEAR (397),
    NIMIQ (242),
    ONTOLOGY (1024),
    POANETWORK (178),
    QTUM (2301),
    XRP (144),
    SOLANA (501),
    STELLAR (148),
    TEZOS (1729),
    THETA (500),
    THUNDERCORE (1001),
    NEO (888),
    VICTION (889),
    TRON (195),
    VECHAIN (818),
    VIACOIN (14),
    WANCHAIN (5718350),
    ZCASH (133),
    FIRO (136),
    ZILLIQA (313),
    ZELCASH (19167),
    RAVENCOIN (175),
    WAVES (5741564),
    TERRA (330),
    TERRAV2 (10000330),
    HARMONY (1023),
    ALGORAND (283),
    KUSAMA (434),
    POLKADOT (354),
    FILECOIN (461),
    MULTIVERSX (508),
    BANDCHAIN (494),
    SMARTCHAINLEGACY (10000714),
    SMARTCHAIN (20000714),
    TBINANCE (30000714),
    OASIS (474),
    POLYGON (966),
    THORCHAIN (931),
    BLUZELLE (483),
    OPTIMISM (10000070),
    ZKSYNC (10000324),
    ARBITRUM (10042221),
    ECOCHAIN (10000553),
    AVALANCHECCHAIN (10009000),
    XDAI (10000100),
    FANTOM (10000250),
    CRYPTOORG (394),
    CELO (52752),
    RONIN (10002020),
    OSMOSIS (10000118),
    ECASH (899),
    IOST (291),
    CRONOSCHAIN (10000025),
    SMARTBITCOINCASH (10000145),
    KUCOINCOMMUNITYCHAIN (10000321),
    BITCOINDIAMOND (999),
    BOBA (10000288),
    SYSCOIN (57),
    VERGE (77),
    ZEN (121),
    METIS (10001088),
    AURORA (1323161554),
    EVMOS (10009001),
    NATIVEEVMOS (20009001),
    MOONRIVER (10001285),
    MOONBEAM (10001284),
    KAVAEVM (10002222),
    KAIA (10008217),
    METER (18000),
    OKXCHAIN (996),
    STRATIS (105105),
    KOMODO (141),
    NERVOS (309),
    EVERSCALE (396),
    APTOS (637),
    NEBL (146),
    HEDERA (3030),
    SECRET (529),
    NATIVEINJECTIVE (10000060),
    AGORIC (564),
    TON (607),
    SUI (784),
    STARGAZE (20000118),
    POLYGONZKEVM (10001101),
    JUNO (30000118),
    STRIDE (40000118),
    AXELAR (50000118),
    CRESCENT (60000118),
    KUJIRA (70000118),
    IOTEXEVM (10004689),
    NATIVECANTO (10007700),
    COMDEX (80000118),
    NEUTRON (90000118),
    SOMMELIER (11000118),
    FETCHAI (12000118),
    MARS (13000118),
    UMEE (14000118),
    COREUM (10000990),
    QUASAR (15000118),
    PERSISTENCE (16000118),
    AKASH (17000118),
    NOBLE (18000118),
    SCROLL (534352),
    ROOTSTOCK (137),
    THETAFUEL (361),
    CONFLUXESPACE (1030),
    ACALA (787),
    ACALAEVM (10000787),
    OPBNB (204),
    NEON (245022934),
    BASE (8453),
    SEI (19000118),
    ARBITRUMNOVA (10042170),
    LINEA (59144),
    GREENFIELD (5600),
    MANTLE (5000),
    ZENEON (7332),
    INTERNETCOMPUTER (223),
    TIA (21000118),
    MANTAPACIFIC (169),
    NATIVEZETACHAIN (10007000),
    ZETAEVM (20007000),
    DYDX (22000118),
    MERLIN (4200),
    LIGHTLINK (1890),
    BLAST (81457),
    BOUNCEBIT (6001),
    ZKLINKNOVA (810180),
    PACTUS (21888),
    SONIC (10000146),
    POLYMESH (595),
    PLASMA (9745),
    MONAD (10143),
    MEGAETH (4326),
    SEIEVM (1329),
    HYPEREVM (10000999),
    ROBINHOODCHAIN (10004663),
    ARC (10005042);

    private final int value;
    CoinType(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static CoinType createFromValue(int value) {
        switch (value) {
            case 457: return CoinType.AETERNITY;
            case 425: return CoinType.AION;
            case 714: return CoinType.BINANCE;
            case 0: return CoinType.BITCOIN;
            case 145: return CoinType.BITCOINCASH;
            case 156: return CoinType.BITCOINGOLD;
            case 820: return CoinType.CALLISTO;
            case 1815: return CoinType.CARDANO;
            case 118: return CoinType.COSMOS;
            case 119: return CoinType.PIVX;
            case 5: return CoinType.DASH;
            case 42: return CoinType.DECRED;
            case 20: return CoinType.DIGIBYTE;
            case 3: return CoinType.DOGECOIN;
            case 194: return CoinType.EOS;
            case 14001: return CoinType.WAX;
            case 60: return CoinType.ETHEREUM;
            case 61: return CoinType.ETHEREUMCLASSIC;
            case 235: return CoinType.FIO;
            case 6060: return CoinType.GOCHAIN;
            case 17: return CoinType.GROESTLCOIN;
            case 74: return CoinType.ICON;
            case 304: return CoinType.IOTEX;
            case 459: return CoinType.KAVA;
            case 2017: return CoinType.KIN;
            case 2: return CoinType.LITECOIN;
            case 22: return CoinType.MONACOIN;
            case 2718: return CoinType.NEBULAS;
            case 8964: return CoinType.NULS;
            case 165: return CoinType.NANO;
            case 397: return CoinType.NEAR;
            case 242: return CoinType.NIMIQ;
            case 1024: return CoinType.ONTOLOGY;
            case 178: return CoinType.POANETWORK;
            case 2301: return CoinType.QTUM;
            case 144: return CoinType.XRP;
            case 501: return CoinType.SOLANA;
            case 148: return CoinType.STELLAR;
            case 1729: return CoinType.TEZOS;
            case 500: return CoinType.THETA;
            case 1001: return CoinType.THUNDERCORE;
            case 888: return CoinType.NEO;
            case 889: return CoinType.VICTION;
            case 195: return CoinType.TRON;
            case 818: return CoinType.VECHAIN;
            case 14: return CoinType.VIACOIN;
            case 5718350: return CoinType.WANCHAIN;
            case 133: return CoinType.ZCASH;
            case 136: return CoinType.FIRO;
            case 313: return CoinType.ZILLIQA;
            case 19167: return CoinType.ZELCASH;
            case 175: return CoinType.RAVENCOIN;
            case 5741564: return CoinType.WAVES;
            case 330: return CoinType.TERRA;
            case 10000330: return CoinType.TERRAV2;
            case 1023: return CoinType.HARMONY;
            case 283: return CoinType.ALGORAND;
            case 434: return CoinType.KUSAMA;
            case 354: return CoinType.POLKADOT;
            case 461: return CoinType.FILECOIN;
            case 508: return CoinType.MULTIVERSX;
            case 494: return CoinType.BANDCHAIN;
            case 10000714: return CoinType.SMARTCHAINLEGACY;
            case 20000714: return CoinType.SMARTCHAIN;
            case 30000714: return CoinType.TBINANCE;
            case 474: return CoinType.OASIS;
            case 966: return CoinType.POLYGON;
            case 931: return CoinType.THORCHAIN;
            case 483: return CoinType.BLUZELLE;
            case 10000070: return CoinType.OPTIMISM;
            case 10000324: return CoinType.ZKSYNC;
            case 10042221: return CoinType.ARBITRUM;
            case 10000553: return CoinType.ECOCHAIN;
            case 10009000: return CoinType.AVALANCHECCHAIN;
            case 10000100: return CoinType.XDAI;
            case 10000250: return CoinType.FANTOM;
            case 394: return CoinType.CRYPTOORG;
            case 52752: return CoinType.CELO;
            case 10002020: return CoinType.RONIN;
            case 10000118: return CoinType.OSMOSIS;
            case 899: return CoinType.ECASH;
            case 291: return CoinType.IOST;
            case 10000025: return CoinType.CRONOSCHAIN;
            case 10000145: return CoinType.SMARTBITCOINCASH;
            case 10000321: return CoinType.KUCOINCOMMUNITYCHAIN;
            case 999: return CoinType.BITCOINDIAMOND;
            case 10000288: return CoinType.BOBA;
            case 57: return CoinType.SYSCOIN;
            case 77: return CoinType.VERGE;
            case 121: return CoinType.ZEN;
            case 10001088: return CoinType.METIS;
            case 1323161554: return CoinType.AURORA;
            case 10009001: return CoinType.EVMOS;
            case 20009001: return CoinType.NATIVEEVMOS;
            case 10001285: return CoinType.MOONRIVER;
            case 10001284: return CoinType.MOONBEAM;
            case 10002222: return CoinType.KAVAEVM;
            case 10008217: return CoinType.KAIA;
            case 18000: return CoinType.METER;
            case 996: return CoinType.OKXCHAIN;
            case 105105: return CoinType.STRATIS;
            case 141: return CoinType.KOMODO;
            case 309: return CoinType.NERVOS;
            case 396: return CoinType.EVERSCALE;
            case 637: return CoinType.APTOS;
            case 146: return CoinType.NEBL;
            case 3030: return CoinType.HEDERA;
            case 529: return CoinType.SECRET;
            case 10000060: return CoinType.NATIVEINJECTIVE;
            case 564: return CoinType.AGORIC;
            case 607: return CoinType.TON;
            case 784: return CoinType.SUI;
            case 20000118: return CoinType.STARGAZE;
            case 10001101: return CoinType.POLYGONZKEVM;
            case 30000118: return CoinType.JUNO;
            case 40000118: return CoinType.STRIDE;
            case 50000118: return CoinType.AXELAR;
            case 60000118: return CoinType.CRESCENT;
            case 70000118: return CoinType.KUJIRA;
            case 10004689: return CoinType.IOTEXEVM;
            case 10007700: return CoinType.NATIVECANTO;
            case 80000118: return CoinType.COMDEX;
            case 90000118: return CoinType.NEUTRON;
            case 11000118: return CoinType.SOMMELIER;
            case 12000118: return CoinType.FETCHAI;
            case 13000118: return CoinType.MARS;
            case 14000118: return CoinType.UMEE;
            case 10000990: return CoinType.COREUM;
            case 15000118: return CoinType.QUASAR;
            case 16000118: return CoinType.PERSISTENCE;
            case 17000118: return CoinType.AKASH;
            case 18000118: return CoinType.NOBLE;
            case 534352: return CoinType.SCROLL;
            case 137: return CoinType.ROOTSTOCK;
            case 361: return CoinType.THETAFUEL;
            case 1030: return CoinType.CONFLUXESPACE;
            case 787: return CoinType.ACALA;
            case 10000787: return CoinType.ACALAEVM;
            case 204: return CoinType.OPBNB;
            case 245022934: return CoinType.NEON;
            case 8453: return CoinType.BASE;
            case 19000118: return CoinType.SEI;
            case 10042170: return CoinType.ARBITRUMNOVA;
            case 59144: return CoinType.LINEA;
            case 5600: return CoinType.GREENFIELD;
            case 5000: return CoinType.MANTLE;
            case 7332: return CoinType.ZENEON;
            case 223: return CoinType.INTERNETCOMPUTER;
            case 21000118: return CoinType.TIA;
            case 169: return CoinType.MANTAPACIFIC;
            case 10007000: return CoinType.NATIVEZETACHAIN;
            case 20007000: return CoinType.ZETAEVM;
            case 22000118: return CoinType.DYDX;
            case 4200: return CoinType.MERLIN;
            case 1890: return CoinType.LIGHTLINK;
            case 81457: return CoinType.BLAST;
            case 6001: return CoinType.BOUNCEBIT;
            case 810180: return CoinType.ZKLINKNOVA;
            case 21888: return CoinType.PACTUS;
            case 10000146: return CoinType.SONIC;
            case 595: return CoinType.POLYMESH;
            case 9745: return CoinType.PLASMA;
            case 10143: return CoinType.MONAD;
            case 4326: return CoinType.MEGAETH;
            case 1329: return CoinType.SEIEVM;
            case 10000999: return CoinType.HYPEREVM;
            case 10004663: return CoinType.ROBINHOODCHAIN;
            case 10005042: return CoinType.ARC;
            default: return null;
        }
    }

    public native Blockchain blockchain();
    public native Purpose purpose();
    public native Curve curve();
    public native HDVersion xpubVersion();
    public native HDVersion xprvVersion();
    public native HRP hrp();
    public native byte p2pkhPrefix();
    public native byte p2shPrefix();
    public native byte staticPrefix();
    public native String chainId();
    public native int slip44Id();
    public native int ss58Prefix();
    public native PublicKeyType publicKeyType();
    public native boolean validate(String address);
    public native String derivationPath();
    public native String derivationPathWithDerivation(Derivation derivation);
    public native String deriveAddress(PrivateKey privateKey);
    public native String deriveAddressFromPublicKey(PublicKey publicKey);
    public native String deriveAddressFromPublicKeyAndDerivation(PublicKey publicKey, Derivation derivation);
}
