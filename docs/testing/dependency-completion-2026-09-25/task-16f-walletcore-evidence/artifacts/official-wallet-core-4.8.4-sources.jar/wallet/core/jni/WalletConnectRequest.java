// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class WalletConnectRequest {
    private long nativeHandle;

    private WalletConnectRequest() {
        nativeHandle = 0;
    }

    static WalletConnectRequest createFromNative(long nativeHandle) {
        WalletConnectRequest instance = new WalletConnectRequest();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Parses the WalletConnect signing request as a `SigningInput`.
     * 
     * @param coin The given coin type to plan the transaction for.
     * @param input The serialized data of a `WalletConnect::Proto::ParseRequestInput` proto object.
     * @return The serialized data of `WalletConnect::Proto::ParseRequestOutput` proto object.
*/
    public static native byte[] parse(CoinType coin, byte[] input);
}
