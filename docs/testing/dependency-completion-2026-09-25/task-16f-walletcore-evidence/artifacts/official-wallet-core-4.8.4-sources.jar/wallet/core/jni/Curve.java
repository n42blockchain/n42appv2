// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Elliptic cruves
*/
public enum Curve {
    SECP256K1 (0),
    ED25519 (1),
    ED25519BLAKE2BNANO (2),
    CURVE25519 (3),
    NIST256P1 (4),
    ED25519EXTENDEDCARDANO (5),
    STARKEX (6);

    private final int value;
    Curve(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static Curve createFromValue(int value) {
        switch (value) {
            case 0: return Curve.SECP256K1;
            case 1: return Curve.ED25519;
            case 2: return Curve.ED25519BLAKE2BNANO;
            case 3: return Curve.CURVE25519;
            case 4: return Curve.NIST256P1;
            case 5: return Curve.ED25519EXTENDEDCARDANO;
            case 6: return Curve.STARKEX;
            default: return null;
        }
    }


    public String toString() {
        switch (this) {
        case SECP256K1: return "secp256k1";
        case ED25519: return "ed25519";
        case ED25519BLAKE2BNANO: return "ed25519-blake2b-nano";
        case CURVE25519: return "curve25519";
        case NIST256P1: return "nist256p1";
        case ED25519EXTENDEDCARDANO: return "ed25519-cardano-seed";
        case STARKEX: return "starkex";
        default: return "";
        }
    }
}
