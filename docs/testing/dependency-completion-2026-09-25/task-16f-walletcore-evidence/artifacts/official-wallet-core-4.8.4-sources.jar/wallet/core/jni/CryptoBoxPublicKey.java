// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class CryptoBoxPublicKey {
    private long nativeHandle;

    private CryptoBoxPublicKey() {
        nativeHandle = 0;
    }

    static CryptoBoxPublicKey createFromNative(long nativeHandle) {
        CryptoBoxPublicKey instance = new CryptoBoxPublicKey();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, CryptoBoxPublicKey::nativeDelete);
        return instance;
    }
    /**
 * Create a `crypto_box` public key with the given block of data.
     * 
     * @param data *non-null* byte array. Expected to have 32 bytes.
     * @note Should be deleted with \tw_crypto_box_public_key_delete.
     * @return Nullable pointer to Public Key.
*/
    static native long nativeCreateWithData(byte[] data);
    static native void nativeDelete(long handle);
    /**
 * Determines if the given public key is valid or not.
     * 
     * @param data *non-null* byte array.
     * @return true if the public key is valid, false otherwise.
*/
    public static native boolean isValid(byte[] data);
    /**
 * Returns the raw data of a given public-key.
     * 
     * @param public_key *non-null* pointer to a public key.
     * @return C-compatible result with a C-compatible byte array.
*/
    public native byte[] data();
    /**
 * Create a `crypto_box` public key with the given block of data.
     * 
     * @param data *non-null* byte array. Expected to have 32 bytes.
     * @note Should be deleted with \tw_crypto_box_public_key_delete.
     * @return Nullable pointer to Public Key.
*/
    public CryptoBoxPublicKey(byte[] data) {
        nativeHandle = nativeCreateWithData(data);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, CryptoBoxPublicKey::nativeDelete);
    }

}
