// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Chain identifiers for Ethereum-based blockchains, for convenience. Recommended to use the dynamic CoinType.ChainId() instead.
 * See also TWChainId.
*/
public enum EthereumChainID {
    ETHEREUM (1),
    CLASSIC (61),
    ROOTSTOCK (30),
    MANTA (169),
    POA (99),
    OPBNB (204),
    TFUELEVM (361),
    VECHAIN (74),
    CALLISTO (820),
    VICTION (88),
    POLYGON (137),
    OKC (66),
    THUNDERTOKEN (108),
    CFXEVM (1030),
    SEIEVM (1329),
    LIGHTLINK (1890),
    MERLIN (4200),
    MEGAETH (4326),
    MANTLE (5000),
    BOUNCEBIT (6001),
    GOCHAIN (60),
    ZENEON (7332),
    BASE (8453),
    PLASMA (9745),
    MONAD (143),
    METER (82),
    CELO (42220),
    LINEA (59144),
    BLAST (81457),
    SCROLL (534352),
    ZKLINKNOVA (810180),
    WANCHAIN (888),
    CRONOS (25),
    OPTIMISM (10),
    XDAI (100),
    SMARTBCH (10000),
    SONIC (146),
    FANTOM (250),
    BOBA (288),
    KCC (321),
    ZKSYNC (324),
    HECO (128),
    ACALAEVM (787),
    HYPEREVM (999),
    METIS (1088),
    POLYGONZKEVM (1101),
    MOONBEAM (1284),
    MOONRIVER (1285),
    RONIN (2020),
    KAVAEVM (2222),
    ROBINHOODCHAIN (4663),
    IOTEXEVM (4689),
    ARC (5042),
    KAIA (8217),
    AVALANCHEC (43114),
    EVMOS (9001),
    ARBITRUMNOVA (42170),
    ARBITRUM (42161),
    SMARTCHAIN (56),
    ZETAEVM (7000),
    NEON (245022934),
    AURORA (1313161554);

    private final int value;
    EthereumChainID(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static EthereumChainID createFromValue(int value) {
        switch (value) {
            case 1: return EthereumChainID.ETHEREUM;
            case 61: return EthereumChainID.CLASSIC;
            case 30: return EthereumChainID.ROOTSTOCK;
            case 169: return EthereumChainID.MANTA;
            case 99: return EthereumChainID.POA;
            case 204: return EthereumChainID.OPBNB;
            case 361: return EthereumChainID.TFUELEVM;
            case 74: return EthereumChainID.VECHAIN;
            case 820: return EthereumChainID.CALLISTO;
            case 88: return EthereumChainID.VICTION;
            case 137: return EthereumChainID.POLYGON;
            case 66: return EthereumChainID.OKC;
            case 108: return EthereumChainID.THUNDERTOKEN;
            case 1030: return EthereumChainID.CFXEVM;
            case 1329: return EthereumChainID.SEIEVM;
            case 1890: return EthereumChainID.LIGHTLINK;
            case 4200: return EthereumChainID.MERLIN;
            case 4326: return EthereumChainID.MEGAETH;
            case 5000: return EthereumChainID.MANTLE;
            case 6001: return EthereumChainID.BOUNCEBIT;
            case 60: return EthereumChainID.GOCHAIN;
            case 7332: return EthereumChainID.ZENEON;
            case 8453: return EthereumChainID.BASE;
            case 9745: return EthereumChainID.PLASMA;
            case 143: return EthereumChainID.MONAD;
            case 82: return EthereumChainID.METER;
            case 42220: return EthereumChainID.CELO;
            case 59144: return EthereumChainID.LINEA;
            case 81457: return EthereumChainID.BLAST;
            case 534352: return EthereumChainID.SCROLL;
            case 810180: return EthereumChainID.ZKLINKNOVA;
            case 888: return EthereumChainID.WANCHAIN;
            case 25: return EthereumChainID.CRONOS;
            case 10: return EthereumChainID.OPTIMISM;
            case 100: return EthereumChainID.XDAI;
            case 10000: return EthereumChainID.SMARTBCH;
            case 146: return EthereumChainID.SONIC;
            case 250: return EthereumChainID.FANTOM;
            case 288: return EthereumChainID.BOBA;
            case 321: return EthereumChainID.KCC;
            case 324: return EthereumChainID.ZKSYNC;
            case 128: return EthereumChainID.HECO;
            case 787: return EthereumChainID.ACALAEVM;
            case 999: return EthereumChainID.HYPEREVM;
            case 1088: return EthereumChainID.METIS;
            case 1101: return EthereumChainID.POLYGONZKEVM;
            case 1284: return EthereumChainID.MOONBEAM;
            case 1285: return EthereumChainID.MOONRIVER;
            case 2020: return EthereumChainID.RONIN;
            case 2222: return EthereumChainID.KAVAEVM;
            case 4663: return EthereumChainID.ROBINHOODCHAIN;
            case 4689: return EthereumChainID.IOTEXEVM;
            case 5042: return EthereumChainID.ARC;
            case 8217: return EthereumChainID.KAIA;
            case 43114: return EthereumChainID.AVALANCHEC;
            case 9001: return EthereumChainID.EVMOS;
            case 42170: return EthereumChainID.ARBITRUMNOVA;
            case 42161: return EthereumChainID.ARBITRUM;
            case 56: return EthereumChainID.SMARTCHAIN;
            case 7000: return EthereumChainID.ZETAEVM;
            case 245022934: return EthereumChainID.NEON;
            case 1313161554: return EthereumChainID.AURORA;
            default: return null;
        }
    }

}
