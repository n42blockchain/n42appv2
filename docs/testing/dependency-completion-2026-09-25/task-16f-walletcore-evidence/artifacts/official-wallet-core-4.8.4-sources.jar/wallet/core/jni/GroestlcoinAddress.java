// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents a legacy Groestlcoin address.
*/
public final class GroestlcoinAddress {
    private long nativeHandle;

    private GroestlcoinAddress() {
        nativeHandle = 0;
    }

    static GroestlcoinAddress createFromNative(long nativeHandle) {
        GroestlcoinAddress instance = new GroestlcoinAddress();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, GroestlcoinAddress::nativeDelete);
        return instance;
    }
    /**
 * Create an address from a base58 string representation.
     *
     * @param string Non-null string
     * @note Must be deleted with \TWGroestlcoinAddressDelete
     * @return Non-null GroestlcoinAddress
*/
    static native long nativeCreateWithString(String string);
    /**
 * Create an address from a public key and a prefix byte.
     *
     * @param publicKey Non-null public key
     * @param prefix public key prefix
     * @note Must be deleted with \TWGroestlcoinAddressDelete
     * @return Non-null GroestlcoinAddress
*/
    static native long nativeCreateWithPublicKey(PublicKey publicKey, byte prefix);
    static native void nativeDelete(long handle);
    /**
 * Compares two addresses for equality.
     *
     * @param lhs left Non-null GroestlCoin address to be compared
     * @param rhs right Non-null GroestlCoin address to be compared
     * @return true if both address are equal, false otherwise
*/
    public static native boolean equals(GroestlcoinAddress lhs, GroestlcoinAddress rhs);
    /**
 * Determines if the string is a valid Groestlcoin address.
     *
     * @param string Non-null string.
     * @return true if it's a valid address, false otherwise
*/
    public static native boolean isValidString(String string);
    /**
 * Returns the address base58 string representation.
     *
     * @param address Non-null GroestlcoinAddress
     * @return Address description as a non-null string
*/
    public native String description();
    /**
 * Create an address from a base58 string representation.
     *
     * @param string Non-null string
     * @note Must be deleted with \TWGroestlcoinAddressDelete
     * @return Non-null GroestlcoinAddress
*/
    public GroestlcoinAddress(String string) {
        nativeHandle = nativeCreateWithString(string);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, GroestlcoinAddress::nativeDelete);
    }

    /**
 * Create an address from a public key and a prefix byte.
     *
     * @param publicKey Non-null public key
     * @param prefix public key prefix
     * @note Must be deleted with \TWGroestlcoinAddressDelete
     * @return Non-null GroestlcoinAddress
*/
    public GroestlcoinAddress(PublicKey publicKey, byte prefix) {
        nativeHandle = nativeCreateWithPublicKey(publicKey, prefix);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, GroestlcoinAddress::nativeDelete);
    }

}
