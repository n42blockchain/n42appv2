// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class Eip7702 {
    private long nativeHandle;

    private Eip7702() {
        nativeHandle = 0;
    }

    static Eip7702 createFromNative(long nativeHandle) {
        Eip7702 instance = new Eip7702();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Signs an Authorization hash in [EIP-7702 format](https://eips.ethereum.org/EIPS/eip-7702)
     * 
     * @param chain_id The chain ID of the user.
     * @param contract_address The address of the smart contract wallet.
     * @param nonce The nonce of the user.
     * @param private_key The private key of the user.
     * @return The signed authorization.
*/
    public static native String signAuthorization(byte[] chainId, String contractAddress, byte[] nonce, String privateKey);
    /**
 * Computes an Authorization hash in [EIP-7702 format](https://eips.ethereum.org/EIPS/eip-7702)
     * `keccak256('0x05' || rlp([chain_id, address, nonce]))`.
     * 
     * @param chain_id The chain ID of the user.
     * @param contract_address The address of the smart contract wallet.
     * @param nonce The nonce of the user.
     * @return The authorization hash.
*/
    public static native byte[] getAuthorizationHash(byte[] chainId, String contractAddress, byte[] nonce);
}
