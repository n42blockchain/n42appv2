// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Tezos message signing, verification and utilities.
*/
public final class TezosMessageSigner {
    private byte[] bytes;

    private TezosMessageSigner() {
    }

    static TezosMessageSigner createFromNative(byte[] bytes) {
        TezosMessageSigner instance = new TezosMessageSigner();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Implement format input as described in https://tezostaquito.io/docs/signing/
     *
     * @param message message to format e.g: Hello, World
     * @param dAppUrl the app url, e.g: testUrl
     * @returns the formatted message as a string
*/
    public static native String formatMessage(String message, String url);
    /**
 * Implement input to payload as described in: https://tezostaquito.io/docs/signing/
     *
     * @param message formatted message to be turned into an hex payload
     * @return the hexpayload of the formated message as a hex string
*/
    public static native String inputToPayload(String message);
    /**
 * Sign a message as described in https://tezostaquito.io/docs/signing/
     *
     * @param privateKey: the private key used for signing
     * @param message: A custom message payload (hex) which is input to the signing.
     * @returns the signature, Hex-encoded. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String signMessage(PrivateKey privateKey, String message);
    /**
 * Verify signature for a message as described in https://tezostaquito.io/docs/signing/
     *
     * @param pubKey: pubKey that will verify the message from the signature
     * @param message: the message signed as a payload (hex)
     * @param signature: in Base58-encoded form.
     * @returns false on any invalid input (does not throw), true if the message can be verified from the signature
*/
    public static native boolean verifyMessage(PublicKey pubKey, String message, String signature);
}
