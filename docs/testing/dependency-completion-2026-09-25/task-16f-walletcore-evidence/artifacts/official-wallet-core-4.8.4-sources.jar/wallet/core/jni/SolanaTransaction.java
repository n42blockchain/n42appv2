// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class SolanaTransaction {
    private long nativeHandle;

    private SolanaTransaction() {
        nativeHandle = 0;
    }

    static SolanaTransaction createFromNative(long nativeHandle) {
        SolanaTransaction instance = new SolanaTransaction();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Decode Solana transaction, update the recent blockhash and re-sign the transaction.
     * 
     * # Warning
     * 
     * This is a temporary solution. It will be removed when `Solana.proto` supports
     * direct transaction signing.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * @param recent_blockhash base58 encoded recent blockhash.
     * @param private_keys list of private keys that should be used to re-sign the transaction.
     * @return serialized `Solana::Proto::SigningOutput`.
*/
    public static native byte[] updateBlockhashAndSign(String encodedTx, String recentBlockhash, DataVector privateKeys);
    /**
 * Try to find a `ComputeBudgetInstruction::SetComputeUnitPrice` instruction in the given transaction,
     * and returns the specified Unit Price.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * @return nullable Unit Price as a decimal string. Null if no instruction found.
*/
    public static native String getComputeUnitPrice(String encodedTx);
    /**
 * Try to find a `ComputeBudgetInstruction::SetComputeUnitLimit` instruction in the given transaction,
     * and returns the specified Unit Limit.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * @return nullable Unit Limit as a decimal string. Null if no instruction found.
*/
    public static native String getComputeUnitLimit(String encodedTx);
    /**
 * Adds or updates a `ComputeBudgetInstruction::SetComputeUnitPrice` instruction of the given transaction,
     * and returns the updated transaction.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * \price Unit Price as a decimal string.
     * @return base64 encoded Solana transaction. Null if an error occurred.
*/
    public static native String setComputeUnitPrice(String encodedTx, String price);
    /**
 * Adds or updates a `ComputeBudgetInstruction::SetComputeUnitLimit` instruction of the given transaction,
     * and returns the updated transaction.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * \limit Unit Limit as a decimal string.
     * @return base64 encoded Solana transaction. Null if an error occurred.
*/
    public static native String setComputeUnitLimit(String encodedTx, String limit);
    /**
 * Adds fee payer to the given transaction, and returns the updated transaction.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * @param fee_payer fee payer account address. Must be a base58 encoded public key. It must NOT be in the account list yet.
     * @return base64 encoded Solana transaction. Null if an error occurred.
*/
    public static native String setFeePayer(String encodedTx, String feePayer);
    /**
 * Inserts an instruction to the given transaction at the specified position, returning the updated transaction.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * @param insert_at index where the instruction should be inserted. If you don't care about the position, use -1.
     * @param instruction json encoded instruction. Here is an example: {"programId":"11111111111111111111111111111111","accounts":[{"pubkey":"YUz1AupPEy1vttBeDS7sXYZFhQJppcXMzjDiDx18Srf","isSigner":true,"isWritable":true},{"pubkey":"d8DiHEeHKdXkM2ZupT86mrvavhmJwUZjHPCzMiB5Lqb","isSigner":false,"isWritable":true}],"data":"3Bxs4Z6oyhaczjLK"}
     * @return base64 encoded Solana transaction. Null if an error occurred.
*/
    public static native String insertInstruction(String encodedTx, int insertAt, String instruction);
    /**
 * Inserts a SOL transfer instruction to the given transaction at the specified position, returning the updated transaction.
     * Please note that compute price and limit instructions should always be the first instructions if they are present in the transaction.
     * 
     * @param encoded_tx base64 encoded Solana transaction.
     * @param insert_at index where the instruction should be inserted. If you don't care about the position, use -1.
     * @param from sender account from which the lamports will be debited.
     * @param to receiver account to which the lamports will be transferred.
     * @param lamports amount of lamports to transfer, as a decimal string.
     * @return base64 encoded Solana transaction. Null if an error occurred.
*/
    public static native String insertTransferInstruction(String encodedTx, int insertAt, String from, String to, String lamports);
}
