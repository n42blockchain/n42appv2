// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Represents an ASN.1 DER parser.
*/
public final class AsnParser {
    private byte[] bytes;

    private AsnParser() {
    }

    static AsnParser createFromNative(byte[] bytes) {
        AsnParser instance = new AsnParser();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Parses the given ECDSA signature from ASN.1 DER encoded bytes.
     *
     * @param encoded The ASN.1 DER encoded signature.
     * @return The ECDSA signature standard binary representation: RS, where R - 32 byte array, S - 32 byte array.
*/
    public static native byte[] ecdsaSignatureFromDer(byte[] encoded);
}
