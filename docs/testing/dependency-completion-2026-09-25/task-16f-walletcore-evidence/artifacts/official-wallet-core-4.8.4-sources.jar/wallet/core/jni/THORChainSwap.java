// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * THORChain swap functions
*/
public final class THORChainSwap {
    private byte[] bytes;

    private THORChainSwap() {
    }

    static THORChainSwap createFromNative(byte[] bytes) {
        THORChainSwap instance = new THORChainSwap();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Builds a THORChainSwap transaction input.
     *
     * @param input The serialized data of SwapInput.
     * @return The serialized data of SwapOutput.
*/
    public static native byte[] buildSwap(byte[] input);
}
