// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * `crypto_box` encryption algorithms.
*/
public final class CryptoBox {
    private byte[] bytes;

    private CryptoBox() {
    }

    static CryptoBox createFromNative(byte[] bytes) {
        CryptoBox instance = new CryptoBox();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Encrypts message using `my_secret` and `other_pubkey`.
     * The output will have a randomly generated nonce prepended to it.
     * The output will be Overhead + 24 bytes longer than the original.
     *
     * @param mySecret *non-null* pointer to my secret key.
     * @param otherPubkey *non-null* pointer to other's public key.
     * @param message *non-null* pointer to the message to be encrypted.
     * @return *nullable* pointer to the encrypted message with randomly generated nonce prepended to it.
*/
    public static native byte[] encryptEasy(CryptoBoxSecretKey mySecret, CryptoBoxPublicKey otherPubkey, byte[] message);
    /**
 * Decrypts box produced by `TWCryptoBoxEncryptEasy`.
     * We assume a 24-byte nonce is prepended to the encrypted text in box.
     *
     * @param mySecret *non-null* pointer to my secret key.
     * @param otherPubkey *non-null* pointer to other's public key.
     * @param encrypted *non-null* pointer to the encrypted message with nonce prepended to it.
     * @return *nullable* pointer to the decrypted message.
*/
    public static native byte[] decryptEasy(CryptoBoxSecretKey mySecret, CryptoBoxPublicKey otherPubkey, byte[] encrypted);
}
