// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class CryptoBoxSecretKey {
    private long nativeHandle;

    static CryptoBoxSecretKey createFromNative(long nativeHandle) {
        CryptoBoxSecretKey instance = new CryptoBoxSecretKey();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, CryptoBoxSecretKey::nativeDelete);
        return instance;
    }
    /**
 * Create a random secret key.
     * 
     * @note Should be deleted with \tw_crypto_box_secret_key_delete.
     * @return Nullable pointer to Private Key.
*/
    static native long nativeCreate();
    /**
 * Create a `crypto_box` secret key with the given block of data.
     * 
     * @param data *non-null* byte array. Expected to have 32 bytes.
     * @note Should be deleted with \tw_crypto_box_secret_key_delete.
     * @return Nullable pointer to Secret Key.
*/
    static native long nativeCreateWithData(byte[] data);
    static native void nativeDelete(long handle);
    /**
 * Determines if the given secret key is valid or not.
     * 
     * @param data *non-null* byte array.
     * @return true if the secret key is valid, false otherwise.
*/
    public static native boolean isValid(byte[] data);
    /**
 * Returns the raw data of a given secret-key.
     * 
     * @param secret_key *non-null* pointer to a secret key.
     * @return C-compatible result with a C-compatible byte array.
*/
    public native byte[] data();
    /**
 * Returns the public key associated with the given `key`.
     * 
     * @param key *non-null* pointer to the private key.
     * @return *non-null* pointer to the corresponding public key.
*/
    public native CryptoBoxPublicKey getPublicKey();
    /**
 * Create a random secret key.
     * 
     * @note Should be deleted with \tw_crypto_box_secret_key_delete.
     * @return Nullable pointer to Private Key.
*/
    public CryptoBoxSecretKey() {
        nativeHandle = nativeCreate();
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, CryptoBoxSecretKey::nativeDelete);
    }

    /**
 * Create a `crypto_box` secret key with the given block of data.
     * 
     * @param data *non-null* byte array. Expected to have 32 bytes.
     * @note Should be deleted with \tw_crypto_box_secret_key_delete.
     * @return Nullable pointer to Secret Key.
*/
    public CryptoBoxSecretKey(byte[] data) {
        nativeHandle = nativeCreateWithData(data);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, CryptoBoxSecretKey::nativeDelete);
    }

}
