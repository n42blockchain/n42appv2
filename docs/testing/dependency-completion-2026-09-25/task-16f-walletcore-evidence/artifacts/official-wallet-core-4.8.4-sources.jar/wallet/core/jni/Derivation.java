// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Non-default coin address derivation names (default, unnamed derivations are not included).
 * Note the enum variant must be sync with `TWDerivation` enum in Rust:
 * https://github.com/trustwallet/wallet-core/blob/master/rust/tw_coin_registry/src/tw_derivation.rs
*/
public enum Derivation {
    DEFAULT (0),
    CUSTOM (1),
    BITCOINSEGWIT (2),
    BITCOINLEGACY (3),
    BITCOINTESTNET (4),
    LITECOINLEGACY (5),
    SOLANASOLANA (6),
    STRATISSEGWIT (7),
    BITCOINTAPROOT (8),
    PACTUSMAINNET (9),
    PACTUSTESTNET (10),
    SMARTCHAINSTABLEACCOUNT (11);

    private final int value;
    Derivation(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static Derivation createFromValue(int value) {
        switch (value) {
            case 0: return Derivation.DEFAULT;
            case 1: return Derivation.CUSTOM;
            case 2: return Derivation.BITCOINSEGWIT;
            case 3: return Derivation.BITCOINLEGACY;
            case 4: return Derivation.BITCOINTESTNET;
            case 5: return Derivation.LITECOINLEGACY;
            case 6: return Derivation.SOLANASOLANA;
            case 7: return Derivation.STRATISSEGWIT;
            case 8: return Derivation.BITCOINTAPROOT;
            case 9: return Derivation.PACTUSMAINNET;
            case 10: return Derivation.PACTUSTESTNET;
            case 11: return Derivation.SMARTCHAINSTABLEACCOUNT;
            default: return null;
        }
    }

}
