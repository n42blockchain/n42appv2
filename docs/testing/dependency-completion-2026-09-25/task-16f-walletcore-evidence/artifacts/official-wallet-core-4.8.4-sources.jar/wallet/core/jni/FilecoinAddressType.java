// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Filecoin address type.
*/
public enum FilecoinAddressType {
    DEFAULT (0),
    DELEGATED (1);

    private final int value;
    FilecoinAddressType(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static FilecoinAddressType createFromValue(int value) {
        switch (value) {
            case 0: return FilecoinAddressType.DEFAULT;
            case 1: return FilecoinAddressType.DELEGATED;
            default: return null;
        }
    }

}
