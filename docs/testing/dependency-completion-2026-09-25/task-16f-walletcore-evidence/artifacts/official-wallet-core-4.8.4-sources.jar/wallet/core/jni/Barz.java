// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class Barz {
    private long nativeHandle;

    private Barz() {
        nativeHandle = 0;
    }

    static Barz createFromNative(long nativeHandle) {
        Barz instance = new Barz();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Calculate a counterfactual address for the smart contract wallet
     * 
     * @param input The serialized data of ContractAddressInput.
     * @return The address.
*/
    public static native String getCounterfactualAddress(byte[] input);
    /**
 * Returns the init code parameter of ERC-4337 User Operation
     * 
     * @param factory The address of the factory contract
     * @param public_key Public key for the verification facet
     * @param verification_facet The address of the verification facet
     * @param salt The salt of the init code; Must be non-negative
     * @return The init code.
*/
    public static native byte[] getInitCode(String factory, PublicKey publicKey, String verificationFacet, int salt);
    /**
 * Converts the original ASN-encoded signature from webauthn to the format accepted by Barz
     * 
     * @param signature Original signature
     * @param challenge The original challenge that was signed
     * @param authenticator_data Returned from Webauthn API
     * @param client_data_json Returned from Webauthn API
     * @return Bytes of the formatted signature
*/
    public static native byte[] getFormattedSignature(byte[] signature, byte[] challenge, byte[] authenticatorData, String clientDataJson);
    /**
 * Returns the final hash to be signed by Barz for signing messages & typed data
     * 
     * @param msg_hash Original msgHash
     * @param barzAddress The address of Barz wallet signing the message
     * @param chainId The chainId of the network the verification will happen; Must be non-negative
     * @return The final hash to be signed.
*/
    public static native byte[] getPrefixedMsgHash(byte[] msgHash, String barzAddress, int chainId);
    /**
 * Returns the encoded diamondCut function call for Barz contract upgrades
     * 
     * @param input The serialized data of DiamondCutInput.
     * @return The diamond cut code.
*/
    public static native byte[] getDiamondCutCode(byte[] input);
}
