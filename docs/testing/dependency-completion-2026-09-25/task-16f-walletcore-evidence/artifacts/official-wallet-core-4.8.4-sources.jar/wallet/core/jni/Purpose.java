// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * HD wallet purpose
 *
 * @see https://github.com/bitcoin/bips/blob/master/bip-0044.mediawiki
 * @see https://github.com/bitcoin/bips/blob/master/bip-0049.mediawiki
 * @see https://github.com/bitcoin/bips/blob/master/bip-0084.mediawiki
*/
public enum Purpose {
    BIP44 (44),
    BIP49 (49),
    BIP84 (84),
    BIP86 (86),
    BIP1852 (1852);

    private final int value;
    Purpose(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static Purpose createFromValue(int value) {
        switch (value) {
            case 44: return Purpose.BIP44;
            case 49: return Purpose.BIP49;
            case 84: return Purpose.BIP84;
            case 86: return Purpose.BIP86;
            case 1852: return Purpose.BIP1852;
            default: return null;
        }
    }

}
