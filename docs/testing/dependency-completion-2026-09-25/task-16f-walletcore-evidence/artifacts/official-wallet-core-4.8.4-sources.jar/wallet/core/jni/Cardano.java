// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Cardano helper functions
*/
public final class Cardano {
    private byte[] bytes;

    private Cardano() {
    }

    static Cardano createFromNative(byte[] bytes) {
        Cardano instance = new Cardano();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Calculates the minimum ADA amount needed for a UTXO.
     *
     * \deprecated consider using `TWCardanoOutputMinAdaAmount` instead.
     * @see reference https://docs.cardano.org/native-tokens/minimum-ada-value-requirement
     * @param tokenBundle serialized data of TW.Cardano.Proto.TokenBundle.
     * @return the minimum ADA amount.
*/
    public static native long minAdaAmount(byte[] tokenBundle);
    /**
 * Calculates the minimum ADA amount needed for an output.
     *
     * @see reference https://docs.cardano.org/native-tokens/minimum-ada-value-requirement
     * @param toAddress valid destination address, as string.
     * @param tokenBundle serialized data of TW.Cardano.Proto.TokenBundle.
     * @param coinsPerUtxoByte cost per one byte of a serialized UTXO (Base-10 decimal string).
     * @return the minimum ADA amount (Base-10 decimal string).
*/
    public static native String outputMinAdaAmount(String toAddress, byte[] tokenBundle, String coinsPerUtxoByte);
    /**
 * Return the staking address associated to (contained in) this address. Must be a Base address.
     * Empty string is returned on error. Result must be freed.
     * @param baseAddress A valid base address, as string.
     * @return the associated staking (reward) address, as string, or empty string on error.
*/
    public static native String getStakingAddress(String baseAddress);
    /**
 * Return the legacy(byron) address.
     * @param publicKey A valid public key with TWPublicKeyTypeED25519Cardano type.
     * @return the legacy(byron) address, as string, or empty string on error.
*/
    public static native String getByronAddress(PublicKey publicKey);
}
