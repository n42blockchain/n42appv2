// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Bech32 encode / decode functions
*/
public final class Bech32 {
    private byte[] bytes;

    private Bech32() {
    }

    static Bech32 createFromNative(byte[] bytes) {
        Bech32 instance = new Bech32();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Encodes data as a Bech32 string.
     *
     * @param hrp The human-readable part.
     * @param data The data part.
     * @return the encoded Bech32 string.
*/
    public static native String encode(String hrp, byte[] data);
    /**
 * Decodes a Bech32 string. Returns null if the string is not a valid Bech32 string.
     *
     * @param string The Bech32 string to decode.
     * @return the decoded data, null if the string is not a valid Bech32 string. Note that the human-readable part is not returned.
*/
    public static native byte[] decode(String string);
    /**
 * Encodes data as a Bech32m string.
     *
     * @param hrp The human-readable part.
     * @param data The data part.
     * @return the encoded Bech32m string.
*/
    public static native String encodeM(String hrp, byte[] data);
    /**
 * Decodes a Bech32m string. Returns null if the string is not a valid Bech32m string.
     *
     * @param string The Bech32m string to decode.
     * @return the decoded data, null if the string is not a valid Bech32m string. Note that the human-readable part is not returned.
*/
    public static native byte[] decodeM(String string);
}
