// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents a NEAR Account name
*/
public final class NEARAccount {
    private long nativeHandle;

    private NEARAccount() {
        nativeHandle = 0;
    }

    static NEARAccount createFromNative(long nativeHandle) {
        NEARAccount instance = new NEARAccount();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, NEARAccount::nativeDelete);
        return instance;
    }
    /**
 * Create a NEAR Account
     *
     * @param string Account name
     * @note Account should be deleted by calling \TWNEARAccountDelete
     * @return Pointer to a nullable NEAR Account.
*/
    static native long nativeCreateWithString(String string);
    static native void nativeDelete(long handle);
    /**
 * Returns the user friendly string representation.
     *
     * @param account Pointer to a non-null NEAR Account
     * @return Non-null string account description
*/
    public native String description();
    /**
 * Create a NEAR Account
     *
     * @param string Account name
     * @note Account should be deleted by calling \TWNEARAccountDelete
     * @return Pointer to a nullable NEAR Account.
*/
    public NEARAccount(String string) {
        nativeHandle = nativeCreateWithString(string);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, NEARAccount::nativeDelete);
    }

}
