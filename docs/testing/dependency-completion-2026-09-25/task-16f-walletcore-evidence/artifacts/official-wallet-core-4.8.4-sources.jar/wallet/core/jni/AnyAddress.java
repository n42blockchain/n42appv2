// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents an address in C++ for almost any blockchain.
*/
public final class AnyAddress {
    private long nativeHandle;

    private AnyAddress() {
        nativeHandle = 0;
    }

    static AnyAddress createFromNative(long nativeHandle) {
        AnyAddress instance = new AnyAddress();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, AnyAddress::nativeDelete);
        return instance;
    }
    /**
 * Creates an address from a string representation and a coin type. Must be deleted with TWAnyAddressDelete after use.
     *
     * @param string address to create.
     * @param coin coin type of the address.
     * @return TWAnyAddress pointer or nullptr if address and coin are invalid.
*/
    static native long nativeCreateWithString(String string, CoinType coin);
    /**
 * Creates an bech32 address from a string representation, a coin type and the given hrp. Must be deleted with TWAnyAddressDelete after use.
     *
     * @param string address to create.
     * @param coin coin type of the address.
     * @param hrp hrp of the address.
     * @return TWAnyAddress pointer or nullptr if address and coin are invalid.
*/
    static native long nativeCreateBech32(String string, CoinType coin, String hrp);
    /**
 * Creates an SS58 address from a string representation, a coin type and the given ss58Prefix. Must be deleted with TWAnyAddressDelete after use.
     *
     * @param string address to create.
     * @param coin coin type of the address.
     * @param ss58Prefix ss58Prefix of the SS58 address.
     * @return TWAnyAddress pointer or nullptr if address and coin are invalid.
*/
    static native long nativeCreateSS58(String string, CoinType coin, int ss58Prefix);
    /**
 * Creates an address from a public key.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    static native long nativeCreateWithPublicKey(PublicKey publicKey, CoinType coin);
    /**
 * Creates an address from a public key and derivation option.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @param derivation the custom derivation to use.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    static native long nativeCreateWithPublicKeyDerivation(PublicKey publicKey, CoinType coin, Derivation derivation);
    /**
 * Creates an bech32 address from a public key and a given hrp.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @param hrp hrp of the address.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    static native long nativeCreateBech32WithPublicKey(PublicKey publicKey, CoinType coin, String hrp);
    /**
 * Creates an SS58 address from a public key and a given ss58Prefix.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @param ss58Prefix ss58Prefix of the SS58 address.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    static native long nativeCreateSS58WithPublicKey(PublicKey publicKey, CoinType coin, int ss58Prefix);
    /**
 * Creates a Filecoin address from a public key and a given address type.
     *
     * @param publicKey derivates the address from the public key.
     * @param filecoinAddressType Filecoin address type.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    static native long nativeCreateWithPublicKeyFilecoinAddressType(PublicKey publicKey, FilecoinAddressType filecoinAddressType);
    /**
 * Creates a Firo address from a public key and a given address type.
     *
     * @param publicKey derivates the address from the public key.
     * @param firoAddressType Firo address type.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    static native long nativeCreateWithPublicKeyFiroAddressType(PublicKey publicKey, FiroAddressType firoAddressType);
    static native void nativeDelete(long handle);
    /**
 * Compares two addresses for equality.
     *
     * @param lhs The first address to compare.
     * @param rhs The second address to compare.
     * @return bool indicating the addresses are equal.
*/
    public static native boolean equals(AnyAddress lhs, AnyAddress rhs);
    /**
 * Determines if the string is a valid Any address.
     *
     * @param string address to validate.
     * @param coin coin type of the address.
     * @return bool indicating if the address is valid.
*/
    public static native boolean isValid(String string, CoinType coin);
    /**
 * Determines if the string is a valid Any address with the given hrp.
     *
     * @param string address to validate.
     * @param coin coin type of the address.
     * @param hrp explicit given hrp of the given address.
     * @return bool indicating if the address is valid.
*/
    public static native boolean isValidBech32(String string, CoinType coin, String hrp);
    /**
 * Determines if the string is a valid Any address with the given SS58 network prefix.
     *
     * @param string address to validate.
     * @param coin coin type of the address.
     * @param ss58Prefix ss58Prefix of the given address.
     * @return bool indicating if the address is valid.
*/
    public static native boolean isValidSS58(String string, CoinType coin, int ss58Prefix);
    /**
 * Returns the address string representation.
     *
     * @param address address to get the string representation of.
*/
    public native String description();
    /**
 * Returns coin type of address.
     *
     * @param address address to get the coin type of.
*/
    public native CoinType coin();
    /**
 * Returns underlaying data (public key or key hash)
     *
     * @param address address to get the data of.
*/
    public native byte[] data();
    /**
 * Creates an address from a string representation and a coin type. Must be deleted with TWAnyAddressDelete after use.
     *
     * @param string address to create.
     * @param coin coin type of the address.
     * @return TWAnyAddress pointer or nullptr if address and coin are invalid.
*/
    public AnyAddress(String string, CoinType coin) {
        nativeHandle = nativeCreateWithString(string, coin);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates an bech32 address from a string representation, a coin type and the given hrp. Must be deleted with TWAnyAddressDelete after use.
     *
     * @param string address to create.
     * @param coin coin type of the address.
     * @param hrp hrp of the address.
     * @return TWAnyAddress pointer or nullptr if address and coin are invalid.
*/
    public AnyAddress(String string, CoinType coin, String hrp) {
        nativeHandle = nativeCreateBech32(string, coin, hrp);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates an SS58 address from a string representation, a coin type and the given ss58Prefix. Must be deleted with TWAnyAddressDelete after use.
     *
     * @param string address to create.
     * @param coin coin type of the address.
     * @param ss58Prefix ss58Prefix of the SS58 address.
     * @return TWAnyAddress pointer or nullptr if address and coin are invalid.
*/
    public AnyAddress(String string, CoinType coin, int ss58Prefix) {
        nativeHandle = nativeCreateSS58(string, coin, ss58Prefix);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates an address from a public key.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    public AnyAddress(PublicKey publicKey, CoinType coin) {
        nativeHandle = nativeCreateWithPublicKey(publicKey, coin);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates an address from a public key and derivation option.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @param derivation the custom derivation to use.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    public AnyAddress(PublicKey publicKey, CoinType coin, Derivation derivation) {
        nativeHandle = nativeCreateWithPublicKeyDerivation(publicKey, coin, derivation);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates an bech32 address from a public key and a given hrp.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @param hrp hrp of the address.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    public AnyAddress(PublicKey publicKey, CoinType coin, String hrp) {
        nativeHandle = nativeCreateBech32WithPublicKey(publicKey, coin, hrp);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates an SS58 address from a public key and a given ss58Prefix.
     *
     * @param publicKey derivates the address from the public key.
     * @param coin coin type of the address.
     * @param ss58Prefix ss58Prefix of the SS58 address.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    public AnyAddress(PublicKey publicKey, CoinType coin, int ss58Prefix) {
        nativeHandle = nativeCreateSS58WithPublicKey(publicKey, coin, ss58Prefix);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates a Filecoin address from a public key and a given address type.
     *
     * @param publicKey derivates the address from the public key.
     * @param filecoinAddressType Filecoin address type.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    public AnyAddress(PublicKey publicKey, FilecoinAddressType filecoinAddressType) {
        nativeHandle = nativeCreateWithPublicKeyFilecoinAddressType(publicKey, filecoinAddressType);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

    /**
 * Creates a Firo address from a public key and a given address type.
     *
     * @param publicKey derivates the address from the public key.
     * @param firoAddressType Firo address type.
     * @return TWAnyAddress pointer or nullptr if public key is invalid.
*/
    public AnyAddress(PublicKey publicKey, FiroAddressType firoAddressType) {
        nativeHandle = nativeCreateWithPublicKeyFiroAddressType(publicKey, firoAddressType);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, AnyAddress::nativeDelete);
    }

}
