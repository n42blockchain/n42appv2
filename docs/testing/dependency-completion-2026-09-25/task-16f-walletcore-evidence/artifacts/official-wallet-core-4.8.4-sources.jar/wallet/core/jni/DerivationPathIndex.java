// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents a derivation path index in C++ with value and hardened flag.
*/
public final class DerivationPathIndex {
    private long nativeHandle;

    private DerivationPathIndex() {
        nativeHandle = 0;
    }

    static DerivationPathIndex createFromNative(long nativeHandle) {
        DerivationPathIndex instance = new DerivationPathIndex();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, DerivationPathIndex::nativeDelete);
        return instance;
    }
    /**
 * Creates a new Index with a value and hardened flag.
     * Must be deleted with TWDerivationPathIndexDelete after use.
     *
     * @param value Index value
     * @param hardened Indicates if the Index is hardened.
     * @return A new Index.
*/
    static native long nativeCreate(int value, boolean hardened);
    static native void nativeDelete(long handle);
    /**
 * Returns numeric value of an Index.
     *
     * @param index Index to get the numeric value of.
*/
    public native int value();
    /**
 * Returns hardened flag of an Index.
     *
     * @param index Index to get hardened flag.
     * @return true if hardened, false otherwise.
*/
    public native boolean hardened();
    /**
 * Returns the string description of a derivation path index.
     *
     * @param path Index to get the address of.
     * @return The string description of the derivation path index.
*/
    public native String description();
    /**
 * Creates a new Index with a value and hardened flag.
     * Must be deleted with TWDerivationPathIndexDelete after use.
     *
     * @param value Index value
     * @param hardened Indicates if the Index is hardened.
     * @return A new Index.
*/
    public DerivationPathIndex(int value, boolean hardened) {
        nativeHandle = nativeCreate(value, hardened);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, DerivationPathIndex::nativeDelete);
    }

}
