// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Represents a FIO Account name
*/
public final class FIOAccount {
    private long nativeHandle;

    private FIOAccount() {
        nativeHandle = 0;
    }

    static FIOAccount createFromNative(long nativeHandle) {
        FIOAccount instance = new FIOAccount();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, FIOAccount::nativeDelete);
        return instance;
    }
    /**
 * Create a FIO Account
     *
     * @param string Account name
     * @note Must be deleted with \TWFIOAccountDelete
     * @return Pointer to a nullable FIO Account
*/
    static native long nativeCreateWithString(String string);
    static native void nativeDelete(long handle);
    /**
 * Returns the short account string representation.
     *
     * @param account Pointer to a non-null FIO Account
     * @return Account non-null string representation
*/
    public native String description();
    /**
 * Create a FIO Account
     *
     * @param string Account name
     * @note Must be deleted with \TWFIOAccountDelete
     * @return Pointer to a nullable FIO Account
*/
    public FIOAccount(String string) {
        nativeHandle = nativeCreateWithString(string);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, FIOAccount::nativeDelete);
    }

}
