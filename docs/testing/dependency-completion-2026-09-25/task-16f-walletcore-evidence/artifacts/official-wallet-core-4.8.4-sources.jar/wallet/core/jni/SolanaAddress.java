// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;

/**
 * Solana address helper functions
*/
public final class SolanaAddress {
    private long nativeHandle;

    private SolanaAddress() {
        nativeHandle = 0;
    }

    static SolanaAddress createFromNative(long nativeHandle) {
        SolanaAddress instance = new SolanaAddress();
        instance.nativeHandle = nativeHandle;
        GenericPhantomReference.register(instance, nativeHandle, SolanaAddress::nativeDelete);
        return instance;
    }
    /**
 * Creates an address from a string representation.
     *
     * @param string Non-null pointer to a solana address string
     * @note Should be deleted with \TWSolanaAddressDelete
     * @return Non-null pointer to a Solana address data structure
*/
    static native long nativeCreateWithString(String string);
    static native void nativeDelete(long handle);
    /**
 * Returns the address string representation.
     *
     * @param address Non-null pointer to a Solana Address
     * @return Non-null pointer to the Solana address string representation
*/
    public native String description();
    /**
 * Derive default token address for token
     *
     * @param address Non-null pointer to a Solana Address
     * @param tokenMintAddress Non-null pointer to a token mint address as a string
     * @return Null pointer if the Default token address for a token is not found, valid pointer otherwise
*/
    public native String defaultTokenAddress(String tokenMintAddress);
    /**
 * Derive token 2022 address for token
     *
     * @param address Non-null pointer to a Solana Address
     * @param tokenMintAddress Non-null pointer to a token mint address as a string
     * @return Null pointer if the token 2022 address for a token is not found, valid pointer otherwise
*/
    public native String token2022Address(String tokenMintAddress);
    /**
 * Creates an address from a string representation.
     *
     * @param string Non-null pointer to a solana address string
     * @note Should be deleted with \TWSolanaAddressDelete
     * @return Non-null pointer to a Solana address data structure
*/
    public SolanaAddress(String string) {
        nativeHandle = nativeCreateWithString(string);
        if (nativeHandle == 0) {
            throw new InvalidParameterException();
        }

        GenericPhantomReference.register(this, nativeHandle, SolanaAddress::nativeDelete);
    }

}
