// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Blockchain enum type
*/
public enum Blockchain {
    BITCOIN (0),
    ETHEREUM (1),
    VECHAIN (3),
    TRON (4),
    ICON (5),
    BINANCE (6),
    RIPPLE (7),
    TEZOS (8),
    NIMIQ (9),
    STELLAR (10),
    AION (11),
    COSMOS (12),
    THETA (13),
    ONTOLOGY (14),
    ZILLIQA (15),
    IOTEX (16),
    EOS (17),
    NANO (18),
    NULS (19),
    WAVES (20),
    AETERNITY (21),
    NEBULAS (22),
    FIO (23),
    SOLANA (24),
    HARMONY (25),
    NEAR (26),
    ALGORAND (27),
    IOST (28),
    POLKADOT (29),
    CARDANO (30),
    NEO (31),
    FILECOIN (32),
    MULTIVERSX (33),
    OASISNETWORK (34),
    DECRED (35),
    ZCASH (36),
    GROESTLCOIN (37),
    THORCHAIN (38),
    RONIN (39),
    KUSAMA (40),
    ZEN (41),
    BITCOINDIAMOND (42),
    VERGE (43),
    NERVOS (44),
    EVERSCALE (45),
    APTOS (46),
    NEBL (47),
    HEDERA (48),
    THEOPENNETWORK (49),
    SUI (50),
    GREENFIELD (51),
    INTERNETCOMPUTER (52),
    NATIVEEVMOS (53),
    NATIVEINJECTIVE (54),
    BITCOINCASH (55),
    PACTUS (56),
    KOMODO (57),
    POLYMESH (58);

    private final int value;
    Blockchain(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static Blockchain createFromValue(int value) {
        switch (value) {
            case 0: return Blockchain.BITCOIN;
            case 1: return Blockchain.ETHEREUM;
            case 3: return Blockchain.VECHAIN;
            case 4: return Blockchain.TRON;
            case 5: return Blockchain.ICON;
            case 6: return Blockchain.BINANCE;
            case 7: return Blockchain.RIPPLE;
            case 8: return Blockchain.TEZOS;
            case 9: return Blockchain.NIMIQ;
            case 10: return Blockchain.STELLAR;
            case 11: return Blockchain.AION;
            case 12: return Blockchain.COSMOS;
            case 13: return Blockchain.THETA;
            case 14: return Blockchain.ONTOLOGY;
            case 15: return Blockchain.ZILLIQA;
            case 16: return Blockchain.IOTEX;
            case 17: return Blockchain.EOS;
            case 18: return Blockchain.NANO;
            case 19: return Blockchain.NULS;
            case 20: return Blockchain.WAVES;
            case 21: return Blockchain.AETERNITY;
            case 22: return Blockchain.NEBULAS;
            case 23: return Blockchain.FIO;
            case 24: return Blockchain.SOLANA;
            case 25: return Blockchain.HARMONY;
            case 26: return Blockchain.NEAR;
            case 27: return Blockchain.ALGORAND;
            case 28: return Blockchain.IOST;
            case 29: return Blockchain.POLKADOT;
            case 30: return Blockchain.CARDANO;
            case 31: return Blockchain.NEO;
            case 32: return Blockchain.FILECOIN;
            case 33: return Blockchain.MULTIVERSX;
            case 34: return Blockchain.OASISNETWORK;
            case 35: return Blockchain.DECRED;
            case 36: return Blockchain.ZCASH;
            case 37: return Blockchain.GROESTLCOIN;
            case 38: return Blockchain.THORCHAIN;
            case 39: return Blockchain.RONIN;
            case 40: return Blockchain.KUSAMA;
            case 41: return Blockchain.ZEN;
            case 42: return Blockchain.BITCOINDIAMOND;
            case 43: return Blockchain.VERGE;
            case 44: return Blockchain.NERVOS;
            case 45: return Blockchain.EVERSCALE;
            case 46: return Blockchain.APTOS;
            case 47: return Blockchain.NEBL;
            case 48: return Blockchain.HEDERA;
            case 49: return Blockchain.THEOPENNETWORK;
            case 50: return Blockchain.SUI;
            case 51: return Blockchain.GREENFIELD;
            case 52: return Blockchain.INTERNETCOMPUTER;
            case 53: return Blockchain.NATIVEEVMOS;
            case 54: return Blockchain.NATIVEINJECTIVE;
            case 55: return Blockchain.BITCOINCASH;
            case 56: return Blockchain.PACTUS;
            case 57: return Blockchain.KOMODO;
            case 58: return Blockchain.POLYMESH;
            default: return null;
        }
    }

}
