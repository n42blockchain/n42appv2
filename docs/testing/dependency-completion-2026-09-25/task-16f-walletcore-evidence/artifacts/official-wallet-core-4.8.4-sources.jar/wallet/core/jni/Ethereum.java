// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class Ethereum {
    private long nativeHandle;

    private Ethereum() {
        nativeHandle = 0;
    }

    static Ethereum createFromNative(long nativeHandle) {
        Ethereum instance = new Ethereum();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Returns the checksummed address.
     * 
     * @param address *non-null* string.
     * @return the checksummed address.
*/
    public static native String addressChecksummed(String address);
    /**
 * Returns the account path from address.
     * 
     * @param eth_address *non-null* string.
     * @param layer *non-null* string.
     * @param application *non-null* string.
     * @param index *non-null* string.
     * @return the account path.
*/
    public static native String eip2645GetPath(String ethAddress, String layer, String application, String index);
    /**
 * Returns EIP-1014 Create2 address
     * 
     * @param from *non-null* string.
     * @param salt *non-null* data.
     * @param init_code_hash *non-null* data.
     * @return the EIP-1014 Create2 address.
*/
    public static native String eip1014Create2Address(String from, byte[] salt, byte[] initCodeHash);
    /**
 * Returns EIP-1967 proxy init code
     * 
     * @param logic_address *non-null* string.
     * @param data *non-null* data.
     * @return the EIP-1967 proxy init code.
*/
    public static native byte[] eip1967ProxyInitCode(String logicAddress, byte[] data);
}
