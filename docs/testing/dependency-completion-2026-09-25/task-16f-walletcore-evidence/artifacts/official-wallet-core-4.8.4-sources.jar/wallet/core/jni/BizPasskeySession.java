// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class BizPasskeySession {
    private long nativeHandle;

    private BizPasskeySession() {
        nativeHandle = 0;
    }

    static BizPasskeySession createFromNative(long nativeHandle) {
        BizPasskeySession instance = new BizPasskeySession();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Encodes `BizPasskeySession.registerSession` function call to register a session passkey public key.
     * 
     * @param session_passkey_public_key The nist256p1 (aka secp256p1) public key of the session passkey.
     * @param valid_until_timestamp The timestamp until which the session is valid. Big endian uint64.
     * @return ABI-encoded function call.
*/
    public static native byte[] encodeRegisterSessionCall(PublicKey sessionPasskeyPublicKey, byte[] validUntilTimestamp);
    /**
 * Encodes `BizPasskeySession.removeSession` function call to deregister a session passkey public key.
     * 
     * @param session_passkey_public_key The nist256p1 (aka secp256p1) public key of the session passkey.
     * @return ABI-encoded function call.
*/
    public static native byte[] encodeRemoveSessionCall(PublicKey sessionPasskeyPublicKey);
    /**
 * Encodes `BizPasskeySession` nonce.
     * 
     * @param nonce The nonce of the Biz Passkey Session account.
     * @return uint256 represented as [passkey_nonce_key_192, nonce_64].
*/
    public static native byte[] encodePasskeySessionNonce(byte[] nonce);
    /**
 * Encodes `BizPasskeySession.executeWithPasskeySession` function call to execute a batch of transactions.
     * 
     * @param input The serialized data of `BizPasskeySession.ExecuteWithPasskeySessionInput` protobuf message.
     * @return ABI-encoded function call.
*/
    public static native byte[] encodeExecuteWithPasskeySessionCall(byte[] input);
    /**
 * Signs and encodes `BizPasskeySession.executeWithPasskeySession` function call to execute a batch of transactions.
     * 
     * @param input The serialized data of `BizPasskeySession.ExecuteWithSignatureInput` protobuf message.
     * @return ABI-encoded function call.
*/
    public static native byte[] signExecuteWithSignatureCall(byte[] input);
}
