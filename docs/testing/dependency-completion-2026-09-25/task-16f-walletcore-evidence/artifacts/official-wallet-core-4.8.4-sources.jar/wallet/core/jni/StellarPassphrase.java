// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 * Stellar network passphrase string.
*/
public enum StellarPassphrase {
    STELLAR (0),
    KIN (1);

    private final int value;
    StellarPassphrase(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static StellarPassphrase createFromValue(int value) {
        switch (value) {
            case 0: return StellarPassphrase.STELLAR;
            case 1: return StellarPassphrase.KIN;
            default: return null;
        }
    }


    public String toString() {
        switch (this) {
        case STELLAR: return "Public Global Stellar Network ; September 2015";
        case KIN: return "Kin Mainnet ; December 2018";
        default: return "";
        }
    }
}
