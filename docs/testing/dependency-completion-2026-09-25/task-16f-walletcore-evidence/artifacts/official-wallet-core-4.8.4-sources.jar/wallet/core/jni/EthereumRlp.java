// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;


public final class EthereumRlp {
    private byte[] bytes;

    private EthereumRlp() {
    }

    static EthereumRlp createFromNative(byte[] bytes) {
        EthereumRlp instance = new EthereumRlp();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Encode an item or a list of items as Eth RLP binary format.
     *
     * @param coin EVM-compatible coin type.
     * @param input Non-null serialized `EthereumRlp::Proto::EncodingInput`.
     * @return serialized `EthereumRlp::Proto::EncodingOutput`.
*/
    public static native byte[] encode(CoinType coin, byte[] input);
}
