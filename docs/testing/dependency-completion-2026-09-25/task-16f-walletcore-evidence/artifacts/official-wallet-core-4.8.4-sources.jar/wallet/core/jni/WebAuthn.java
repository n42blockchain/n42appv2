// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;


public final class WebAuthn {
    private byte[] bytes;

    private WebAuthn() {
    }

    static WebAuthn createFromNative(byte[] bytes) {
        WebAuthn instance = new WebAuthn();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Converts attestation object to the public key on P256 curve
     *
     * @param attestationObject Attestation object retrieved from webuthn.get method
     * @return Public key.
*/
    public static native PublicKey getPublicKey(byte[] attestationObject);
    /**
 * Uses ASN parser to extract r and s values from a webauthn signature
     *
     * @param signature ASN encoded webauthn signature: https://www.w3.org/TR/webauthn-2/#sctn-signature-attestation-types
     * @return Concatenated r and s values.
*/
    public static native byte[] getRSValues(byte[] signature);
    /**
 * Reconstructs the original message that was signed via P256 curve. Can be used for signature validation.
     *
     * @param authenticatorData Authenticator Data: https://www.w3.org/TR/webauthn-2/#authenticator-data
     * @param clientDataJSON clientDataJSON: https://www.w3.org/TR/webauthn-2/#dom-authenticatorresponse-clientdatajson
     * @return original messages.
*/
    public static native byte[] reconstructOriginalMessage(byte[] authenticatorData, byte[] clientDataJSON);
}
