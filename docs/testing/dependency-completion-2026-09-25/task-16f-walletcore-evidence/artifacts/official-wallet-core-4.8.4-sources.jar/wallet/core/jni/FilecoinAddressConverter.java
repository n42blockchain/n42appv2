// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;

/**
 * Filecoin-Ethereum address converter.
*/
public final class FilecoinAddressConverter {
    private byte[] bytes;

    private FilecoinAddressConverter() {
    }

    static FilecoinAddressConverter createFromNative(byte[] bytes) {
        FilecoinAddressConverter instance = new FilecoinAddressConverter();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Converts a Filecoin address to Ethereum.
     *
     * @param filecoinAddress: a Filecoin address.
     * @returns the Ethereum address. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String convertToEthereum(String filecoinAddress);
    /**
 * Converts an Ethereum address to Filecoin.
     *
     * @param ethAddress: an Ethereum address.
     * @returns the Filecoin address. On invalid input empty string is returned. Returned object needs to be deleted after use.
*/
    public static native String convertFromEthereum(String ethAddress);
}
