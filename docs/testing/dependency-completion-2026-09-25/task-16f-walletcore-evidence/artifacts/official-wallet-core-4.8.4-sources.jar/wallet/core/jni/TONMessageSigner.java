// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class TONMessageSigner {
    private long nativeHandle;

    private TONMessageSigner() {
        nativeHandle = 0;
    }

    static TONMessageSigner createFromNative(long nativeHandle) {
        TONMessageSigner instance = new TONMessageSigner();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Signs an arbitrary message to prove ownership of an address for off-chain services.
     * https://github.com/ton-foundation/specs/blob/main/specs/wtf-0002.md
     * 
     * @param private_key: the private key used for signing
     * @param message: A custom message which is input to the signing.
     * @returns the signature, Hex-encoded. On invalid input null is returned. Returned object needs to be deleted after use.
*/
    public static native String signMessage(PrivateKey privateKey, String message);
}
