// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;


/**
 *  Registered human-readable parts for BIP-0173
 *
 * - SeeAlso: https://github.com/satoshilabs/slips/blob/master/slip-0173.md
*/
public enum HRP {
    UNKNOWN (0),
    BITCOIN (1),
    LITECOIN (2),
    VIACOIN (3),
    GROESTLCOIN (4),
    DIGIBYTE (5),
    MONACOIN (6),
    SYSCOIN (7),
    VERGE (8),
    COSMOS (9),
    ZCASH (10),
    BITCOINCASH (11),
    BITCOINGOLD (12),
    IOTEX (13),
    NERVOS (14),
    ZILLIQA (15),
    TERRA (16),
    CRYPTOORG (17),
    KAVA (18),
    OASIS (19),
    BLUZELLE (20),
    BANDCHAIN (21),
    MULTIVERSX (22),
    SECRET (23),
    AGORIC (24),
    BINANCE (25),
    ECASH (26),
    THORCHAIN (27),
    BITCOINDIAMOND (28),
    HARMONY (29),
    CARDANO (30),
    QTUM (31),
    PACTUS (32),
    STRATIS (33),
    NATIVEINJECTIVE (34),
    OSMOSIS (35),
    TERRAV2 (36),
    COREUM (37),
    NATIVEZETACHAIN (38),
    NATIVECANTO (39),
    SOMMELIER (40),
    FETCHAI (41),
    MARS (42),
    UMEE (43),
    QUASAR (44),
    PERSISTENCE (45),
    AKASH (46),
    NOBLE (47),
    SEI (48),
    STARGAZE (49),
    NATIVEEVMOS (50),
    TIA (51),
    DYDX (52),
    JUNO (53),
    TBINANCE (54),
    STRIDE (55),
    AXELAR (56),
    CRESCENT (57),
    KUJIRA (58),
    COMDEX (59),
    NEUTRON (60);

    private final int value;
    HRP(int value) {
        this.value = value;
    }
    public int value() { return value; }

    public static HRP createFromValue(int value) {
        switch (value) {
            case 0: return HRP.UNKNOWN;
            case 1: return HRP.BITCOIN;
            case 2: return HRP.LITECOIN;
            case 3: return HRP.VIACOIN;
            case 4: return HRP.GROESTLCOIN;
            case 5: return HRP.DIGIBYTE;
            case 6: return HRP.MONACOIN;
            case 7: return HRP.SYSCOIN;
            case 8: return HRP.VERGE;
            case 9: return HRP.COSMOS;
            case 10: return HRP.ZCASH;
            case 11: return HRP.BITCOINCASH;
            case 12: return HRP.BITCOINGOLD;
            case 13: return HRP.IOTEX;
            case 14: return HRP.NERVOS;
            case 15: return HRP.ZILLIQA;
            case 16: return HRP.TERRA;
            case 17: return HRP.CRYPTOORG;
            case 18: return HRP.KAVA;
            case 19: return HRP.OASIS;
            case 20: return HRP.BLUZELLE;
            case 21: return HRP.BANDCHAIN;
            case 22: return HRP.MULTIVERSX;
            case 23: return HRP.SECRET;
            case 24: return HRP.AGORIC;
            case 25: return HRP.BINANCE;
            case 26: return HRP.ECASH;
            case 27: return HRP.THORCHAIN;
            case 28: return HRP.BITCOINDIAMOND;
            case 29: return HRP.HARMONY;
            case 30: return HRP.CARDANO;
            case 31: return HRP.QTUM;
            case 32: return HRP.PACTUS;
            case 33: return HRP.STRATIS;
            case 34: return HRP.NATIVEINJECTIVE;
            case 35: return HRP.OSMOSIS;
            case 36: return HRP.TERRAV2;
            case 37: return HRP.COREUM;
            case 38: return HRP.NATIVEZETACHAIN;
            case 39: return HRP.NATIVECANTO;
            case 40: return HRP.SOMMELIER;
            case 41: return HRP.FETCHAI;
            case 42: return HRP.MARS;
            case 43: return HRP.UMEE;
            case 44: return HRP.QUASAR;
            case 45: return HRP.PERSISTENCE;
            case 46: return HRP.AKASH;
            case 47: return HRP.NOBLE;
            case 48: return HRP.SEI;
            case 49: return HRP.STARGAZE;
            case 50: return HRP.NATIVEEVMOS;
            case 51: return HRP.TIA;
            case 52: return HRP.DYDX;
            case 53: return HRP.JUNO;
            case 54: return HRP.TBINANCE;
            case 55: return HRP.STRIDE;
            case 56: return HRP.AXELAR;
            case 57: return HRP.CRESCENT;
            case 58: return HRP.KUJIRA;
            case 59: return HRP.COMDEX;
            case 60: return HRP.NEUTRON;
            default: return null;
        }
    }


    public String toString() {
        switch (this) {
        case UNKNOWN: return "";
        case BITCOIN: return "bc";
        case LITECOIN: return "ltc";
        case VIACOIN: return "via";
        case GROESTLCOIN: return "grs";
        case DIGIBYTE: return "dgb";
        case MONACOIN: return "mona";
        case SYSCOIN: return "sys";
        case VERGE: return "vg";
        case COSMOS: return "cosmos";
        case ZCASH: return "tex";
        case BITCOINCASH: return "bitcoincash";
        case BITCOINGOLD: return "btg";
        case IOTEX: return "io";
        case NERVOS: return "ckb";
        case ZILLIQA: return "zil";
        case TERRA: return "terra";
        case CRYPTOORG: return "cro";
        case KAVA: return "kava";
        case OASIS: return "oasis";
        case BLUZELLE: return "bluzelle";
        case BANDCHAIN: return "band";
        case MULTIVERSX: return "erd";
        case SECRET: return "secret";
        case AGORIC: return "agoric";
        case BINANCE: return "bnb";
        case ECASH: return "ecash";
        case THORCHAIN: return "thor";
        case BITCOINDIAMOND: return "bcd";
        case HARMONY: return "one";
        case CARDANO: return "addr";
        case QTUM: return "qc";
        case PACTUS: return "pc";
        case STRATIS: return "strax";
        case NATIVEINJECTIVE: return "inj";
        case OSMOSIS: return "osmo";
        case TERRAV2: return "terra";
        case COREUM: return "core";
        case NATIVEZETACHAIN: return "zeta";
        case NATIVECANTO: return "canto";
        case SOMMELIER: return "somm";
        case FETCHAI: return "fetch";
        case MARS: return "mars";
        case UMEE: return "umee";
        case QUASAR: return "quasar";
        case PERSISTENCE: return "persistence";
        case AKASH: return "akash";
        case NOBLE: return "noble";
        case SEI: return "sei";
        case STARGAZE: return "stars";
        case NATIVEEVMOS: return "evmos";
        case TIA: return "celestia";
        case DYDX: return "dydx";
        case JUNO: return "juno";
        case TBINANCE: return "tbnb";
        case STRIDE: return "stride";
        case AXELAR: return "axelar";
        case CRESCENT: return "cre";
        case KUJIRA: return "kujira";
        case COMDEX: return "comdex";
        case NEUTRON: return "neutron";
        default: return "";
        }
    }
}
