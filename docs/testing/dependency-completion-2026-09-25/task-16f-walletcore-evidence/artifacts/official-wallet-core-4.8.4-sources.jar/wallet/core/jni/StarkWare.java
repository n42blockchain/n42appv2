// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;


public final class StarkWare {
    private byte[] bytes;

    private StarkWare() {
    }

    static StarkWare createFromNative(byte[] bytes) {
        StarkWare instance = new StarkWare();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Generates the private stark key at the given derivation path from a valid eth signature
     *
     * @param derivationPath non-null StarkEx Derivation path
     * @param signature valid eth signature
     * @return  The private key for the specified derivation path/signature, or `nullptr` if the signature or derivation path is invalid or an internal error occurs.
*/
    public static native PrivateKey getStarkKeyFromSignature(DerivationPath derivationPath, String signature);
}
