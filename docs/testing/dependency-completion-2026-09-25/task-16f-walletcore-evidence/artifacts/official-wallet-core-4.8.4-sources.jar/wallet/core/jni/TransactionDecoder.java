// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;


public final class TransactionDecoder {
    private byte[] bytes;

    private TransactionDecoder() {
    }

    static TransactionDecoder createFromNative(byte[] bytes) {
        TransactionDecoder instance = new TransactionDecoder();
        instance.bytes = bytes;
        return instance;
    }
    /**
 * Decodes a transaction from a binary representation.
     *
     * @param coin coin type.
     * @param encodedTx encoded transaction data.
     * @return serialized protobuf message specific for the given coin.
*/
    public static native byte[] decode(CoinType coinType, byte[] encodedTx);
}
