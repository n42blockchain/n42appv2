// SPDX-License-Identifier: Apache-2.0
//
// Copyright © 2017 Trust Wallet.
//
// This is a GENERATED FILE, changes made here WILL BE LOST.
//

package wallet.core.jni;

import java.security.InvalidParameterException;
import wallet.core.java.GenericPhantomReference;


public final class WebAuthnSolidity {
    private long nativeHandle;

    private WebAuthnSolidity() {
        nativeHandle = 0;
    }

    static WebAuthnSolidity createFromNative(long nativeHandle) {
        WebAuthnSolidity instance = new WebAuthnSolidity();
        instance.nativeHandle = nativeHandle;
        return instance;
    }
    /**
 * Computes WebAuthn message hash to be signed with secp256p1 private key.
     * 
     * @param authenticator_data The authenticator data in hex format.
     * @param client_data_json The client data JSON string with a challenge.
     * @return WebAuthn message hash.
*/
    public static native byte[] getMessageHash(String authenticatorData, String clientDataJson);
    /**
 * Converts the original ASN-encoded signature from webauthn to the format accepted by Barz
     * 
     * @param authenticator_data The authenticator data in hex format.
     * @param client_data_json The client data JSON string with a challenge.
     * @param der_signature original ASN-encoded signature from webauthn.
     * @return WebAuthn ABI-encoded data.
*/
    public static native byte[] getFormattedSignature(String authenticatorData, String clientDataJson, byte[] derSignature);
}
