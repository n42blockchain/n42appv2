#!/usr/bin/env python3
"""Compare same-commit old/new Go AAR release ZIP inventories."""

import hashlib
import json
from pathlib import Path
import sys
import zipfile


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def category(name):
    if name.startswith(("lib/", "base/lib/")):
        return "native"
    if name.startswith(("assets/", "base/assets/")):
        return "assets"
    if name.startswith(("res/", "base/res/")):
        return "resources"
    if name.endswith(".dex"):
        return "dex"
    if name.startswith("BUNDLE-METADATA/"):
        return "bundle_metadata"
    return "other"


def inspect(path):
    result = {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}
    with zipfile.ZipFile(path) as bundle:
        files = {i.filename: i for i in bundle.infolist() if not i.is_dir()}
        result["members"] = len(files)
        result["categories"] = {}
        for name, info in files.items():
            group = result["categories"].setdefault(
                category(name), {"members": 0, "raw_bytes": 0, "compressed_bytes": 0}
            )
            group["members"] += 1
            group["raw_bytes"] += info.file_size
            group["compressed_bytes"] += info.compress_size
        result["go_members"] = {}
        for name in sorted(files):
            if name.endswith("/libgojni.so"):
                payload = bundle.read(name)
                result["go_members"][name] = {
                    "bytes": len(payload),
                    "compressed_bytes": files[name].compress_size,
                    "sha256": hashlib.sha256(payload).hexdigest(),
                }
        return result, files


def compare(old, new):
    old_data, old_files = inspect(old)
    new_data, new_files = inspect(new)
    changed = []
    for name in sorted(set(old_files) | set(new_files)):
        before = old_files.get(name)
        after = new_files.get(name)
        if before is None:
            kind = "added"
        elif after is None:
            kind = "removed"
        elif (before.CRC, before.file_size, before.compress_size) != (
            after.CRC, after.file_size, after.compress_size
        ):
            kind = "changed"
        else:
            continue
        changed.append({
            "name": name,
            "category": category(name),
            "change": kind,
            "old_raw_bytes": before.file_size if before else 0,
            "new_raw_bytes": after.file_size if after else 0,
            "old_compressed_bytes": before.compress_size if before else 0,
            "new_compressed_bytes": after.compress_size if after else 0,
            "old_crc32": f"{before.CRC:08x}" if before else None,
            "new_crc32": f"{after.CRC:08x}" if after else None,
        })
    return {
        "old": old_data,
        "new": new_data,
        "total_byte_delta": new_data["bytes"] - old_data["bytes"],
        "member_changes": changed,
        "comparison": "ZIP CRC32, raw and compressed sizes; Go members SHA-256",
    }


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: compare-size.py OLD_DIR NEW_DIR")
    old_dir, new_dir = map(Path, sys.argv[1:])
    print(json.dumps({
        suffix: compare(old_dir / f"app-release.{suffix}", new_dir / f"app-release.{suffix}")
        for suffix in ("apk", "aab")
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
