# Task16C protocol/source slice review

Reviewed committed range `410a62b4f825a961c918b10445135aa717f0de61..b5939303b8da5e71c78028ae055b4f3f5bb3a76b` against the Task16C brief, scoped protocol report and retained logs. Mutable platform fixes, candidate AAR production, dependency upgrades and later native work are excluded. No builds/tests/native reruns or source edits were performed.

## Verdict

- **Spec compliance: PASS for this source-only slice.** It records the narrow Emit binding and characterizes selected real engine behavior without claiming whole Task16C completion.
- **Code quality: PASS.** No concrete blocking defect or new regression found in the committed increment.
- **Findings: none requiring a change in this commit.** Binary/API/runtime/security/BLS-parity gates remain open as explicitly recorded by the implementer.

## Independently checked

1. **Source identity / overlay guards.** `prepare_source.sh:8-10,36-49` binds all three new files to exact SHA-256, rejects hashing failures or mismatches with explicit exit11 before output creation, and retains the fixed canonical `5083c29735acfc7023ab1fbbd6d6527b7b97cbae` archive and prior patch/module guards. Lines68-82 reject unexpected overlay destinations and explicitly reject mkdir/copy failures. No sibling source write or replacement of an existing output was added. Existing source archive / explicit `GOFLAGS=-buildvcs=false` convention remains intact.

   Hashes recomputed from `git show b5939303b:<path>` match the script and the actual prepared files at `/private/tmp/n42-task16c-go/protocol-recipe-test/cmd/evmsdk`:

   | Overlay | SHA-256 |
   | --- | --- |
   | `protocol/emit_contract_test.go` | `1fddc806bee30c1d2697cb8a13cda893ad4c193f341307a99d186c6c48816b38` |
   | `protocol/mobilebind/emit.go` | `8212470e064305bb18a01a8cbd90412ab074a4ff395991982f6e6f349e1603d4` |
   | `protocol/mobilebind/emit_test.go` | `cc83ebc5da0e61ce4b43c5750be2f7c868f8702600aec9acaf68314dafab39eb` |

   `prepare-protocol-positive.log` records those exact hashes. `prepare-protocol-tamper.log` contains the expected mismatch diagnostic; exit11 and no-output observation are reported by the implementer, while the raw short log alone does not encode either exit status or a filesystem assertion. Code ordering independently supports the before-output rejection. This is sufficient for this bounded review, not a new claim of a fully bound durable build manifest.

2. **Real Emit characterization.** `protocol/emit_contract_test.go:15-33` calls real `Emit`, requires code/message/data and decodes their types. Lines35-66 cover initial settings, stopped state, repeated idle stop and partial-update preservation of account/private key. Lines68-111 cover malformed JSON/setting/key/message and low/high synthetic32-byte BLS requests. Tests restore the engine/debug globals and do not run in parallel or invoke start. Fixture keys are deterministic synthetic material, not user secrets.

   `emit-contract-prepared-green.log` contains PASS for the facade test, both new parent test groups (including all listed subcases), the two inherited real-Emit redaction tests, and inherited `TestWebSocketServiceForwardWritesDeliversWrappedRequest`. The latter's source asserts exact `eth_submitSign` JSON-RPC wrapping through an in-memory callback; it does not connect to a validator or establish actual WebSocket/server acceptance. No test rerun was needed.

3. **Facade/API preservation.** `protocol/mobilebind/emit.go:4-9` keeps package name `evmsdk`, exports only `Emit(string) string`, and forwards the request unchanged to `engine.Emit`. It does not whitelist operations, remove upstream Go functions, transform responses or change start/state/stop behavior. Actual Android callers remain `FlutterMiningPlugin.kt:42` and `TransactionSignerHandler.kt:242`, both using `Evmsdk.emit`.

   `gomobile-build-1.log` explicitly shows gobind rejecting the upstream tuple-returning `DecodeWireHeader` and `GenerateMobileBLSKey`; the facade is a bounded solution to that export limitation. `gobind-protocol-prepared.log` honestly retains the separate missing pinned x/mobile graph failure. The retained generated `/private/tmp/n42-task16c-go/protocol-gobind/java/evmsdk/Evmsdk.java:28` has `public static native String emit(String request);`. Generated Java is not a compiled AAR descriptor or JNI-load proof; report/README correctly leave that gate pending. The review establishes current caller preservation, not parity of every public method in the old unprovenanced AAR.

4. **Scope / evidence accuracy.** The only unrelated-looking diff is the documented hook version increment in `pubspec.yaml`; no AAR/Gradle integration changed. BLS assertions check response status, string type and length, not hex validity, cryptographic correctness, scalar derivation or old/new byte identity. The report explicitly describes the narrower type/length scope and leaves independent vectors and native comparison pending. It also leaves three-ABI builds, security/license inventory,16KB ELF and durable archive completion open.

## Carry-forward gates, not findings against this slice

Retain the brief's independent low/high-input BLS derivation/signature vectors, exact amount-message bytes, compiled `Evmsdk.emit(Ljava/lang/String;)Ljava/lang/String;` inspection, all three ABIs and isolated offline runtime tests before integration. The current stopped-state fixture does not establish the started-state branch or live V1 operation; do not infer either from delegation or compile success. Preserve bounded failed attempts and full command/exit/input identity in durable evidence before final Task16C acceptance; ignored logs alone are not the final evidence deliverable.
