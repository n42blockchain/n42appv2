# Task16C build recipe fix-round1 review

Range: `dd19b79d4..617a4fef8`. Scoped to the two original P2 findings and regressions introduced by their repair. Reviewed committed script/README changes, fix report, retained negative-control logs and preflight sidecars. No build, test, native/device execution or tracked edit was performed.

## Verdict

- **Spec compliance: PASS for the scoped repair.**
- **Code quality: PASS.** No new blocking regression found.
- **P2 NDK selection: ADDRESSED.**
- **P2 inherited Go routing: ADDRESSED.**

This closes the two findings against the build-recipe group. It does not accept app integration, a newly rebuilt binary, or whole Task16C completion.

## P2 NDK selection — addressed

`build_android_aar.sh:44-65` now derives the exact28.2 directory from the selected SDK, checks executable clang and source.properties, explicitly rejects a different revision and verifies both metadata and clang SHA-256. These failures precede creation of the run directory. Line75 exports `ANDROID_NDK_HOME` to that checked path; pinned gomobile prioritizes this variable, so inherited29.x and side-by-side newest-version selection cannot override the recipe's chosen NDK. Lines89-94 record selected path/revision/hashes and clang version before preflight/bind.

Read `build-hostile-env-final/inputs.txt`: selected path is the task-owned mock SDK's28.2 symlink, with expected revision and hashes. Independently hashed that selected metadata and clang: `c00aa236fdb205e9be9edd9e2169763e48aca52735efff4e16f34205d49783b5` and `df85444b66234bf4cae267e22bde45ea8fef596d30ca2991b2091a27e6ea7718`, matching committed checks. The retained version output identifies Android clang19.0.1 and its real installation path.

`build-wrong-ndk-final.log`, `build-missing-ndk.log` and `build-bad-clang.log` contain the expected rejection diagnostics. Reported exit5 / before-output outcomes agree with explicit source ordering; the short raw logs alone do not contain exit-code footers. `build-hostile-env-final.log` records preflight PASS under the stated hostile inherited NDK setup; its input sidecar confirms selection. No native bind was required to prove this selection change.

## P2 inherited Go routing — addressed

Build lines25-27 and prefetch lines52-55 establish GOENV=off, GOWORK=off, fixed GOFLAGS/GOTOOLCHAIN, empty GOPRIVATE/GONOPROXY/GONOSUMDB/GOINSECURE, and GOVCS=*:off before Go commands. They then select the distinct intended proxy/sumdb policies. The prefetch opt-in remains required. This removes the private/direct route that preceded GOPROXY=off in the prior recipe and removes inherited public-fetch checksum exemptions.

Read both hostile-run `go-env.json` files:

| Setting | Prefetch | Build |
| --- | --- | --- |
| GOPROXY | https://proxy.golang.org | off |
| GOSUMDB | sum.golang.org | off |
| GOPRIVATE / GONOPROXY / GONOSUMDB / GOINSECURE | empty | empty |
| GOVCS | *:off | *:off |
| GOWORK | off | off |

Both inputs explicitly record `goenv_export=off`; `go env` renders its disabled GOENV path as an empty string, so that JSON value is not evidence that the hostile settings were loaded. `hostile-env-final-assertions.log` records the expected routing and NDK checks. Prefetch's environment-only mode exits before download; build's preflight-only mode exits after separate offline source/generated graph checks and module verification, before bind. The retained module verification log says all modules verified. Report and README correctly describe module-fetch controls rather than an OS network sandbox.

## Regression / evidence boundaries

- Optional inspection modes reject unknown arguments and use the same environment setup as the regular paths; they do not bypass pin checks or public-fetch opt-in. A normal invocation continues through the unchanged download/bind and exact generated-graph checks.
- Source patches, selected module graph, ABI/API/tag settings, portable BLST flag and both16KB link flags are unchanged. No AAR or app integration changed in this commit.
- The earlier `23da7d12133b272e56a15cc5a9a6bce4844a75c4ff176d0c7106d114e9900eea` AAR predates these identity records. The report explicitly states its actual historical NDK/clang identity remains unproven by the retained build log. This preflight does not fill that gap retroactively.
- New source-changing builds must use the corrected recipe and retain their own input/compiler/artifact identity and applicable scanner/runtime evidence. No duplicate full native rebuild is required solely to close these two environment-selection findings.
