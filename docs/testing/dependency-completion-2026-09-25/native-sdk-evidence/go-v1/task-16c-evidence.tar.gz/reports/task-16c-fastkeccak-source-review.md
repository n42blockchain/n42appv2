# Task16C Legacy Keccak source review

Range `617a4fef8..7b8e223c29857ee647e14e58ad0e10db62b41d5f`. Reviewed committed patch/test/recipe changes, report, fresh prepared source and retained RED/GREEN/package-graph evidence. No build/test/native reruns, tracked edits or child agents. New AAR integration and final runtime/scanner/legal acceptance are outside this source review.

## Verdict

- **Spec compliance: PASS for this bounded source replacement.**
- **Code quality: PASS.** No blocking defect or new regression found.
- **Findings requiring a change: none.** New-binary acceptance remains separate.

## Semantic review

The new section of `android/source.patch` changes only the import and four hash calls in `lib/commitment/keys_nibbles.go`, plus the small `legacyKeccak256` wrapper. The prepared result is at that source file's lines16-62:

- `len(key) > length.Addr` remains the storage branch. Exactly20 bytes stays an account key;21 bytes hashes the first20 and remaining1 separately. Output lengths remain64 nibbles for account/direct hash and128 for storage.
- Each32-byte digest is copied into the same temporary half of the destination buffer. The unchanged nibblization loop emits high nibble then low nibble. The overlapping layout and returned buffer behavior are unchanged.
- `KeyToNibblizedHash` still hashes the entire input once, regardless of length.
- The wrapper creates a new `sha3.NewLegacyKeccak256()` state per call, writes the supplied bytes and returns a32-byte value. There is no shared mutable hasher, input mutation, truncation or changed key derivation. Selected x/crypto0.57.0 `sha3/legacy_hash.go:35-36` uses Keccak domain padding and32-byte output; its Write method consumes the input and returns nil error, making the wrapper's ignored Write error valid for this concrete implementation. Nil/empty input follows the same zero-length absorption path.

This is Legacy Keccak, not ordinary NIST SHA3-256. No BLS/Emit/deposit/account persistence code changes in this group. Existing inaccurate boundary wording in an upstream comment was not changed; the operative `>` branch and test expectations preserve actual behavior.

## Test and provenance evidence

`android/tests/lib/commitment/keys_nibbles_keccak_portable_test.go:11-46` freezes eight synthetic incremental-byte vectors of lengths0,1,20,21,135,136,137,272. Each verifies the raw Legacy Keccak digest against a fixed value and SHA256 fingerprints of both complete nibble outputs. The nibble checks call the actual production functions, so they cover all four replaced call sites across account/storage/direct paths.

Read the retained generator: it calls exact selected fastkeccak.Sum256 and the old commitment functions, with a separate Legacy Keccak comparison. `fastkeccak-baseline-vectors.log` records matching raw hashes and all expected nibble fingerprints. Independently hashed the retained v3 `keys_nibbles.go`: `499a1ad9185d76571c28f29571e64a708f12b22e4321cdf463ddbb2c0fee50c5`, matching the report's original key-code identity. That hash identifies the **SDK key-code file**, not the entire fastkeccak module source tree.

`ordinary-sha3-mutant-red.log` contains eight actual account/storage assertion failures, including empty input; this is behavioral RED, not compile failure. Because each subtest stops at that first failing assertion, it does not separately demonstrate that the direct-output assertion also failed in the mutant run. The passing run checks both outputs. The raw log does not itself include the reported MUTANT_EXIT footer; FAIL output establishes the test failure, while exact exit1 is the implementer's recorded result.

`fastkeccak-removal-green.log` passes the vector test. `fastkeccak-package-green.log` records the full commitment package pass (13.787s); `fastkeccak-fresh-source-green.log` passes that package again from the prepared source (13.871s). No rerun was needed. The committed test bytes equal the fresh v4 test, and independently computed SHA256 `e18aa22e96f363944e55b14cbfbe217a2aaf092868c95c69ccc0d2c587641e96` matches the recipe pin.

## Recipe and graph consistency

Source changes remove only the fastkeccak requirement/checksums in addition to the bounded key-code patch; generated graph removals match. No new module is added. Independently recomputed:

| Input | SHA256 |
| --- | --- |
| Android source patch | `453bba81aa9e5c68f40371889c818e1e33a367c0b33d51b672eefa927629d648` |
| Fresh source go.mod | `1a98bf2ee961c11b4e77cc8a6ff3026bfdcdf950ab14270af402d6889ebfec1b` |
| Fresh source go.sum | `6dedcc331228891ee79297521297697020263b3710f59f9b0c775ab3cec3b7b0` |
| Generated module template | `73f3d67e6bb00113eb59353d376ac90d7194b9c930453ddba1a1d4459068a57e` |
| Generated sum | `2ae35fbba78a593eda6ef02a49b02e4eb1b39841a9150a81d8a0de07b33ac424` |

Prepare, prefetch and build scripts use these updated values, including post-fetch sum validation and output identity records. Preparation installs the new hash-checked test through the existing collision/copy failure guard. The previously accepted NDK pin and Go-routing isolation remain unchanged.

All retained v4 generated arm/arm64/amd64 normalized module files and sums are byte-identical to the committed template/sum. Independently parsed the three raw package JSON streams:924/926/928 complete packages, zero Error/DepsErrors/Incomplete markers, no fastkeccak, and selected x/crypto/sha3 present. A source search of fresh v4 Go files/go.mod/go.sum also found no fastkeccak reference. These establish removal from this prepared package selection, not all application binaries or a whole-artifact license conclusion.

## Acceptance boundary

The report correctly assigns rebuilt `a7f1e0122ca76fe6a4b5c3a29816a07bb95cacb3cc6c21d73573d90a168d258c` its own subsequent runtime, ELF, scanner and integration gates; previous23da evidence cannot substitute. No tracked AAR is changed here. The bounded implementation avoids depending on the questioned fastkeccak version, but this review does not independently provide a legal clearance determination for the complete SDK. Preserve baseline generator/logs, mutation log and fresh-source evidence in the final durable package.
