# Task16C binary integration review

Scope: `afdfad230d654955a68e12811f75c74e9993cfe0..1243d11b3cce62b2664fdd55415e34104a6c8153`. Two AAR replacements and hook `pubspec.yaml` build-number increment only. Earlier source/recipe/fixture reviews are accepted and were not repeated. No build/test/device reruns; no tracked edits.

## Verdict

- **Spec compliance: PASS for bounded binary integration.** Both committed inputs are exactly the reviewed and exercised a7 candidate; three ABIs and the production Java entry point remain present. Existing compile/runtime Gradle ownership and both callers are preserved.
- **Code quality: PASS.** No new concrete finding in this binary-only increment. This does not grant whole-app release, store signing, ARM32 runtime, WSS/remote-validator, or final durable-evidence acceptance.

## Independent committed-blob checks

Read blobs directly from commit `1243d11b3`, not mutable worktree AARs:

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `android/app/libs/evm.aar` | 41,052,430 | `a7f1e0122ca76fe6a4b5c3a29816a07bb95cacb3cc6c21d73573d90a168d258c` |
| `plugins/flutter_mining/android/libs/evm.aar` | 41,052,430 | same |

Each includes `jni/armeabi-v7a/libgojni.so` (ELF32/ARM), `jni/arm64-v8a/libgojni.so` (ELF64/AArch64), and `jni/x86_64/libgojni.so` (ELF64/x86-64). Their raw SHA256s are respectively `588cc9efc7b2efcf57861cf21ab476e16df9ac263dd858dcc9892a66c7209293`, `c81ca645563c5f9663448cc1fc02f6adf1b387815e5b698fab80dec971614762`, and `9fbb582f44f34e36229824131e2ed58cd7cbec982be8c01c977ea63641060954`.

Independently decoded committed `classes.jar!/evmsdk/Evmsdk.class`: public static native `emit` descriptor `(Ljava/lang/String;)Ljava/lang/String;`. `classes.jar` SHA256 is `f8227480ce7cda83b0a3c21c5155f8c3265c7bc50bc16f5b5b27507d3b971a88`. This agrees with accepted fixture/recipe and retained `rebuild-v4-javap.txt`.

`android/app/build.gradle.kts:191` remains compileOnly; runtime remains plugin `implementation project(':evm-module')`, whose default artifact is the plugin AAR. The two `Evmsdk.emit` callers (`FlutterMiningPlugin.kt:42`, `TransactionSignerHandler.kt:242`) and V1 selection are unchanged. No ABI is removed or fallback introduced.

## Retained release evidence

Read `task-16c-logs/go-v4-app-release-{apk,aab}.log`, `go-v4-release-{apk,aab}-go-members.txt`, both native-audit JSONs, APK zipalign and apksigner logs. Independently read current resulting archives before the implementer's separate size-baseline work:

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| release APK | 800,218,952 | `f1a31c5feb5266890067f44ed8915651c52a06ab77a16e2926a3c9f1923ce11c` |
| release AAB | 496,336,562 | `ee0da215c2918789066fd9e2eb022800d239aee1329088db08b8b9e2b725577e` |

Both archives' three Go member hashes independently agree with retained strip comparisons: ARM32 `682c95d70937cafe1a9d27f73cabbb15401ae71f98e9008eba7c74d07e1a5267`, ARM64 `7f0c14b8ed06c52b8fa758668b071e678520e471a6fb584dc4224aa3451161c6`, x86-64 `fae0e1f59f95965a3cbfcf2b78e841607ab0be20c90f8fcc97a933392b457168`. Existing logs record all three as equal to NDK-stripped reviewed AAR members; no strip/build rerun was performed for this review.

Formal Flutter release logs finish successfully for assembleRelease and bundleRelease. Release configuration retains minification/resource shrinking. APK zipalign reports Verification successful; apksigner verifies v2 with one signer. Worker identifies this as a temporary debug-signing release build, subsequently restored, so signature validity is not store identity acceptance.

**Build epoch matters:** worker corrected the release epoch to HEAD `d905de757`, with already-replaced a7 worktree AARs and build number `2026072892`. Current binary commit has hook build number `2026072894`. These are release build/package evidence for the same native bytes and production source, not a claim that a clean exact `1243d11b3` release was built. The durable evidence group must preserve this distinction and temporary-signing provenance.

Both current whole audits are **FAIL: 35 of 55 checked libraries**. Independently compared to Task16B's 37/55 failure lists: the only removed failures are ARM64 and x86-64 `libgojni.so`; no failure added. This closes the changed Go libraries' static alignment findings and leaves other failures in Task16F. An ELF/static pass is not runtime proof for every ABI; accepted isolated strict16KB execution is ARM64/debug fixture only.

## Remaining gates

- Preserve source/build/fixture/package provenance and raw evidence in the separately queued durable group, including exact commands, strip tool identity, release epoch/signing override and final artifact hashes.
- Full-app native alignment still fails; real validator/WSS and ARM32 execution limitations remain. Do not infer server or on-chain acceptance from offline fixture parity.
- Report the 800.2MB current APK and 496.3MB AAB honestly. The prior approximately 739MB APK was not retained; no size-change cause is established here. The separately queued controlled baseline comparison owns that investigation.
