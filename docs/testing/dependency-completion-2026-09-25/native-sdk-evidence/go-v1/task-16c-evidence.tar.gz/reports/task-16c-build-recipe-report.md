# Task16C offline Go mobile build recipe for scoped review

Commit `dd19b79d4` (`build: pin offline Go mobile module graphs`) follows source commit `54185d01a`. Implementer did not push. This group adds separate source/generated graph prefetch, a fully offline three-ABI binding command, exact graph comparison, and usage/limits. App AARs are unchanged.

## Inputs and current candidate

- Public source commit `5083c29735acfc7023ab1fbbd6d6527b7b97cbae`, then both tracked patches/overlays. Final source `go.mod` SHA256 `4639b00890c7a3a4f74760f7d94241cb093eb3e9bc06df7161b238cc99b8dd02`, `go.sum` SHA256 `0cddda5969568083ac76e023426edb81107ae6ad598587867786a52b7a56d599`. Source archive has no Git metadata; build sets `GOFLAGS=-buildvcs=false` and records source identity separately.
- Go1.26.8 binary SHA256 `2ebc27dd4e38e9b86a9f41df0307785f4f7e2997e4be761a7b4af04b41a0de57`; task-owned gomobile SHA `fbc873fa18751c39c7bdef9eb73abffbcfe321527129fbb980f71bb77de92b43`, gobind SHA `7f4343e4acc6767ab73d8f580d24125533b432fd8494868f5649dc01761bae30`, both from `golang.org/x/mobile@v0.0.0-20260908204917-8b95e45f8d3e`. Android SDK37/NDK28.2.13676358, JDK21. API26, tags `nosqlite,noboltdb`, all shipping ABI arm/arm64/amd64, BLST portable, 16KB link flags, `-trimpath`, `-ldflags='-s -w'`.
- Normalized generated `go.mod` template SHA256 `9ad07b22d3153642defe0f1fc4b8be25854f07931832e48876d686eaf6a00cf4`, `go.sum` SHA256 `f3d9b4bb3a72b0e241e8f90700e72fe6368e44df1a4b6ca4b2ab92cd825311ec`. The only normalization is the exact prepared-source path in three local `replace` statements. Each arm/arm64/amd64 generated graph was compared byte-for-byte after that normalization. Source and generated module graphs were separately preflighted via `go list -m -json all` with `GOPROXY=off`, then `go mod verify` passed before bind.
- Final build-recipe output `/private/tmp/n42-task16c-go/rebuild-v3/evm.aar`, SHA256 `23da7d12133b272e56a15cc5a9a6bce4844a75c4ff176d0c7106d114e9900eea`, 41,051,318 bytes, below normal Git's 100MiB object limit. Three ABI members exist. `task-16c-logs/rebuild-v3-elf-audit.json` checks both 64-bit ELF LOAD and GNU_RELRO, 2/2 pass; ZIP/device and whole app checks remain separate. This is the only current candidate for subsequent scan/runtime; earlier `b91aec`, `c7e4` and failed-recipe `a4b4` AARs are historical outputs.

## Exact commands and outcomes

From the app worktree root, fresh source preparation command is in `task-16c-platform-source-report.md`. Then:

```sh
N42_ALLOW_PUBLIC_MODULE_FETCH=yes /bin/bash tools/android_native_smoke/go_evm_v5_7_906/prefetch_android_modules.sh /private/tmp/n42-task16c-go/android-recipe-v3 /private/tmp/n42-task16c-go/modcache /private/tmp/n42-task16c-go/prefetch-v3b
/bin/bash tools/android_native_smoke/go_evm_v5_7_906/build_android_aar.sh /private/tmp/n42-task16c-go/android-recipe-v3 /private/tmp/n42-task16c-go/modcache /private/tmp/n42-task16c-go/bin /Users/jieliu/.codex/toolchains/android-sdk-37 /opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home /private/tmp/n42-task16c-go/rebuild-v3
python3 scripts/audit_android_native.py /private/tmp/n42-task16c-go/rebuild-v3/evm.aar
```

`task-16c-logs/prefetch-v3b.log` exit0, source/generated offline JSON graph outputs in `/private/tmp/n42-task16c-go/prefetch-v3b/`. Public fetch requires explicit flag; `prefetch-no-opt.log` exit5 before output. `task-16c-logs/build-recipe-v3.log` exit0, detailed input/Go verification/bind/generated graph sidecars under `/private/tmp/n42-task16c-go/rebuild-v3/`. `task-16c-logs/build-recipe-existing-output.log` exit3 before replacement. `bash -n` for all three recipe scripts exit0, recorded in implementation transcript. ELF audit above exit0.

Two failed attempts remain evidence, not passing gates: `task-16c-logs/build-recipe-v2.log` exit1 after AAR creation because generated arm graph contained one additional `google.golang.org/genproto/googleapis/rpc` selected module; the recipe correctly rejected graph drift. The generated template was then frozen from the fully prefetched graph, with no version/checksum normalization. `task-16c-logs/prefetch-v3.log` exit7 because `go mod download all` adds authentic checksums for otherwise unused modules to the preflight copy of generated `go.sum`; the revised prefetch verifies original checksum lines remain unchanged, records the expanded sum hash, and leaves the source lock unchanged. Neither failed output is accepted.

Remaining: final AAR hash Java descriptor and Go metadata checks, independent exact-hash binary scan, offline synthetic device protocol/strict16KB, app integration and release APK/AAB/whole native audit. This build does not prove live validator acceptance or settle exact-source redistribution requirements.
