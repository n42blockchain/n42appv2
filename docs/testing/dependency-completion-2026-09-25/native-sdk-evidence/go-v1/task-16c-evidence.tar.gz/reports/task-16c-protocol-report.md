# Task 16C protocol and binding source slice — 2026-09-26

Commit `b5939303b` (`test: characterize Go mobile Emit protocol`) adds a hash-checked overlay to the fixed public `5083c29735acfc7023ab1fbbd6d6527b7b97cbae` source recipe. The hook bumped only `pubspec.yaml` from `2.4.8+2026072886` to `+2026072887`. No app AAR, Gradle edge, or production SDK code changed in this commit.

## RED and source finding

`gomobile bind -v -target=android/arm,android/arm64,android/amd64 -androidapi=26 -tags=nosqlite,noboltdb ./cmd/evmsdk` returned **1** in `task-16c-logs/gomobile-build-1.log`: gobind rejects exported `GenerateMobileBLSKey` and `DecodeWireHeader` because their signatures have multiple result values. The app-wide Kotlin/Java source audit (`rg 'import evmsdk|Evmsdk\.|evmsdk\.' android plugins tools --glob '*.{kt,java,gradle,kts}'`) found only `FlutterMiningPlugin.kt:42` and `TransactionSignerHandler.kt:242`, both calling `Evmsdk.emit(paramsJson)`. Static `javap -s` of the old AAR shows `evmsdk.Evmsdk.emit(Ljava/lang/String;)Ljava/lang/String;`.

The overlay adds `cmd/evmsdk/mobilebind`, a package named `evmsdk` with only `Emit` exported; it forwards to the original engine and leaves upstream Go functions intact. An attempted direct `gobind` from the recipe-only source returned **1** in `gobind-protocol-prepared.log` because that source slice does not yet contain the pinned x/mobile tool graph. A later candidate with pinned tool graph generated `java/evmsdk/Evmsdk.java` with `public static native String emit(String request);`, but compiled AAR `javap` remains pending.

## GREEN and negative control

- `/bin/bash tools/android_native_smoke/go_evm_v5_7_906/prepare_source.sh /Users/jieliu/Documents/n42/N42-gov5 /private/tmp/n42-task16c-go/protocol-recipe-test` returned **0**, `prepare-protocol-positive.log`. It checked original Go mod/sum, `source.patch`, and exact SHA-256 for each of the three overlay files before copying.
- From that freshly prepared source, `GOTOOLCHAIN=local GOFLAGS=-buildvcs=false GOCACHE=/private/tmp/n42-task16c-go/gocache GOMODCACHE=/private/tmp/n42-task16c-go/modcache GOPROXY=off GOSUMDB=off /Users/jieliu/.codex/toolchains/go-1.26.8/go/bin/go test ./cmd/evmsdk/mobilebind ./cmd/evmsdk -run 'TestEmitDelegatesToEngine|TestAppEmit|TestEmitDoesNotLog|TestWebSocketServiceForwardWritesDeliversWrappedRequest' -count=1 -v` returned **0**, `emit-contract-prepared-green.log`. This covers idle state, repeat stop, initial and partial setting, malformed JSON/key/message input, low/high synthetic key output type/length, redaction, local WebSocket framing, and facade delegation. It does **not** establish old/new crypto byte identity.
- Copying the recipe and appending a comment to `protocol/mobilebind/emit.go`, then running its `prepare_source.sh` with a new output path, returned **11 expected** and did not create the output, `prepare-protocol-tamper.log`.
- `/bin/bash -n prepare_source.sh` and `git diff --cached --check` returned **0** before commit. The proposed English subject was checked for Chinese characters.

## Remaining scope

This is source characterization only. Canonical candidate build is still handling fixed-tool graph, Go 1.26.8/Android compatibility, actual 3-ABI AAR, old/new native BLS vectors, offline emulator tests, linked security/license inventory, and 16 KB artifact inspection. No `start` or remote validator was called. All logs named here are in ignored `.superpowers/sdd/dependency-completion-20260925/task-16c-logs/`; the durable evidence archive remains to be created after the scoped build/runtime work.
