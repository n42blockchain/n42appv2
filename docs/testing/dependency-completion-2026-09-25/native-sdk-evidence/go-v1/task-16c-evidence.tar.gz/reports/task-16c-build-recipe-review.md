# Task16C build recipe review

Committed range `54185d01a..dd19b79d4`. Scope: source/generated graph prefetch, offline build recipe, normalization/checksum policy and retained candidate evidence. Source group was independently accepted in `task-16c-platform-source-review.md`; app AAR integration and later mutable work are excluded. No builds/tests/native execution, source edits or child agents were performed.

## Verdict

- **Spec compliance: CHANGES REQUIRED** — the claimed NDK pin and offline/public-fetch environment policy are not fully enforced.
- **Code quality: CHANGES REQUIRED** — two concrete P2 environment-selection defects below.
- These findings concern future/reused recipe invocations. They do not establish that the retained successful build used the wrong compiler or accessed the network.

## Findings

### P2 — Enforce the NDK selected by gomobile, not just existence of a versioned clang

Location: `tools/android_native_smoke/go_evm_v5_7_906/build_android_aar.sh:35-38,50-56`.

The recipe checks that `$android_sdk/ndk/28.2.13676358/.../clang` exists, but exports only ANDROID_HOME / ANDROID_SDK_ROOT. It neither overrides inherited ANDROID_NDK_HOME nor pins gomobile's NDK lookup. The exact selected gomobile `cmd/gomobile/env.go:396-425` first accepts inherited ANDROID_NDK_HOME and otherwise chooses the newest compatible side-by-side NDK. Consequently, with a valid28.2 installation plus inherited29.x (or a newer installed NDK), every recipe input check can pass while gomobile invokes another compiler. The final generated go.mod/go.sum checks do not detect this.

Required correction: explicitly export the checked absolute NDK directory, validate its source.properties revision, and record the actual selected NDK/clang identity in run inputs. Keep the three ABIs and link flags. Add selective negative/environment tests showing a different inherited NDK cannot select a different toolchain, missing/wrong revision fails before binding, and a valid pinned installation wins even with an unrelated newer SDK NDK present. These tests can exercise selection/preflight without a full SDK rebuild. Do not retroactively state the prior log had a compiler identity it did not record.

### P2 — Clear inherited module-routing exemptions before claiming offline/public-proxy enforcement

Locations: `build_android_aar.sh:51-55` and `prefetch_android_modules.sh:45-47,70`.

Setting GOPROXY=off is insufficient when GONOPROXY (or GOPRIVATE's default influence) is inherited from the shell or persistent Go environment. In installed Go1.26.8, `cmd/go/internal/modfetch/proxy.go:63-65` prepends a `noproxy` route before processing GOPROXY; `modfetch/repo.go:261-267` sends matching module paths to `lookupDirect`. Thus an inherited `GONOPROXY=*` with missing cache inputs can cause direct VCS/network resolution despite the recipe's offline marker. The same route bypasses the prefetch script's explicit public proxy; inherited GONOSUMDB / GOPRIVATE can also bypass its promised checksum database verification. Neither script disables persistent GOENV settings or clears these routing exemptions.

Required correction: establish the module-routing environment explicitly in both scripts (including GOENV policy, GOPRIVATE, GONOPROXY and GONOSUMDB) before Go commands, then set the intended proxy/sumdb policy. Keep public prefetch authorization separate from offline build. Add a focused configuration/command-capture negative control with inherited `GONOPROXY=*`, GOPRIVATE/GONOSUMDB and a custom GOENV file; assert those settings cannot produce a direct fetch route or disabled verification. No live remote fetch or complete native rebuild is required to test the environment setup. A truly isolated-network claim would additionally require network isolation; these scripts currently implement module-fetch policy, not an OS network sandbox.

## Checks that passed

- Explicit input hashes, existing output refusal and full-build failure checks are present. Full source preparation remains the prior group's responsibility; this recipe consumes its prepared source and checks final module-file hashes.
- Independently hashed committed generated template (`9ad07b22d3153642defe0f1fc4b8be25854f07931832e48876d686eaf6a00cf4`) and sum (`f3d9b4bb3a72b0e241e8f90700e72fe6368e44df1a4b6ca4b2ab92cd825311ec`). All three retained normalized arm/arm64/amd64 module files and sum files are byte-identical to those committed inputs.
- Normalization replaces only the supplied source-directory string. Equality against the fixed template, which contains three local replacement positions, preserves selected versions and checksums; it does not ignore dependency version drift.
- Prefetch checksum expansion is confined to the separate generated-graph copy. The retained copy has1002 checksum lines versus508 committed lines, with **zero missing original lines**. The later actual per-ABI build comparison still requires the exact committed508-line sum. This is a reasonable separation of cache prefetch from produced graph acceptance, subject to fixing the public verification environment above.
- Source and generated graphs are preflighted separately; `go-mod-verify.log` says all modules verified. The final exact generated graph check occurs after AAR creation and can reject that output: failed-v2 output must remain rejected, as the report states.
- Independently read/hash-checked `/private/tmp/n42-task16c-go/rebuild-v3/evm.aar`: **41,051,318 bytes**, SHA256 `23da7d12133b272e56a15cc5a9a6bce4844a75c4ff176d0c7106d114e9900eea`, matching report and inputs. Final recipe log records all three generated graphs exact. Existing ELF JSON reports two64-bit libraries checked, zero failures, explicitly limited to LOAD/GNU_RELRO.
- The recorded command preserves arm/arm64/amd64, API26, nosqlite/noboltdb, portable BLST, both16KB link flags, trimpath and stripped output. No app AAR or Gradle integration changed. README/report correctly leave actual Java descriptor, new-hash scan/runtime, app release packaging and licensing acceptance open.

## Evidence limits and follow-up scope

`inputs.txt` binds final AAR hash and graph pins but does not record actual selected NDK/clang or a sanitized effective module-routing environment. This is why the above are recipe defects, not assertions that the historical artifact failed. Retained short GREEN/negative logs and reported exit codes should be carried into the later durable archive with exact command/input identity. No duplicate full build is requested for the two environment-selection fixes; a subsequent changed AAR still needs its own applicable acceptance evidence. Source/platform approval remains separate and unchanged.
