# Task16C anet IPv6 zone advisory inputs

Read-only preparation, 2026-09-26. Inspected the mutable task-owned `/private/tmp/n42-task16c-go/source/third_party/anet`, selected module sources, retained Android dependency list and generated gomobile module mapping. No edits outside this report, builds, tests, device or SDK/network execution. This is advisory preparation, not final commit review.

## Decision summary

Removing the private cache writes is **not universally behavior-preserving**: on Android11+ where standard Go interface discovery is denied, a named IPv6 zone such as `%wlan0` can become scope ID0. A decimal interface index still works through public Go APIs. This is a concrete source-level conditional risk, not demonstrated failure of the current mobile V1 route.

The current mobile import graph contains Pion/anet, but two inspected runtime routes do not establish use of the removed side effect: geth NAT calls `stun.Dial` (direct `net.Dial`, not `stdnet.NewNet`), and mobile libp2p explicitly selects TCP+QUIC rather than default WebRTC. Don't claim either that all IPv6 is broken or that the patch preserves every consumer. If an actual SDK consumer uses named zones after anet enumeration, normalize those zones to public interface indices at that consumer's socket boundary. Don't disable Go's linkname checks, drop IPv6, rename network interfaces or restore private memory-layout writes.

## Exact delta and Go behavior

Selected `source/go.mod` has anet0.0.5 replaced by `./third_party/anet`; Pion transport/v4 is4.0.2, ICE/v4 is4.3.0, STUN/v3 is3.1.6, and x/net is0.59.0. Relative to the pristine module cache, `interface_android.go` removes:

- `zoneCache.update(ift, true)` and `zoneCacheX.update(ift, true)` after successful Interfaces / InterfaceByName enumeration;
- copied private cache structure/method and `//go:linkname` aliases to `net.zoneCache` and `golang.org/x/net/internal/socket.zoneCache`;
- now-unused sync/time imports.

The Android API detector, interface/address enumeration and netlink workaround remain. Interfaces uses `net.Interfaces` below API30; API30+ uses anet's RTM_GETADDR-based discovery. The [official anet0.0.5 source](https://raw.githubusercontent.com/wlynxg/anet/v0.0.5/interface_android.go) confirms these were intentional shared-cache updates, not unused declarations. Upstream README's `-checklinkname=0` advice is not an acceptable substitute for a supported API path.

Pinned Go1.26.8 source under `/Users/jieliu/.codex/toolchains/go-1.26.8/go/src/net` establishes the behavior:

| Source | Consequence |
| --- | --- |
| `interface_linux.go:16-20` | Go interface discovery issues RTM_GETLINK. Android11 app restrictions prohibit that operation; exact device denial was not tested here. |
| `interface.go:197-220` | Zone-cache refresh uses that discovery. An error leaves lookup unable to learn anet's successfully enumerated names/indices. |
| `interface.go:244-262` | On name-cache miss, `index` attempts decimal parsing. `wlan0` is not numeric and resolves to0; `7` resolves to7. |
| `interface.go:224-241` | Reverse lookup falls back to the decimal index when a name is unavailable. |
| `ipsock_posix.go:183-205,266` | IPv6 sockaddr `ZoneId` comes from the cache's index conversion for string zones / netip zones. |
| `udpsock_posix.go`, `tcpsock_posix.go` | Received/local socket addresses can consequently expose numeric rather than named zones. |

The public [Go source](https://go.dev/src/net/interface.go) documents the same cache fallback, and [Android's official API restriction description](https://developer.android.com/identity/user-data-ids#mac-address-availability-changes-in-android-11) confirms the RTM_GETLINK restriction. The precise installed source above is authoritative for this candidate.

`x/net@v0.59.0/internal/socket/sys_posix.go:127-184` separately refreshes through `net.Interfaces`; its index fallback uses `strconv.Atoi`, and reverse lookup uses `strconv.Itoa`. `sys_unix.go:82` / `sys_posix.go:59` feed that result into socket scope IDs. Therefore merely preserving one cache would not preserve all previous behavior, and calling public `net.Interfaces()` to “prime” caches cannot solve the failure where that call is restricted.

This concerns scoped IPv6 (especially link-local unicast/multicast). IPv4 and ordinary unscoped global IPv6 do not require this name→scope conversion. Exact bind/dial errno/routing consequences depend on the socket/address and device; a runtime failure has not been reproduced by this preparation.

## Actual consumers and reachability limits

The retained `task-16c-logs/deps-android-arm64.txt` includes anet, transport/v4/stdnet, ICE and WebRTC. The retained build-5 generated `src-android-arm64/go.mod` replaces the SDK module with `/private/tmp/n42-task16c-go/source`. This proves package selection, not invocation of every package's functions or that the old unprovenanced AAR contained anet.

1. **Direct anet consumers:** selected `pion/transport/v4@v4.0.2/stdnet/net.go:40-61` invokes anet.Interfaces and InterfaceAddrsByInterface in `UpdateInterfaces`; `NewNet` invokes that update. The deleted private cache writes used to affect later ordinary socket operations process-wide. Transport v2/v3 copies also exist in module cache but are not evidence of selected v4 usage.

2. **Concrete conditional affected consumer:** `pion/ice/v4@v4.3.0/agent.go:487` creates stdnet by default; `net.go:98` passes `iface.Name` into `parseAddrFromIface`. `addr.go:12-33` adds that name as the zone for IPv6 link-local addresses enumerated as `net.IPNet`. `gather.go:431-440` passes `addr.Zone()` into `ListenUDP`, which `stdnet/net.go` forwards to Go. With unresolvable names, the kernel receives scope0 instead of the interface index and binding can fail, losing that interface's candidate. This code creates listeners even when location-tracked candidates are not publicly advertised (`gather.go:459-461`); the candidate filtering policy is not proof the socket path cannot occur. Remote scoped destinations and x/net batch socket writes have the corresponding conversion risk.

3. **Current geth NAT route is different:** `go-ethereum@v1.17.4/p2p/nat/stun.go:114` calls STUN `Dial`. `pion/stun/v3@v3.1.6/client.go:30-36` directly calls `net.Dial`. Only its separate `DialURI` path at55 creates stdnet. Thus the suggested import chain `internal/devp2p → geth NAT → Pion STUN → stdnet → anet` is a valid package dependency explanation but is **not** a demonstrated call chain that primes the cache. A named-zone custom STUN endpoint can have the general Go problem, but this route alone did not previously invoke anet's removed side effect.

4. **Mobile libp2p setup:** `source/internal/p2p/options.go:69-79` explicitly installs TCP and QUIC transports; libp2p0.48.0 `defaults.go:159-165` installs default transports only when Transports is nil. WebRTC packages being imported by libp2p defaults does not make the mobile host instantiate WebRTC. The other source-tree WebRTC fetcher is enabled through the separate `cmd/eth-el` CLI; its constructor/call path was not found in the mobile SDK entry. Neither that fetcher nor `internal/cl/p2p` appears in the retained mobile package list. No app-live ICE invocation was established here.

## Minimal public-API alternative when needed

There is no exported Go API to inject anet's interface table into either private cache. Keeping anet enumeration while ensuring correct scoped operations requires explicit conversion where scoped addresses are constructed/used:

- If the interface is already known (the ICE local-interface loop), use `strconv.Itoa(iface.Index)` as the socket zone for link-local addresses. Keep `iface.Name` separately for user interface filters, labels and interface selection. This avoids a second lookup and preserves real interface names.
- For caller-supplied named zones, resolve via public `anet.InterfaceByName`, validate a positive index, and copy the address with a decimal zone before `net` / x/net socket operations. Preserve empty zones and valid decimal zones; reject unknown names explicitly rather than silently falling back to zero. Parse host/port and IPv6 zone structurally, not by naive string replacement.
- For a transport.Net adapter, cover both local/remote UDP/TCP addresses, string Dial/Listen operations, and returned connection WriteTo / batch-write paths as actually used. A Dial-only normalizer is not a universal patch. Numeric receive zones should remain valid for reply writes; do not assume every returned zone string is an interface name.

For the current mobile SDK, first freeze the above call-graph limitation in the platform report. Do not launch broad Pion changes solely because anet is in go.mod. If future/actual mobile ICE use is established, the known-interface numeric-zone change is the smallest identified repair; a general named-zone API guarantee needs a bounded adapter and tests. Retaining a documented limitation is not a claim of full anet replacement compatibility.

Suggested bounded later checks: pure fixtures with anet-derived interface `{Name:wlan0, Index:7}` and synthetic `fe80::1`, verifying preservation of names/filter behavior plus socket Zone=`7`; input empty/numeric/name/missing-name cases; unchanged IPv4/globalIPv6; receive-zone/reply symmetry. An isolated offline Android fixture can verify actual scoped bind/send with real available interfaces and source-only test controls, but no validator or remote server is necessary. Record net.Interfaces failure separately from anet enumeration success; an environment where both succeed cannot reproduce the cache-removal condition. None of these tests was run by this investigation.
