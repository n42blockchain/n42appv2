# Task16C candidate source/logging slice review

Scope: `391910e2a..410a62b4f825a961c918b10445135aa717f0de61`, against the first source/logging gate in `task-16c-go-sdk-brief.md`. Read the committed recipe/patch, canonical Git objects, isolated prepared source, detailed report and existing RED/GREEN/recipe logs. No Go tests, native builds, validator or device operation rerun; sibling checkout was read only.

- **Spec compliance: PASS for this source slice.** Canonical identity, initial request-value redaction and bounded regression evidence are satisfied.
- **Code quality: PASS.** No blocking concrete finding in the reviewed increment.
- This is not final Task16C acceptance: no AAR/integration change, ABI compatibility, cryptographic old/new equivalence, security-scan, license or release approval is inferred.

## Exact source and recipe

`tools/android_native_smoke/go_evm_v5_7_906/prepare_source.sh:4-7` pins commit5083c29735acfc7023ab1fbbd6d6527b7b97cbae, original module inputs and reviewed patch digest. It references the object hash, not the stale same-name local tag. Independently read the commit object/tree: `454a5c991f2943efef8131a6b75ec4af6c831570`. Canonical `go.mod`/`go.sum` hashes equal the pins and the isolated candidate bytes. The tracked patch hashes `8ce074b989d01fa83ecb3c5878d08140cd6d6b109ea0bb8f0ddc05618aaa617b` as declared.

Critical refusals are explicit condition/exit branches: arguments10-13; source Git metadata16-19; existing output20-23; absent exact commit24-27; changed patch29-32; archive failure35-38; changed module inputs41-44; dry-run/apply failures45-52. No bare comparison depends on Bash3.2 errexit. Extraction is a read-only `git archive` from the source repository; patching occurs after `cd` to the new output. There is no sibling fetch/reset/tag/config/index mutation.

The positive replay log reports all four fixed identities and patch application. Independently compared prepared candidate and replay `common.go`/new test: byte-equal; patched common SHA is `bff5ef66458be1444f69b02dd464f5dfb81370e21610046df5b3ca2cba593024`.

`prepare-missing-repo.log` and `prepare-existing-output.log` contain the intended refusal diagnostics. The report clarifies **expected exit3 and exit4**, not a3/4 pass rate; code paths visibly use those exit values. The files themselves contain diagnostics, not numeric exit metadata, so exact observed statuses are attributed to the implementer's report. Both checks precede mkdir/extraction. Other failure branches were inspected, not claimed as negatively executed.

## Secret redaction and protocol preservation

`source.patch:4-16` makes the only production-source change: the pre-dispatch `simpleLog` no longer receives `eq.Val`, retaining only operation type. In canonical `cmd/evmsdk/common.go`, the call occurs before `Setting` applies `log_level`; default `isDebug=true` therefore exposed initial `priv_key` values upstream. `simpleLog` sends the same argument list to stdout and `log.Debug`, so redaction covers both sinks by code inspection.

Tests at `source.patch:20-91` call actual `Emit`, reset `EE/isDebug` to initial-debug state, capture stdout and reject full synthetic32-byte secret strings for initial `setting` and `blspubk`. They restore globals/stdout and use no `start`, endpoint or real account. The initial setting requests empty log level, testing the specific before-log-level window. Tests are serial; no parallel test mutation was found in this package scope.

The retained RED log shows both intended secret-leak assertions failing after compilation; MDBX warning is not the failure cause. GREEN shows2/2 passing. The patch does not modify JSON parsing, dispatch, `Setting`, `EmitResponse`, `emitJSON`, BLS derivation or WebSocket formatting. Inspection of the immediate setting/BLS request/response paths found no second raw `priv_key` logging call; `emitJSON` marshals/returns response without logging it. This is not a whole-repository logging audit.

The existing dispatch test verifies parsed response code/data against `BlsSign`; the existing framing test exercises local `forwardWrites` with an injected send callback and exact `eth_submitSign` JSON, without dialing a remote connection. `emit-and-framing-green.log` shows5/5 selected tests passing: invalid JSON, BLS dispatch, both new secret tests and framing. These checks support unchanged local protocol behavior for this narrow patch, not all live Emit commands or server acceptance. Existing direct BLS comparison is not an independent cryptographic oracle; later Task16C vectors remain necessary.

## VCS provenance and remaining scope

The inspected candidate `/private/tmp/n42-task16c-go/source` is outside the app worktree and has no `.git`. README explicitly requires `GOFLAGS=-buildvcs=false` for Go commands; the report records that setting for every test. The preparation script itself does not enforce an outside-app destination, so future callers must retain the documented task-owned path and the eventual build script must enforce/record VCS handling. No Android build has occurred in this slice, and no claim of actual erroneous app-revision stamping is made.

Selected Go tests and source preparation are not a mobile build recipe. Preserve the canonical source/patch/module identity and explicitly disable misleading VCS stamping when adding that later recipe. Three shipping ABIs, live V1 preservation, secret-safe additional Emit cases, independent BLS/amount vectors, security/dependency/license evidence and durable archive remain the subsequent Task16C gates. Current ignored logs are acceptable intermediate source-review inputs; the brief still requires durable publication before complete task acceptance.

The scoped `.gitattributes` treats whitespace within the unified patch as patch data. No source/formatting issue is inferred from its context tabs/blank lines. The accompanying pubspec increment is the hook's build-number change only.
