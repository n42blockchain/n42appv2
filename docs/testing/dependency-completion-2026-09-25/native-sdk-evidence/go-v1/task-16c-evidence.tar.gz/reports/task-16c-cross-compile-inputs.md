# Task16C cross-compile failure inputs

Read-only investigation, 2026-09-26. Scope: `task-16c-logs/gomobile-build-5.log`, task-owned `/private/tmp/n42-task16c-go/source` and its module/tool inputs. No source/index edits, builds, tests or device calls were performed. This is a diagnosis and candidate repair, not acceptance of the implementer's mutable source or a completed AAR.

## Conclusion

There are **two independent target-specific source portability errors**. ARMv7 fails because artificial 48-bit Go array capacities cannot fit its `int`; BLST's signal initializer fails on Android x86_64 because Bionic's first `sigaction` field is an integer. Neither requires dropping an ABI, suppressing diagnostics, removing the SIGILL check, or changing cryptography.

### 1. ARMv7: artificial array lengths exceed target int

Observed build-5 failures:

- `source/lib/mmap/mmap_unix.go:31` sets `MaxMapSize = 0xFFFFFFFFFFFF`. Public mmap return/handle types at lines34/39/43/70 and the unsafe conversion at51 use `[MaxMapSize]byte`.
- `source/lib/recsplit/eliasfano16/elias_fano.go:234` uses the same constant. Single-EF Write/Read at214/228 and Double-EF Write/Read at513/528 cast to `[maxDataSize]byte` or `[maxDataSize/8]uint64`.

Go requires an array's constant length to be representable by target `int`; 281474976710655 and its eighth are not representable on ARM32. These pointer casts do not actually allocate 256TB, so reducing an artificial capacity to the addressable bound is the narrow fix. [Go array specification](https://go.dev/ref/spec#Array_types).

Candidate constant for each Android-relevant definition, supported by the selected Go1.26 compiler:

```go
const MaxMapSize = min(0xFFFFFFFFFFFF, uint64(^uint(0)>>1))
// Likewise maxDataSize in eliasfano16.
```

This yields 2^31−1 on32-bit and preserves 2^48−1 on64-bit. Explicit32/64 build-tag constants are another valid implementation. The `uint64` conversion is intentional: `min(0xFFFFFFFFFFFF, int(^uint(0)>>1))` would first attempt the overflowing conversion of the large literal to32-bit int. This candidate has not been compiled by this investigator.

Keep the mmap pointer API and callers intact: `lib/seg/decompress.go`, `lib/recsplit/index.go`, `internal/ethel/codes_hash_index.go`, `internal/ethel/snapshotreader/reader.go`, `internal/cscompact/segment_store.go` all name `*[mmap.MaxMapSize]byte`. The Windows file has its own48-bit constant but is not in the Android build; avoid an unrelated Windows port during this repair. No serialized EF header, word order or read/write framing should change.

Acceptance for the implementer: reproduce compile failure on ARM before patch and cross-compile both packages afterward; preserve64-bit values; add deterministic Single/Double EF **Write→Read** round trips and baseline byte comparison, and small-file mmap read/read-write/unmap checks. Existing `elias_fano_fuzz_test.go` exercises construction/lookups but contains no serialization calls, so its seed passes alone would not prove serialization preservation. Ensure length multiplication / derived word counts cannot silently wrap in any newly added validation; don't claim this constant-only patch fixes pre-existing unsafe aliasing or malformed-input handling. It must not intentionally permit mappings beyond process-addressable length.

### 2. BLST: positional sigaction initializer is invalid on Bionic LP64

Selected module: `github.com/supranational/blst v0.3.17`; `source/go.sum` records `h1:OyduggShfN3CWEDdrqChEUZyt1iIsVAFApTKSzqoxAo=` (go.mod `h1:jZJtfjgudtNl4en1tzwPIV3KjUnQUvG3/j+w+fVonLw=`).

`modcache/github.com/supranational/blst@v0.3.17/bindings/go/blst.go:20-36` conditionally includes its SIGILL constructor only for `__x86_64__ && (__unix__ || __APPLE__)`. At31 it initializes `struct sigaction act = { handler }, oact;`. The same source appears in generating template `bindings/go/blst.tgo:27` and in the [official tagged template](https://raw.githubusercontent.com/supranational/blst/v0.3.17/bindings/go/blst.tgo).

Actual NDK header `/Users/jieliu/.codex/toolchains/android-sdk-37/ndk/28.2.13676358/toolchains/llvm/prebuilt/darwin-x86_64/sysroot/usr/include/bits/signal_types.h:101-122` defines LP64 `struct sigaction` with **`int sa_flags` first**, then the handler union. Thus `{ handler }` tries to assign a function pointer to `int`, exactly matching the diagnostic. The error is from the x86_64 conditional path, even though the interleaved gomobile log ends with an ARMv7 command failure. There is no evidence here that ARM was accidentally compiled with x86_64 macros.

Minimal candidate: use `struct sigaction act = { .sa_handler = handler }, oact;`, or zero-initialize `act` then assign `act.sa_handler = handler`. Keep install/probe/restore and the handler unchanged. Do not cast the pointer to int, disable the constructor, or add `-Wno-int-conversion`: those would leave a broken signal action or remove its diagnostic protection. The existing `__BLST_PORTABLE__` does not alter C struct field layout and cannot fix this initializer.

Apply a reproducible task-owned module patch/replacement, retaining the exact upstream module/checksum and license; don't edit the module cache as the final build recipe. Patch the `.tgo` template and regenerate `blst.go` with its `generate.py`, checking the resulting diff remains bounded (or retain a deterministic verified template/output patch if generator prerequisites prevent regeneration). New generated output must stay consistent with the source template. A moving-master dependency is unnecessary; the inspected master template still showed the positional initializer and is not a pinned repair.

Acceptance: isolated exact-target BLST package cross-compiles for ARMv7, arm64 and x86_64 using the actual NDK/API; retain an x86_64 prepatch failure and postpatch success to attribute this fix. Run existing offline BLS known-answer/signature positive and negative vectors in the implementer's bounded validation. Cross-compilation proves portability, not device load or cryptographic correctness by itself. `src/vect.h:28-35` already selects32-bit limbs and `__BLST_NO_ASM__` on ordinary32-bit targets; no blanket no-asm change is justified by this error.

## Actual build inputs and target attribution

The sole implementer supplied the build-5 command/environment; `gomobile-build-5.log` itself records the flags/ABI build tail but not a full environment preamble. Preserve this distinction when archiving evidence.

- Go1.26.8; task-owned `bin/gomobile`, module `golang.org/x/mobile v0.0.0-20260908204917-8b95e45f8d3e`.
- `GOFLAGS=-buildvcs=false`; task-owned GOCACHE/GOMODCACHE; `GOPROXY=off`, `GOSUMDB=off`; Android SDK37, NDK28.2.13676358 and JDK21.
- `CGO_CFLAGS=-D__BLST_PORTABLE__`; `CGO_LDFLAGS=-Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384`.
- Command: `gomobile bind -v -work -target=android/arm,android/arm64,android/amd64 -androidapi=26 -tags=nosqlite,noboltdb -trimpath -ldflags='-s -w' -o /private/tmp/n42-task16c-go/evm-candidate.aar ./cmd/evmsdk/mobilebind`.

Pinned gomobile `cmd/gomobile/env.go:168-197` sets GOOS=android, per-ABI GOARCH, CGO_ENABLED=1, and NDK clang/clang++ with target-specific flags; ARM gets GOARM=7. `ClangFlags()` constructs the target at575 onward. Config entries617-654 map arm→armv7a-linux-androideabi26, arm64→aarch64-linux-android26 and amd64→x86_64-linux-android26. Android setup does not replace the supplied CGO_CFLAGS/LDFLAGS. BLST adds its own include paths, CGO macro and no-builtin flags; amd64 additionally uses `-D__ADX__ -mno-avx`.

The implementer's independently running `task-16c-logs/blst-arm-isolated.log` already exposes actual clang `--target=armv7a-linux-androideabi26`, `-marm`, portable C flags and both16KB linker flags. That corroborates correct ARM target selection for the isolated command; this investigation does not claim its eventual exit status or substitute it for the missing x86_64-specific failure control.

These are compile blockers before final ELF production. Keep all three requested ABIs and the existing page flags; after repair the produced AAR still needs per-ABI ELF/JNI and offline behavior acceptance. Neither constant adjustment nor the C initializer proves RELRO alignment or live V1 acceptance.
