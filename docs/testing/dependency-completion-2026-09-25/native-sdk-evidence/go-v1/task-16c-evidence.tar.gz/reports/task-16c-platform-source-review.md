# Task16C platform source review

Range: `b5939303b8da5e71c78028ae055b4f3f5bb3a76b..54185d01a`. Reviewed committed Git blobs, scoped diff/report, prepared source and retained evidence. Separate mutable build-recipe work, AAR integration and licensing investigation are excluded. No build/test/native reruns, tracked edits or child agents.

## Verdict

- **Spec compliance: PASS for this bounded source/platform group.** Exact source reconstruction and minimal portability changes are present; binary integration and remaining acceptance gates remain explicitly open.
- **Code quality: PASS.** No new concrete blocking defect found in the committed increment.
- **Findings requiring revision: none.** The anet named-zone limitation remains a documented compatibility boundary, not a solved generic replacement guarantee.

## Reviewed changes and evidence

### Source preparation / explicit rejection

`prepare_android_source.sh:13-31` rejects existing output and missing/unhashable/mismatching inputs with explicit exits. Lines34-45 verify every new patch/test and both module ZIPs before invoking the existing canonical source recipe. Lines47-54 reject source preparation / patch failures. Lines59-79 enforce extraction and both local-module patches; lines82-95 reject existing test paths, copy failures and wrong final module-file hashes. No compiler or network operation is hidden inside this source-only preparation and no sibling source mutation is introduced.

Independently recomputed committed hashes for all seven `android/` patch/test inputs: all match the recipe. Independently hashed the cached anet0.0.5 ZIP (`5d6e471c…d50d02a`) and BLST0.3.17 ZIP (`898d1f5c…eed2b`): both match. Prepared `android-recipe-v3/go.mod` and `go.sum` match final expected hashes `4639b00890c7a3a4f74760f7d94241cb093eb3e9bc06df7161b238cc99b8dd02` and `0cddda5969568083ac76e023426edb81107ae6ad598587867786a52b7a56d599`.

`prepare-android-v3.log` reaches the final prepared marker with these hashes; `prepare-v3-byte-compare.log` records eleven matching selected source/test files. Existing-directory and tampered-ZIP logs contain the intended refusal diagnostics. Their exit3/exit4 and before-output observations come from the implementer's report; the short raw logs do not themselves contain an exit-code footer. Code ordering supports those rejection paths. This is adequate scoped evidence; retain command/exit/input identity in the later durable package.

The `.gitattributes` addition targets unified-diff data only; its whitespace exception does not disable source-code checks generally. The `pubspec.yaml` increment is the documented hook effect.

### ARM capacities and serialized data

`android/source.patch:1321-1356` changes only the artificial unsafe-array constants in Unix mmap, Single/Double Elias-Fano and Golomb-Rice. `min(0xFFFFFFFFFFFF, uint64(^uint(0)>>1))` preserves2^48−1 on64-bit and selects2^31−1 on32-bit; the intermediate uint64 avoids overflowing conversion of the large literal to32-bit int. Mmap handle types/callers and serialization code remain unchanged. This does not claim to harden pre-existing unsafe buffer parsing or make impossible large32-bit mappings valid.

New tests cover:

- `android/tests/lib/mmap/mmap_portable_test.go:11-41`: temporary-file mapped write/unmap/read/unmap.
- `.../eliasfano16/serialization_portable_test.go:10-57`: Single/Double real Write→Read, exact consumed lengths, decoded values and frozen prepatch byte hashes.
- `.../recsplit/golomb_portable_test.go:11-38`: frozen output hash, word-count header and decoded Golomb values.

The two baseline logs record the same three hashes frozen by the tests. Patched host logs pass all four tests. `prepare-v3-focused-go-test.log` passes the five requested packages, including inherited Emit/redaction/protocol tests. ARM array RED logs contain the actual invalid-array-length errors. ARM GREEN logs / the report establish cross-compilation, **not execution on an ARM32 device**; the empty successful compiler logs cannot independently encode exit0. The report correctly identifies the failed CGO-disabled recsplit attempt and the relevant CGO-enabled follow-up.

### BLST template/output portability

`android/blst.patch:1-22` changes the positional initializer to `.sa_handler = handler` in both `bindings/go/blst.tgo` and its generated `blst.go`, with no other BLST change. This addresses Bionic LP64 field ordering while retaining installation, SIGILL probe and handler restoration. It does not suppress the diagnostic or disable CPU checks. Exact official module ZIP plus bounded patch reconstructs both files; this review confirms matching template/output deltas, not a claim that the generator was rerun.

`blst-amd64-red.log` contains the exact pointer-to-int initializer error. The reported x86_64 GREEN compiler exit and later all-ABI build are consistent with the source fix; the empty focused GREEN file is compiler output, not device/runtime evidence. Report attribution to x86_64 rather than the interleaved build log's final ARM failure is correct.

### Fixed modules and tool graph

`android/source.patch:1-66` records Go1.26 language level, exact x/mobile pseudo-version, both tool directives, dependent x/* versions, cilium/ebpf0.22.0 and the two local module replacements. The selected x/mobile module itself requires Go1.26.0 and the recorded x/mod0.41, x/sync0.23, x/tools0.50 and x/sys0.48 values. The broad go.sum addition records checksums; it is not proof that every listed module is linked.

Read and parsed both retained `source-modules-v2.json` and `generated-modules-v2.json`: both select cilium/ebpf0.22.0, x/mobile `v0.0.0-20260908204917-8b95e45f8d3e`, x/net0.59.0, and the expected local anet/BLST replacements. `go-get-cilium-0.22.log` records the0.21→0.22 upgrade. This review confirms the selected graph, not advisory reachability or a clean final binary scan. Full offline generated-graph/build-recipe validation and new-artifact scanning remain separate gates as reported.

### anet limitation remains explicit

`android/anet.patch` removes only the private cache links/update implementation and dependent imports, preserving Android enumeration. The earlier read-only call-path analysis remains applicable: standard Go / x/net may lose named-zone→index translation on Android11+ when RTM_GETLINK is denied, while decimal zones remain representable. The mobile TCP+QUIC and direct geth STUN paths inspected did not establish execution of the susceptible anet-primed ICE route.

`android/tests/third_party/anet/zone_portable_test.go:12-25` tests synthetic public numeric-zone representation / UDP address parsing. It does **not** call Android anet enumeration, perform a scoped socket operation or prove scope_id reaches the kernel. Its comment and the scoped report state this honestly. Do not describe it as generic named-zone parity or a device regression test. An actual future/current caller requiring named scoped addresses still needs a bounded public interface-index conversion, as documented in `task-16c-anet-review-inputs.md`.

## Remaining gates / evidence limits

The retained build8 log lists all three ABI `libgojni.so` members, but this commit does not integrate that AAR. Final build recipe/tool/environment identity, actual artifact hash and JNI descriptor, independent BLS byte compatibility, isolated native runtime, changed-library ELF/RELRO, whole-release package checks, reachable scanner interpretation and linked-source license/notice inventory remain open. No claim of old unprovenanced AAR source equivalence, live validator success or redistribution clearance is accepted here. Durable final evidence must survive deletion of ignored W; this group has not claimed that final archival step complete.
