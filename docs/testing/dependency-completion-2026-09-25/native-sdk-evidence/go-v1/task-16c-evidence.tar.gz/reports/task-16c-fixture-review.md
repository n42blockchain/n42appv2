# Task16C fixture increment review

Scope: `7b8e223c29857ee647e14e58ad0e10db62b41d5f..d905de7572cace3b58bd458f2fd5a02e5a05e587`. Read-only review of committed fixture changes, the fixture report, and retained logs. No native/device/build/test reruns; no review of current uncommitted AAR integration.

## Verdict

- **Spec compliance: PASS for this bounded fixture increment.** The actual retained evidence supports old compatibility-mode versus candidate strict16KB execution, nine local valid response matches, independent Rust binding BLS checks and actual app deposit ABI encoding. This is not final Task16C/app release acceptance.
- **Code quality: PASS with one P3 reporting correction below.** No P1/P2 defect identified in this increment. Durable evidence packaging is explicitly queued separately.

## Finding

**P3 — Comparator reports strict16KB without examining runtime conditions.** `tools/android_native_smoke/compare_go_evm_vectors.py:60` always prints “candidate ran strict 16KB” after comparing only vector records (lines 23–41, 49–60). Supplying the same old compatibility log for both arguments would also produce that assertion. Remove the mode assertion or explicitly state that mode/input/exit binding must be checked in the runner evidence. No device rerun is needed for this output-text correction. This does **not** invalidate the actual candidate run: its retained pre/post properties independently establish strict mode.

## Evidence checked

- Old `task-16c-logs/go-evm-old-runtime-2.log`: input `28a8f913...eb470`, PAGE_SIZE 16384, compatibility `true/false`, airplane=1 and failed IPv4 route probe before/after, Flutter exit 0 and strict restoration. It is correctly not claimed as strict16KB evidence. Unknown old source remains explicit.
- Candidate `task-16c-logs/go-evm-keccak-v4-runtime.log`: input `a7f1e012...d258c`, PAGE_SIZE 16384, linker `fatal`, package compatibility disabled `true`, airplane=1/failed route probe before/after, Flutter exit 0 and successful cleanup. APK `70fa2c8f...056f`; input member `c81ca645...4762`; stripped and packaged arm64 member both `7f0c14b8...61c6`. Independently read the existing candidate AAR: SHA256 and 41,052,430-byte size match the report.
- Both runtime logs' runner, Kotlin, Gradle and Dart test hashes exactly match their **committed d905de757** bytes. The logged parent commits precede the fixture commit, so the per-file hashes, not an assumption of a clean parent tree, identify the executed fixture. Historical Task16B manifest files are absent from this diff.
- All nine valid raw response strings are equal across the two logs, in addition to the comparator's parsed-object match. `go-evm-valid-vector-negative.log` reports the intended lowPubkey mismatch. Old one-byte key acceptance versus candidate code-1 rejection is explicitly retained and excluded from valid-vector parity.
- Oracle `src/lib.rs:27–51` derives from the fixed 32-byte input using KeyGen, compares independently generated public/signature bytes, verifies the correct amount message and rejects a changed message. Its four constants exactly match both actual device vector records. `bls-oracle-green.log` reports 2/2. Independence is a separate Rust blst 0.3.15 binding/oracle versus Go blst 0.3.17, not a claim of unrelated cryptographic implementations or proof for arbitrary inputs.
- `mining_token_deposit_abi_test.dart:12–35` uses the actual `astMining` ABI and compares full calldata, offsets, dynamic lengths, padding and BLS bytes. Retained Flutter result is 1/1 and Dart analysis reports no issues. This does not test signing, on-chain acceptance, every amount-conversion boundary, or a running validator.
- `rebuild-v4-elf-audit.json` reports 2/2 checked 64-bit members passing LOAD/GNU_RELRO. This is not arm32 runtime coverage or final APK/AAB/ZIP alignment acceptance.

## Runner and scope observations

`run_go_evm_fixture.sh` checks the reviewed Go AAR hash before building, registers restoration before compatibility changes, explicitly checks mode/page/network properties, propagates Flutter failures, and compares the APK member against the declared llvm-strip transformation. Cleanup preserves a prior failure or returns failure if strict settings cannot be restored. A printed PASS line is not a substitute for the process exit/cleanup result. No failure-path runtime rerun was claimed or performed in this review.

The fixture is a debug harness. Only the Go input is selected by this runner; its exact native member is checked after packaging. Existing shared-harness environment switches for Rust/TLS/BLS/other libraries remain available, so the logged default Rust AAR hash alone must not be reused as proof of all auxiliary APK inputs or production Rust/TLS configuration. No such broad acceptance is granted here. The recorded offline evidence is airplane mode, disabled Wi-Fi/data, and an IPv4 route probe; it is not a comprehensive network-policy or IPv6 isolation test. No `start` call exists in the new fixture and its configured server addresses are loopback. Production app/native inputs are unchanged in this commit.

## Required material for the separately queued durable group

Preserve the exact old/candidate runtime logs with their hash/property/exit/cleanup records; the two AAR identities and old-source limitation; the executable runner/harness epoch identified by these hashes; comparator positive and changed-vector negative evidence (including invocation/actual exit status); Rust oracle source/lock, command and GREEN/initial selector-error logs; actual Dart ABI test and analyzer logs; candidate build provenance, all-ABI headers/Java descriptor and ELF JSON. Store a manifest with relative paths and cryptographic hashes. Preserve the distinction between this new shared-harness epoch and immutable Task16B historical evidence. Final app artifact integration, release/R8/packaging, other 16F failures and remote validator acceptance remain separate gates.
