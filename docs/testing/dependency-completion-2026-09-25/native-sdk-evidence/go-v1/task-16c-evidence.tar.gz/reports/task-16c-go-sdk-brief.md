# Task16C: Upgrade reachable Android Go EVM SDK from recorded source

Prepared only; wait for controller greenlight and exact base after Task16B. This is a bounded dependency/security migration under approved full production upgrade, not a V1 retirement or consensus redesign. Work only in app continuation /Users/jieliu/.codex/worktrees/n42appv2-dependency-completion and an explicitly task-owned source/build workspace. Never modify sibling /Users/jieliu/Documents/n42/N42-gov5, its tags/index/config or main app checkout. No child agents, pushes or production account/device/service use. Controller independently reviews each coherent English commit and pushes.

## Read first

- task-16-go-sdk-build-inputs.md: actual live Emit requests/responses, pinned mobile tools, native/build hazards, corrected per-directory license findings.
- task-16-sdk-upgrade-feasibility.md and durable docs/testing/dependency-completion-2026-09-25/native-sdk-audit.md.
- Existing native acceptance and toolchain docs; preserve earlier native patches and3appABIs.

## Fixed baseline and candidate

Both old evm.aar copies SHA25628a8f91311b94b0ffaeea61620fa065633d0e8934b95c4250314c120775eb470 containGo1.19.4,113distinctbinaryadvisoriesperABI; noexactoldsource. V1actuallyuserselectable andmustremainfunctional. Canonical currentreleasev5.7.906 source5083c29735acfc7023ab1fbbd6d6527b7b97cbae (notstalelocaltag0ce8e74). This is a source candidate, not accepted mobile replacement. Start with exactsourcearchive/isolatedcheckout, preservego.sum andrecordallpatches/hash.

PinnedGo1.26.8 /Users/jieliu/.codex/toolchains/go-1.26.8/go/bin/go, AndroidisolatedSDK37 andNDK28.2.13676358, JDK21. Candidategomobile/gobindboth golang.org/x/mobile@v0.0.0-20260908204917-8b95e45f8d3e; verifyofficialsumdb/proxy andinstallintask-ownedGOBIN, neverfloatinglatest/globalreplacement. Targetandroid/arm,android/arm64,android/amd64 (appmin26); chooseexplicitvalidAPI/tags/CGOportableflags withactualtargetdependencygraph. No droppingarmv7wallet/chat orsilentlyremovingV1.

## Implementation gates

1. In recorded candidate source, stop logging raw request values before dispatch: setting andblssign/blspubk can containpriv_key. Capturestdout/logger withdummykey regression showing no key appears under defaultdebug/initialsetting beforelog_leveltakes effect. Inspect otherentrypointrequest/response logs narrowly forsecret exposure. Preserve responseprotocol; nofictionalclaimoldbinaryloggingproof.
2. Offline tests all live Emit commands:settingfull/partial,state,stop,blssign,blspubk;typescode/message/data, exactstarted/stopped,invalidJSON/hex/keylength/errorchannels, repeatidle behavior. Neverstartproductionvalidator. Freezeindependent BLSsignature/pubkey vectors forappamount-to-wei/evenhex/depositABI; testexistingoldAARoffline where safe andnewcandidatebytecompatibility. Serveracceptance/rewards notinferred. Existingupstreamloopback/inmemoryverificationfixturesmayrunif nooutboundservices/realdata. Ifold/newprotocolconflicts arise, localize/reportandfixboundedcompatibility;don'thidefeature.
3. Resolveactualper-targetgo list-deps,BLSTCGO/MDBXconditions,licenses; useonlyrequiredreviewedpatchesforAndroid/16KB/toolchain. Runrequiredsourcesecurityscan; updateaffecteddependencieswithstablecompatibleversions whenneeded,retainexactsolver/build/testevidenceforconstraints. RootLICENSEisnotwholeartifactlicense:LICENSE-MITlistscmd/evmsdk/lib/modules/rpc/accounts,lib/LICENSEApache2,crypto/blsoutsideexplicitlist;inventoryactuallylinkedfiles/dependencies/notices/correspondingsourcerequirementswithoutinventingblanketGPLorlegalverdict.
4. Buildall3shippingABIs reproducibly withimmutableupstream+trackedpatches+exacttools+script. Recordsourceidentity independently ofbrokenupstreamVERSIONldflag. Inspect JavaEvmsdk.emitdescriptor,JNIload/nativeELF/RELRO16KB,dependencyinventory,Go buildmetadata/hash andgovulncheckbinaryJSON results. Parsefindingsnotexitcodealone;distinguishsymbols/reachable/moduleonly/unsupportedanalysis.
5. OnlyaftercompatibilitygatesintegratecompiledAARs/Gradlecompile-runtimeedgescoherently; avoidduplicatingout-of-synccopies. Preserveexistingcallers/accountstorage/assets/cryptobehavior. Realofflineisolatedemulator nativefixture includingBLScalls andstatus/configwithsynthetickey, noactualmining/network. AndroidreleaseAPK/AAB,R8,allABIpackage/signature/ZIP/ELF16KBchecks. Usecontroller'sdedicated16KBemulatorenvironment;physicalandexistingemulatoruntouched. Runtimefunctiontestisnotremotevalidatoracceptance.
6. Trackexactrebuildscript/sourcecommit/patches/licenses/artifacthashes withdurableevidence. Ifactualtargetcompileorcryptocompatibilitycannotbesatisfied, do notreplaceworkingbinarywithbadcandidate; preserveconcreteminimalfailure andsurfaceboundedalternativebeforecontinuing. No silentV1retirement.

## Reporting and commits

KeepchangeslimitedtothisSDK/security/nativeintegration. Separatebuildsource+patches,productionartifactintegration,fixtures,evidence wherecoherent. CommitEnglishsubjects only afterexplicitnon-Chinesecheck andtests; rootprecommithookbumps/stagespubspec. Do notbypasshooks/forcepush. Report task-16c-go-sdk-report.md withstatus,exactcommits,allcommands/resultlogs/hashes,sourcevsbinaryscanlimits,remainingcompatibility/runtime/redistributionfacts. Fullstoreacceptanceandwholeupgradecompletionarenotclaimedhere.

ExistingGoAARcopiesare82MiBeach trackednormalGit(noLFSrules). Checknewartifactsizebeforecommit/push; preferonecoherentsharedGradlereferenceifremovingredundantcopy, avoidadding>100MiBblobblindly. Do notenableglobalLFSormutatepublicationtopologywithoutneed; sourcebuildscript+appropriateexistingartifactstrategy mustremainreviewableandreproducible.

Controllerreadcanonicalcmd/evmsdk/blst.go: wallet32bytes are inputtoSecretKeyFromRandom32Byte, notnecessarilyserializedBLSscalar. Preservethisderivationexactly; donotreplacewithSecretKeyFromBytes merelybecauseboth32bytes. Includeold/newindependentvectorsforlow/high32-byteinputs andexactamountmessagebytes, sincechangedderivationwouldchangesavedvalidatoridentity/depositcompatibility. Noactualwalletkeyreads.

Build VCS metadata: an archive nested under the app worktree can make Go/git stamp the app revision. Use a task-owned independent checkout of exact upstream commit, or explicitly disable/override misleading VCS stamping and retain authoritative source hash/patch manifest. Never mutate sibling git worktree metadata. Check built library go version -m against the actual SDK source, not just the compiler version.

For old unprovenanced AAR comparison, make the disposable emulator fixture offline before loading unknown Go package initializers (record device network isolation). Only synthetic keys and local Emit crypto/state operations; no start. Do not assume old package init is network-free merely because the requested function is offline. Coordinate the dedicated emulator owner and preserve other devices.

## Carry-forward execution controls from Task16B

- On this host /bin/bash 3.2.57, bare `[[ ... ]]` failures do not reliably abort via `set -e`. Every security/provenance/tool/input/output check must use explicit conditional failure/exit. Test real negative paths without network/build side effects; preserve an existing output directory.
- Make runtime evidence durable from the first run: a bounded runner records selected input/library/helper hashes, declared strip transformation and packaged-member equality, final APK hash, exact command/exit, serial, PAGE_SIZE and compatibility/network-isolation properties before/after. Do not retroactively join separate logs into a claimed contemporaneous identity binding.
- Full APK/AAB currently has37/55RELRO failures owned by16F; Go migration must close its changed libraries and retain a truthful full-artifact result, not waive unrelated failures. Use exact current output hashes/counts.
- Generate release tooling via the formal Flutter build entry; after debug/integration tests, --no-pub may retain a stale dev-plugin registrant on Flutter3.47.5. Never hand-edit generated plugin registrants or add integration_test to production to bypass this. Temporary debug-signed release builds prove compilation/R8/packaging, not store-signature acceptance.
- Preserve all minimal commands, failed attempts, source/lock/patch/license inputs and runtime logs in a small tracked archive with a SHA256 manifest before task completion; do not rely on ignored W. Archive no real keys, credentials or huge target directories.
