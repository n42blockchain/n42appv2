# Task 16C source/security slice — 2026-09-26

Status: first candidate-source slice committed as `410a62b4f825a961c918b10445135aa717f0de61` (`fix: redact Go SDK request values before logging`). The hook alone changed `pubspec.yaml` build number `2.4.8+2026072885` → `+2026072886`. **No app AAR or Gradle integration changed.** No Go V1 runtime or distribution claim follows yet.

## Exact source identity and inputs

- Public v5.7.906 commit used by hash: `5083c29735acfc7023ab1fbbd6d6527b7b97cbae`; tree `454a5c991f2943efef8131a6b75ec4af6c831570`. `git archive --format=tar <commit> | shasum -a 256` yielded `0307daeefe3d647f78d461345dc915221f3dfa6e5bd09846f600936df85d6aa9`. Archive produced from an already-present Git object; no same-name local tag was trusted.
- Original `go.mod` SHA-256 `cc02fd1da3063d1ebdee16e04e7ddd2e835f27c4e26164b2872719c01464a0c2`; `go.sum` `899d023d3da8b64689e51fd7a7d5e932d93878dbcf780b35e2fe85e4ddc270ca`. Tracked reviewed `source.patch` SHA-256 `8ce074b989d01fa83ecb3c5878d08140cd6d6b109ea0bb8f0ddc05618aaa617b`; patched `cmd/evmsdk/common.go` SHA-256 `bff5ef66458be1444f69b02dd464f5dfb81370e21610046df5b3ca2cba593024`.
- The candidate source is task-owned `/private/tmp/n42-task16c-go/source`, a `git archive` without Git metadata. Every Go test used `GOFLAGS=-buildvcs=false`; the eventual build recipe must do likewise. The tracked `prepare_source.sh` independently re-archives the exact object and validates the original module and patch hashes, refusing pre-existing output. The sibling repository was read via `git show/archive` only.

## RED, GREEN, and recipe gates

All logs below are under `.superpowers/sdd/dependency-completion-20260925/task-16c-logs/` (ignored; durable archive pending the complete task). The isolated executable is `/Users/jieliu/.codex/toolchains/go-1.26.8/go/bin/go`; cache paths were `/private/tmp/n42-task16c-go/{gocache,modcache}`. First RED dependency retrieval used `GOPROXY=https://proxy.golang.org GOSUMDB=sum.golang.org`; subsequent GREEN used cached modules and the final focused run set both to `off`.

| Command / test | Exit | Observed result |
| --- | ---: | --- |
| `GOTOOLCHAIN=local GOFLAGS=-buildvcs=false GOCACHE=/private/tmp/n42-task16c-go/gocache GOMODCACHE=/private/tmp/n42-task16c-go/modcache GOPROXY=https://proxy.golang.org GOSUMDB=sum.golang.org go test ./cmd/evmsdk -run 'TestEmitDoesNotLog' -count=1 -v` against exact unpatched archive | 1 | `emit-secret-red.log`: both initial `setting` and `blspubk` printed the synthetic `priv_key`; both behavioral assertions failed as intended. A compiler warning from MDBX appeared but did not cause the test failure. |
| Same focused command after changing only `simpleLog` to record operation type, not raw value | 0 | `emit-secret-green.log`: 2/2 passed. No secret value was printed through the tested stdout route; `log.Debug` receives the same redacted arguments. |
| `GOTOOLCHAIN=local GOFLAGS=-buildvcs=false GOCACHE=/private/tmp/n42-task16c-go/gocache GOMODCACHE=/private/tmp/n42-task16c-go/modcache GOPROXY=off GOSUMDB=off go test ./cmd/evmsdk -run 'TestEmit|TestWebSocketServiceForwardWritesDeliversWrappedRequest' -count=1 -v` | 0 | `emit-and-framing-green.log`: 5/5 selected tests passed, including existing JSON parse/BLS dispatch and local WebSocket JSON framing. No `start` or remote validator called. |
| `/bin/bash -n tools/android_native_smoke/go_evm_v5_7_906/prepare_source.sh` | 0 | Syntax valid. |
| `/bin/bash prepare_source.sh /does/not/exist /private/tmp/n42-task16c-go/rejected` | **3 expected** | `prepare-missing-repo.log`; refused missing source without creating destination. |
| `/bin/bash prepare_source.sh /Users/jieliu/Documents/n42/N42-gov5 /private/tmp/n42-task16c-go/source` | **4 expected** | `prepare-existing-output.log`; refused to overwrite existing source. |
| `/bin/bash prepare_source.sh /Users/jieliu/Documents/n42/N42-gov5 /private/tmp/n42-task16c-go/recipe-test-source` then `cmp` patched common/test against the first task-owned candidate | 0 | `prepare-positive.log`; exact source, hash checks, dry-run/apply and byte equality passed. |

“Negative gates 3/4” in the checkpoint meant the **expected exit codes 3 and 4**, not three of four tests passing. Both negative scenarios and the positive scenario passed their assertions. `git diff --cached --check` passed after scoping the generated unified patch's preserved context whitespace via the recipe's `.gitattributes`; the English-only subject was checked before commit.

## Limits carried forward

The old AAR's source is unknown; this RED only proves a logging defect in the canonical *candidate* source. The source package selected tests are narrower than complete Go SDK compatibility, Android builds, license and vulnerability review. Exact old/new BLS vectors, all Emit commands, three ABIs, native/runtime fixture and final whole-app 16 KB checks remain Task 16C work. Current old app AARs were not loaded or modified in this slice.
