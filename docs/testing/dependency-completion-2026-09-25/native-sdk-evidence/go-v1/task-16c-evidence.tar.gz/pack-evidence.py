#!/usr/bin/env python3
"""Pack bounded Task 16C text evidence with stable relative member paths."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


APP = Path('/Users/jieliu/.codex/worktrees/n42appv2-dependency-completion')
WORK = APP / '.superpowers/sdd/dependency-completion-20260925'
OUT = APP / 'docs/testing/dependency-completion-2026-09-25/native-sdk-evidence/go-v1'
BUILD = Path('/private/tmp/n42-task16c-go/rebuild-v4')
AAR_SHA = 'a7f1e0122ca76fe6a4b5c3a29816a07bb95cacb3cc6c21d73573d90a168d258c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inputs():
    for file in sorted((WORK / 'task-16c-logs').iterdir()):
        if file.is_file() and file.suffix != '.kts':
            yield 'logs/' + file.name, file
    for file in sorted((WORK / 'task-16c-security-scan').iterdir()):
        if file.is_file():
            yield 'security/' + file.name, file
    for file in sorted(WORK.glob('task-16c-*.md')):
        # Reviews of this archive refer to its digest and cannot be members
        # of the same digest-bound archive.
        if file.name not in ('task-16c-evidence-review.md',
                             'task-16c-evidence-fix-review.md'):
            yield 'reports/' + file.name, file
    yield 'controlled-size-build.sh', WORK / 'task-16c-controlled-size-build.sh'
    yield 'compare-size.py', WORK / 'task-16c-compare-size.py'
    yield 'pack-evidence.py', WORK / 'task-16c-pack-evidence.py'
    build_names = [
        'inputs.txt', 'ndk-clang-version.txt', 'go-env.json',
        'source-modules.json', 'source-modules.err',
        'generated-modules.json', 'generated-modules.err',
        'go-mod-verify.log', 'gomobile.log',
    ]
    for abi in ('arm', 'arm64', 'amd64'):
        build_names += [f'generated-{abi}.go.mod.normalized', f'generated-{abi}.go.sum']
    for name in build_names:
        yield 'build-v4/' + name, BUILD / name


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    archive = OUT / 'task-16c-evidence.tar.gz'
    manifest_path = OUT / 'manifest.json'
    if archive.exists() or manifest_path.exists():
        raise SystemExit('refusing to replace an existing evidence archive/manifest')

    selected = {}
    for member, file in inputs():
        if member in selected or not file.is_file() or file.is_symlink():
            raise SystemExit(f'missing, duplicate or linked evidence input: {member}')
        data = file.read_bytes()
        if b'\0' in data or len(data) > 25_000_000:
            raise SystemExit(f'nontext or oversized evidence input: {member}')
        selected[member] = data

    with archive.open('wb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as bundle:
                for name, data in sorted(selected.items()):
                    record = tarfile.TarInfo(name)
                    record.size = len(data)
                    record.mtime = 0
                    record.uid = record.gid = 0
                    record.uname = record.gname = ''
                    record.mode = 0o644
                    bundle.addfile(record, io.BytesIO(data))

    archive_bytes = archive.read_bytes()
    manifest = {
        'schema': 1,
        'task': '16C Go V1 Android SDK; text evidence only',
        'canonical_go_source_commit': '5083c29735acfc7023ab1fbbd6d6527b7b97cbae',
        'published_source_commits': [
            '410a62b4f825a961c918b10445135aa717f0de61',
            'b5939303b8da5e71c78028ae055b4f3f5bb3a76b',
            '54185d01a4c64d894f35ea6883ca5948d76885d6',
            'dd19b79d4f83c3f1860f8fef51398633edddc0ae',
            '617a4fef8661b16870bd02a2a1de1b4205c60a09',
            '7b8e223c29857ee647e14e58ad0e10db62b41d5f',
            'd905de7572cace3b58bd458f2fd5a02e5a05e587',
            'afdfad230d654955a68e12811f75c74e9993cfe0',
            '1243d11b3cce62b2664fdd55415e34104a6c8153',
        ],
        'app_binary_commit': '1243d11b3cce62b2664fdd55415e34104a6c8153',
        'historical_commit_boundaries': {
            'task16b_release_baseline': '391910e2a14960aa64f0680268e514ab968a01a5',
            'go_fixture_and_oracle': 'd905de7572cace3b58bd458f2fd5a02e5a05e587',
            'go_fixture_comparator_text_fix': 'afdfad230d654955a68e12811f75c74e9993cfe0',
            'go_app_aar_integration': '1243d11b3cce62b2664fdd55415e34104a6c8153',
        },
        'archive': {
            'path': archive.name,
            'bytes': len(archive_bytes),
            'sha256': sha(archive_bytes),
        },
        'members': {name: {'bytes': len(data), 'sha256': sha(data)}
                    for name, data in sorted(selected.items())},
        'app_aar_sha256': {
            'android/app/libs/evm.aar': AAR_SHA,
            'plugins/flutter_mining/android/libs/evm.aar': AAR_SHA,
        },
        'preserved_task16b_manifest_sha256': '17d3c41dd582a1cbdd3d68370aceb58479eaa04273478d2e1c3745ae4f3ee91c',
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(f'archive={archive} sha256={manifest["archive"]["sha256"]} bytes={len(archive_bytes)} members={len(selected)}')


if __name__ == '__main__':
    main()
