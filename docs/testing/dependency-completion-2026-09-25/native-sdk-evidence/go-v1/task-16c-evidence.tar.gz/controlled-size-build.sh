#!/bin/bash
set -u -o pipefail

root=/Users/jieliu/.codex/worktrees/n42appv2-dependency-completion
scratch=/private/tmp/n42-task16c-go
logs="$root/.superpowers/sdd/dependency-completion-20260925/task-16c-logs"
new_aar="$scratch/rebuild-v4/evm.aar"
old_aar="$scratch/old-packaged-evm.aar"
new_hash=a7f1e0122ca76fe6a4b5c3a29816a07bb95cacb3cc6c21d73573d90a168d258c
old_hash=28a8f91311b94b0ffaeea61620fa065633d0e8934b95c4250314c120775eb470
gradle=android/app/build.gradle.kts
gradle_backup="$logs/go-size-app-gradle-before.kts"
old_output="$scratch/controlled-old-release"
new_output="$scratch/controlled-new-release"
flutter=/Users/jieliu/.codex/toolchains/flutter-3.47.5/flutter/bin/flutter

cd "$root" || exit 2
if [ -e "$gradle_backup" ] || [ -e "$old_output" ] || [ -e "$new_output" ]; then
  echo 'controlled size output already exists' >&2
  exit 3
fi
if [ "$(shasum -a 256 "$new_aar" | awk '{print $1}')" != "$new_hash" ] ||
   [ "$(shasum -a 256 "$old_aar" | awk '{print $1}')" != "$old_hash" ] ||
   [ "$(shasum -a 256 android/app/libs/evm.aar | awk '{print $1}')" != "$new_hash" ] ||
   [ "$(shasum -a 256 plugins/flutter_mining/android/libs/evm.aar | awk '{print $1}')" != "$new_hash" ]; then
  echo 'old/new AAR input hash differs' >&2
  exit 4
fi
if [ -n "$(git status --porcelain)" ]; then
  echo 'worktree is not clean before controlled baseline' >&2
  exit 4
fi
original_gradle_hash=$(shasum -a 256 "$gradle" | awk '{print $1}')
if ! cp "$gradle" "$gradle_backup"; then exit 5; fi

restore() {
  outcome=$?
  trap - EXIT
  if ! cp "$new_aar" android/app/libs/evm.aar ||
     ! cp "$new_aar" plugins/flutter_mining/android/libs/evm.aar ||
     ! cp "$gradle_backup" "$gradle"; then
    echo 'controlled size input restoration failed' >&2
    exit 99
  fi
  restored_gradle_hash=$(shasum -a 256 "$gradle" | awk '{print $1}')
  restored_app_hash=$(shasum -a 256 android/app/libs/evm.aar | awk '{print $1}')
  restored_plugin_hash=$(shasum -a 256 plugins/flutter_mining/android/libs/evm.aar | awk '{print $1}')
  echo "restored_gradle_sha256=$restored_gradle_hash restored_app_aar_sha256=$restored_app_hash restored_plugin_aar_sha256=$restored_plugin_hash"
  if [ "$restored_gradle_hash" != "$original_gradle_hash" ] ||
     [ "$restored_app_hash" != "$new_hash" ] ||
     [ "$restored_plugin_hash" != "$new_hash" ]; then
    exit 99
  fi
  exit "$outcome"
}
trap restore EXIT

python3 - "$gradle" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
contents = path.read_text()
old = 'signingConfig = signingConfigs.getByName("release")'
if contents.count(old) != 1:
    raise SystemExit('unexpected release signing setting')
path.write_text(contents.replace(old, 'signingConfig = signingConfigs.getByName("debug")'))
PY
if [ "$?" -ne 0 ]; then exit 5; fi

export JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home
export ANDROID_HOME=/Users/jieliu/.codex/toolchains/android-sdk-37
export ANDROID_SDK_ROOT="$ANDROID_HOME"
printf 'utc=%s\ncommit=%s\npubspec=%s\nold_aar=%s\nnew_aar=%s\noriginal_gradle_sha256=%s\nsigning=temporary local debug\n' \
  "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$(git rev-parse HEAD)" \
  "$(sed -n 's/^version: //p' pubspec.yaml)" "$old_hash" "$new_hash" "$original_gradle_hash" \
  > "$logs/go-size-controlled-inputs.txt"

for mode in old new; do
  if [ "$mode" = old ]; then
    input="$old_aar"
    expected="$old_hash"
    output="$old_output"
  else
    input="$new_aar"
    expected="$new_hash"
    output="$new_output"
  fi
  if ! cp "$input" android/app/libs/evm.aar ||
     ! cp "$input" plugins/flutter_mining/android/libs/evm.aar ||
     [ "$(shasum -a 256 android/app/libs/evm.aar | awk '{print $1}')" != "$expected" ] ||
     [ "$(shasum -a 256 plugins/flutter_mining/android/libs/evm.aar | awk '{print $1}')" != "$expected" ]; then
    echo "could not install $mode AAR input" >&2
    exit 6
  fi
  if ! "$flutter" build apk --release > "$logs/go-size-controlled-$mode-apk.log" 2>&1; then
    echo "$mode APK build failed; see log" >&2
    exit 7
  fi
  if ! "$flutter" build appbundle --release > "$logs/go-size-controlled-$mode-aab.log" 2>&1; then
    echo "$mode AAB build failed; see log" >&2
    exit 8
  fi
  if ! mkdir "$output" ||
     ! cp build/app/outputs/flutter-apk/app-release.apk "$output/app-release.apk" ||
     ! cp build/app/outputs/bundle/release/app-release.aab "$output/app-release.aab"; then
    echo "could not retain $mode outputs" >&2
    exit 9
  fi
  echo "mode=$mode apk_sha256=$(shasum -a 256 "$output/app-release.apk" | awk '{print $1}') apk_bytes=$(stat -f '%z' "$output/app-release.apk") aab_sha256=$(shasum -a 256 "$output/app-release.aab" | awk '{print $1}') aab_bytes=$(stat -f '%z' "$output/app-release.aab")" \
    >> "$logs/go-size-controlled-inputs.txt"
done
echo 'controlled_builds=PASS'
