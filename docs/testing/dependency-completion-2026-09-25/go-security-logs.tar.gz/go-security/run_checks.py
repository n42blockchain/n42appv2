import datetime, hashlib, json, os, pathlib, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parents[4]
OUT = pathlib.Path(__file__).resolve().parent
GO = '/Users/jieliu/.codex/toolchains/go-1.26.8/go/bin/go'
ENV = os.environ.copy()
ENV.update(GOTOOLCHAIN='local', PATH=str(pathlib.Path(GO).parent)+':'+ENV['PATH'])
SCANNER = OUT / 'tools' / 'govulncheck'
SCANNER.parent.mkdir(exist_ok=True)

def run(label, command, cwd=ROOT, extra=None):
    env = ENV.copy()
    env.update(extra or {})
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    now = time.monotonic()
    with (OUT/(label+'.stdout')).open('w') as stdout, (OUT/(label+'.stderr')).open('w') as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    record = {'label':label,'command':command,'cwd':str(cwd),'environment':{'GOTOOLCHAIN':'local','PATH_prefix':str(pathlib.Path(GO).parent),**(extra or {})},'started':started,'duration_seconds':round(time.monotonic()-now,3),'exit':result.returncode}
    (OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(label, result.returncode, flush=True)
    return result.returncode

assert run('001-version',[GO,'version']) == 0
assert run('002-scanner-build',[GO,'install','golang.org/x/vuln/cmd/govulncheck@v1.1.4'],extra={'GOBIN':str(SCANNER.parent)}) == 0
run('003-scanner-build-info',[GO,'version','-m',str(SCANNER)])
(OUT/'scanner.sha256').write_text(hashlib.sha256(SCANNER.read_bytes()).hexdigest()+'\n')
for module in ['livekit-jwt','loyalty','social-auth','swap']:
    cwd = ROOT/'backend'/module
    for name, args in [('test',['test','-count=1','./...']),('vet',['vet','./...']),('tidy-diff',['mod','tidy','-diff']),('verify',['mod','verify'])]:
        run(module+'-'+name,[GO]+args,cwd)
    run(module+'-host-vuln',[str(SCANNER),'-json','./...'],cwd)
    run(module+'-host-imports',[GO,'list','-deps','-test','./...'],cwd)
    for arch in ['amd64','arm64']:
        extra={'GOOS':'linux','GOARCH':arch,'CGO_ENABLED':'0'}
        run(module+'-linux-'+arch+'-vuln',[str(SCANNER),'-json','./...'],cwd,extra)
        run(module+'-linux-'+arch+'-imports',[GO,'list','-deps','./...'],cwd,extra)
        run(module+'-linux-'+arch+'-build',[GO,'build','-trimpath','-o',str(OUT/(module+'-linux-'+arch)),'.'],cwd,extra)
print('CHECKS FINISHED',flush=True)
