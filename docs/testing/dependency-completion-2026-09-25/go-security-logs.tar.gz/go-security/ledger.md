# Go security patch execution ledger
Base: 1dbbe89c055681dce30eca5d5da17ee34b036f08. Brief: ../task-go-security-brief.md.
Ruling: existing Go1.26.5 reachable-advisory scans are the failing regression evidence; this change modifies toolchain/configuration only, so verification is fresh scans plus existing service tests, without an artificial implementation-mirroring test.
Ruling: set go directives to1.26.8, no redundant toolchain directive. CI go-version-file follows minimum patch and GOTOOLCHAIN=local disallows hidden toolchain switching. Builders pin official available1.26.8-alpine.
Isolated official tarball hash verified; global toolchain untouched. Controller untracked UGC document preserved.
Verification:51commands all exit0;12host/Linuxamd64/arm64scans contain0stdlib/0reachable/0imported affected-packagefindings. Module-only OpenPGP andgrpc preserved. All3go.sum files unchanged. Crossbuilds pass; containers notrun.
