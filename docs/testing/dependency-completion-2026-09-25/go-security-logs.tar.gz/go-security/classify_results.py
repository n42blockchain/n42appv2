import json, pathlib, re
OUT=pathlib.Path(__file__).resolve().parent
results={}
for f in sorted(OUT.glob('*-vuln.stdout')):
    data=f.read_text(); decoder=json.JSONDecoder(); config=None; findings={}; advisories={}
    while data.strip():
        data=data.lstrip(); obj,index=decoder.raw_decode(data); data=data[index:]
        if 'config' in obj: config=obj['config']
        if 'osv' in obj: advisories[obj['osv']['id']]=obj['osv']
        if 'finding' not in obj: continue
        finding=obj['finding']; top=finding['trace'][0]
        level='reachable' if top.get('function') else 'imported-package' if top.get('package') else 'module-only'
        ranks={'module-only':0,'imported-package':1,'reachable':2}
        if finding['osv'] not in findings or ranks[level]>ranks[findings[finding['osv']]['level']]:
            findings[finding['osv']]={'level':level,'module':top['module'],'version':top['version'],'fixed_version':finding.get('fixed_version')}
    imports=(OUT/f.name.replace('-vuln.stdout','-imports.stdout')).read_text().splitlines()
    for id,finding in findings.items():
        affected=[i['path'] for a in advisories[id]['affected'] for i in a.get('ecosystem_specific',{}).get('imports',[])]
        finding['affected_packages']=affected
        finding['affected_packages_present_in_import_graph']=sorted(set(affected)&set(imports))
    results[f.stem]={'config':config,'findings':findings}
assert len(results)==12,len(results)
for result in results.values():
    assert result['config']['go_version']=='go1.26.8'
    for finding in result['findings'].values():
        assert finding['module']!='stdlib',finding
        assert finding['level']=='module-only',finding
        assert not finding['affected_packages_present_in_import_graph'],finding
commands=[json.loads(p.read_text()) for p in OUT.glob('*.json') if isinstance(json.loads(p.read_text()),dict) and 'label' in json.loads(p.read_text())]
assert len(commands)==51,len(commands)
assert all(c['exit']==0 for c in commands)
summary={'commands':len(commands),'command_failures':0,'scans':len(results),'reachable_findings':0,'imported_affected_package_findings':0,'stdlib_findings':0,'module_only_advisories_retained':True,'results':results}
(OUT/'results-classified.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
for name,value in results.items():print(name,','.join(value['findings']) or 'no findings')
