# Iteration record

- Real unpatched11 direct ESP upgrade returned null (retained RED log).
- Initial completed-destination missing-key test regenerated a key (retained RED log); the maintained guard prevents it.
- The first CBC seed used a file-list-based flush before apply() created its XML; the seed disappeared when instrumentation exited. Fixed by committing known prefs caches before snapshot/exit. The early raw CBC failure log was overwritten; it is not claimed as adapter RED evidence.
- A test's deliberate corrupt-source injection and repair changed XML entry ordering. failure-test-injected-source-rewrite.log retains that failure. The final test proves corrupted bytes stay unchanged on failure, repairs cache and restores original encrypted bytes BEFORE retry. Final focused assertions/restart passed.
- Initial desktop test compilation accessed userId through abstract AccessToken; narrowed it to ClassicToken. This test-authoring error is not claimed as behavior RED.
- Package source/test setup and fixture build warnings are distinct from final test assertions. No real credentials or production apps were used.
