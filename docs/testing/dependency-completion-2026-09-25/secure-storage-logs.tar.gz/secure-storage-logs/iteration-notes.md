# Iteration record

- Real unpatched11 direct ESP upgrade returned null (retained RED log).
- Initial completed-destination missing-key test regenerated a key (retained RED log); the maintained guard prevents it.
- The first CBC seed used a file-list-based flush before apply() created its XML; the seed disappeared when instrumentation exited. Fixed by committing known prefs caches before snapshot/exit. The early raw CBC failure log was overwritten; it is not claimed as adapter RED evidence.
- A test's deliberate corrupt-source injection and repair changed XML entry ordering. failure-test-injected-source-rewrite.log retains that failure. The final test proves corrupted bytes stay unchanged on failure, repairs cache and restores original encrypted bytes BEFORE retry. Final focused assertions/restart passed.
- Initial desktop test compilation accessed userId through abstract AccessToken; narrowed it to ClassicToken. This test-authoring error is not claimed as behavior RED.
- Package source/test setup and fixture build warnings are distinct from final test assertions. No real credentials or production apps were used.

## Review fix round 1

- Before production fixes, a real directory chmod failure at completion commit left Android's cached completion=true and allowed a second FlutterEngine read. Retained review-red-completion-esp-completion.log.
- Before production fixes, malformed source XML in a fresh process was accepted as empty. Retained review-red-source-esp-malformed.log.
- The initial strict XML parser rejected legal trailing IGNORABLE_WHITESPACE. review-iteration-parser-whitespace.log and esp-verify-review-debug.log retain the failure/diagnosis. Explicit whitespace-token acceptance fixed it; this iteration is not additional behavior RED.
- Final expanded focused suite: 42 persistence/corruption stages, review-persistence-suite.log and persistence-results.json. Original regression rerun: 40 native stage invocations and deliberate process termination recovery, review-native-suite.log and native-results.json. Secure Dart suite rerun: 92/92, review-secure-dart-test.log.
- Directory permission failure is real filesystem evidence; disk-full, actual fsync failure, and hardware power loss remain untested. Any .bak is preserved and rejected for explicit repair.
