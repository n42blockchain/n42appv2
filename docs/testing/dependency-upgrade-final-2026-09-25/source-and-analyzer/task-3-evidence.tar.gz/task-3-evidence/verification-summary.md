# Task 3 verification commands

All paths below are relative to the plan-owned workspace at
`.superpowers/sdd/2026-09-25-full-dependency-upgrade/task-3-evidence/`.

| Command | Working directory | Exit | Result log |
| --- | --- | ---: | --- |
| `dart pub get` | `packages/n42_jmt_verify` | 0 | `jmt-dart-pub-get.log` |
| `dart analyze` | `packages/n42_jmt_verify` | 0 | `jmt-dart-analyze.log` |
| `dart test` | `packages/n42_jmt_verify` | 0 | `jmt-dart-test.log` — 13 passed |
| `flutter test --no-pub --reporter expanded test/features/wallet/wallet_payment_asset_test.dart` | repository root | 0 | `wallet-payment-asset-test.log` — 5 passed |
| `flutter test --no-pub --reporter expanded test/features/wallet/n42_wallet_bridge_test.dart` | repository root | 0 | `n42-wallet-bridge-test.log` — 9 passed |
| `flutter test --no-pub --reporter expanded test/features/wallet/n42_wallet_bridge_rejection_test.dart` | repository root | 0 | `n42-wallet-bridge-rejection-test.log` — 22 passed |
| `flutter test --no-pub --reporter expanded test/features/wallet/` | repository root | 0 | `wallet-directory-tests.log` — 1,101 passed |
| `flutter analyze --no-fatal-infos` | repository root | 0 | `flutter-analyze-after-fixes.log` — 37 infos, 0 warnings, 0 errors |
| `dart format --output=none --set-exit-if-changed <four changed Dart files>` | repository root | 0 | `dart-format-check.log` |
| `git diff --check` | repository root | 0 | `git-diff-check.log` |

Each command's numeric exit status is also stored in the corresponding `.exit` file. The post-Task-2 analyzer output is preserved separately as `flutter-analyze-after-task2.log`.
