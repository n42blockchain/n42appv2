from run import ROOT, OUT
import subprocess,json,pathlib,re,hashlib,gzip
BASE='dee63931f'
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
def yamltext(s): return json.loads(subprocess.check_output(['ruby','-ryaml','-rjson','-e','puts JSON.generate(YAML.load(STDIN.read))'],input=s,text=True))
files=git('ls-files').splitlines()
manifest=[p for p in files if not p.startswith(('packages/n42_chat/','docs/','.superpowers/')) and (pathlib.Path(p).name in ['pubspec.yaml','pubspec.lock','pubspec_overrides.yaml','go.mod','go.sum','Cargo.toml','Cargo.lock','package.json','package-lock.json','Podfile','Podfile.lock','Package.resolved','gradle-wrapper.properties','build.gradle.kts','build.gradle','settings.gradle.kts','settings.gradle','gradle.properties','libs.versions.toml'])]
records=[]
for p in manifest:
 q=ROOT/p
 if not q.exists(): continue
 records.append({'path':p,'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'changed_since_baseline':bool(git('diff',BASE,'--',p))})
(OUT/'500-manifest-lock-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
root=yamltext((ROOT/'pubspec.lock').read_text()); baseline=yamltext(git('show',BASE+':pubspec.lock'))
def nums(v): return tuple(int(x) for x in re.findall(r'\d+',v.split('+')[0]))
downgrades=[]
for name,p in root['packages'].items():
 old=baseline['packages'].get(name)
 if old and nums(p['version'])<nums(old['version']): downgrades.append({'name':name,'before':old['version'],'after':p['version'],'source':p['source']})
prereleases=[]
for p in manifest:
 if p.endswith('pubspec.lock'):
  for name,v in yamltext((ROOT/p).read_text())['packages'].items():
   if '-' in v['version'].split('+')[0]: prereleases.append({'lock':p,'name':name,'version':v['version']})
for name,v in json.loads((ROOT/'chrome-extension/package-lock.json').read_text())['packages'].items():
 if '-' in v.get('version','').split('+')[0]: prereleases.append({'lock':'chrome-extension/package-lock.json','name':name,'version':v['version']})
for name,version in re.findall(r'\[\[package\]\]\nname = "([^"]+)"\nversion = "([^"]+)"',(ROOT/'rust/n42_mls/Cargo.lock').read_text()):
 if '-' in version.split('+')[0]: prereleases.append({'lock':'rust/n42_mls/Cargo.lock','name':name,'version':version})
assert root['packages']['n42_chat']['source']=='git'
assert root['packages']['n42_chat']['description']['resolved-ref']=='3cc19c12a7c9bbf2031270acca8e3922730b55a5'
assert yamltext((ROOT/'packages/n42_jmt_verify/pubspec.lock').read_text())['packages']['blake3_dart']['version']=='1.0.0'
assert not git('diff',BASE,'--','packages/n42_chat')
old_overrides=yamltext(git('show',BASE+':pubspec_overrides.yaml'))['dependency_overrides']; new_overrides=yamltext((ROOT/'pubspec_overrides.yaml').read_text())['dependency_overrides']
assert set(old_overrides)-set(new_overrides)=={'n42_chat'}
native=[]
for p in ['ios/Podfile.lock','macos/Podfile.lock','android/app/build.gradle.kts']:
 old=git('show',BASE+':'+p)
 for line in (ROOT/p).read_text().splitlines():
  if re.search(r'beta\d|nightly\.',line): native.append({'file':p,'line':line.strip(),'in_baseline':line in old.splitlines()})
changes=git('diff',BASE,'--name-status')
for entry in prereleases:
 try:
  oldtext=git('show',BASE+':'+entry['lock'])
  entry['version_present_in_baseline']=entry['version'] in oldtext
 except subprocess.CalledProcessError: entry['version_present_in_baseline']=False
(OUT/'501-graph-audit.json').write_text(json.dumps({'root_packages':len(root['packages']),'baseline_root_packages':len(baseline['packages']),'root_downgrades':downgrades,'prereleases_flutter_npm_cargo':prereleases,'inherited_native_prereleases':native,'removed_overrides':list(set(old_overrides)-set(new_overrides)),'chat_mirror_unchanged':True,'blake3_dart':'1.0.0'},indent=2)+'\n')
with gzip.open(OUT/'502-full-name-status.log.gz','wt') as f: f.write(changes)
# Only file names/counts leave this scanner; credential values are never printed.
diff=git('diff',BASE,'--','.',':(exclude)docs').splitlines(); findings=[]; current=''
patterns=[r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'AKIA[0-9A-Z]{16}',r'gh[pousr]_[A-Za-z0-9]{30,}']
for line in diff:
 if line.startswith('+++ b/'): current=line[6:]
 if line.startswith('+') and not line.startswith('+++') and any(re.search(p,line) for p in patterns): findings.append(current)
for p in git('diff',BASE,'--name-only','--diff-filter=A').splitlines():
 if pathlib.Path(p).name in ['key.properties','local.properties','GoogleService-Info.plist','google-services.json'] or pathlib.Path(p).suffix in ['.jks','.keystore','.p12','.mobileprovision']: findings.append(p)
(OUT/'503-secret-scan.json').write_text(json.dumps({'scope':'Added diff lines: private key headers, AWS access IDs, GitHub tokens; new signing/Firebase/local configuration paths. This is a focused scan, not proof of absence of every secret format.','finding_paths':sorted(set(findings))},indent=2)+'\n')
print('Manifest/lock records',len(records),'root packages',len(root['packages']),'downgrades',downgrades,'new prereleases',prereleases,'secret finding paths',sorted(set(findings)))
