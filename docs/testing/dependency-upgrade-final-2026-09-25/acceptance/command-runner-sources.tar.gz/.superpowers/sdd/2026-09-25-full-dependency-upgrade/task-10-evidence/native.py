from run import run
import os
jdk='/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home'
env={'JAVA_HOME':jdk,'PATH':jdk+'/bin:'+os.environ['PATH']}
run('400-java-version',['sh','-c','java -version; "$JAVA_HOME/bin/jlink" --version'],env=env)
run('401-android-apk',['flutter','build','apk','--debug'],env=env)
run('402-android-mining-native',['./gradlew',':flutter_mining:assembleDebug',':flutter_mining:testDebugUnitTest',':app:testDebugUnitTest','--console=plain'],'android',env)
run('410-ios-pod-deployment',['pod','install','--deployment','--no-repo-update'],'ios')
run('411-ios-release',['flutter','build','ios','--no-codesign','--release'])
run('412-ios-spm-resolve',['xcodebuild','-resolvePackageDependencies','-workspace','ios/Runner.xcworkspace','-scheme','Runner'])
run('420-macos-pod-deployment',['pod','install','--deployment','--no-repo-update'],'macos')
run('421-macos-release',['flutter','build','macos','--release'])
run('422-macos-project',['xcodebuild','-project','macos/Runner.xcodeproj','-scheme','Runner','-configuration','Release','CODE_SIGNING_ALLOWED=NO','build'])
