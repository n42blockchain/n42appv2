import subprocess, pathlib, json, gzip, time, sys, os
ROOT=pathlib.Path(__file__).resolve().parents[4]
OUT=ROOT/'docs/testing/dependency-upgrade-final-2026-09-25/acceptance'
def run(label, cmd, cwd='.', env=None):
    dst=OUT/(label+'.log.gz')
    if dst.exists(): raise RuntimeError('Will not overwrite '+str(dst))
    start=time.time(); actualenv=os.environ.copy(); actualenv.update(env or {})
    print('START',label,flush=True)
    live=pathlib.Path(__file__).parent/(label+'.live.log')
    with live.open('wb') as output:
        p=subprocess.run(cmd,cwd=ROOT/cwd,env=actualenv,stdout=output,stderr=subprocess.STDOUT)
    p.stdout=live.read_bytes()
    with gzip.open(dst,'wb') as f: f.write(p.stdout)
    (OUT/(label+'.exit')).write_text(str(p.returncode)+'\n')
    rec=dict(label=label,command=cmd,cwd=cwd,environment=env or {},exit=p.returncode,seconds=round(time.time()-start,2))
    (OUT/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
    print('END',label,'exit',p.returncode,'seconds',rec['seconds'],flush=True)
    print(p.stdout.decode(errors='replace')[-1600:],flush=True)
    return p.returncode
if __name__=='__main__': run(sys.argv[1],sys.argv[3:],sys.argv[2])
