from run import run
import os
env={'PATH':'/Users/jieliu/.nvm/versions/node/v20.20.0/bin:'+os.environ['PATH']}
run('308-audit-fix-dry-run',['npm','audit','fix','--dry-run','--json'],'chrome-extension',env)
run('309-audit-dependency-chains',['npm','explain','adm-zip','brace-expansion','fast-uri','shell-quote','tmp','uuid','--json'],'chrome-extension',env)
