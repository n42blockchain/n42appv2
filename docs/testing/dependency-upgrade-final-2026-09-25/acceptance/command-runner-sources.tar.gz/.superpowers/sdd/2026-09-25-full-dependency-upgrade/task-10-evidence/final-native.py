from run import run,OUT
import os,time
marker=OUT/'517-localization-wallet-tests.exit'
while not marker.exists(): time.sleep(2)
for label in ['512-intl-utils-generate','518-wallet-localization-audit','514-localization-python-tests','515-post-localization-format','516-post-localization-analyze','517-localization-wallet-tests']:
 assert (OUT/(label+'.exit')).read_text().strip()=='0',label+' failed'
jdk='/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home'
env={'JAVA_HOME':jdk,'PATH':jdk+'/bin:'+os.environ['PATH']}
run('430-final-android-apk',['flutter','build','apk','--debug'],env=env)
run('431-final-ios-release',['flutter','build','ios','--no-codesign','--release'])
