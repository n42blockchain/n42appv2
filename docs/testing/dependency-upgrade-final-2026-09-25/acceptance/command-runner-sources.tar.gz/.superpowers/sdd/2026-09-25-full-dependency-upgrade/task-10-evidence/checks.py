from run import run, ROOT
import sys, os
mode=sys.argv[1]
if mode=='flutter':
    run('010-toolchains',['sh','-c','flutter --version; dart --version; xcodebuild -version; pod --version'])
    run('011-root-pub-get',['flutter','pub','get'])
    run('012-root-analyze',['flutter','analyze','--no-fatal-infos'])
    run('013-root-format',['dart','format','--output=none','--set-exit-if-changed','lib/','test/'])
    run('014-root-coverage-tests',['sh','-c','ulimit -n 4096; flutter test --coverage --concurrency=4'])
    run('015-root-coverage-gate',['python3','scripts/quality_gate.py','coverage','coverage/lcov.info','--threshold','70'])
elif mode=='go':
    env={'GOTOOLCHAIN':'local'}
    run('100-go-version',['go','version'],env=env)
    for i,mod in enumerate(['livekit-jwt','loyalty','social-auth','swap']):
        cwd='backend/'+mod
        run(f'{110+i*10}-go-{mod}-test',['go','test','-count=1','./...'],cwd,env)
        run(f'{111+i*10}-go-{mod}-vet',['go','vet','./...'],cwd,env)
        run(f'{112+i*10}-go-{mod}-tidy',['go','mod','tidy'],cwd,env)
        run(f'{113+i*10}-go-{mod}-tidy-diff',['git','diff','--exit-code','--','go.mod','go.sum'],cwd,env)
elif mode=='rust':
    cwd='rust/n42_mls'; env={'ANDROID_NDK_HOME':'/Users/jieliu/Library/Android/sdk/ndk/27.1.12297006'}
    run('200-rust-version',['sh','-c','rustc --version; cargo --version'],cwd)
    for label,cmd in [('201-fmt',['cargo','fmt','--check']),('202-test',['cargo','test','--all-targets','--locked']),('203-check',['cargo','check','--all-targets','--locked']),('204-clippy',['cargo','clippy','--all-targets','--locked','--','-D','warnings']),('205-android-check',['cargo','check','--target','aarch64-linux-android','--all-targets','--locked']),('206-android-clippy',['cargo','clippy','--target','aarch64-linux-android','--all-targets','--locked','--','-D','warnings'])]: run(label,cmd,cwd,env)
elif mode=='chrome':
    cwd='chrome-extension'; env={'PATH':'/Users/jieliu/.nvm/versions/node/v20.20.0/bin:'+os.environ['PATH']}
    run('300-node-version',['sh','-c','node --version; npm --version'],cwd,env)
    for label,cmd in [('301-npm-ci',['npm','ci']),('302-tests',['npm','test']),('303-lint',['npm','run','lint']),('304-type',['npm','run','type-check']),('305-build',['npm','run','build']),('306-audit-prod',['npm','audit','--omit=dev','--json']),('307-audit-all',['npm','audit','--json'])]: run(label,cmd,cwd,env)
