from run import run
import os
env={'PATH':'/Users/jieliu/.nvm/versions/node/v20.20.0/bin:'+os.environ['PATH']};cwd='chrome-extension'
run('323-unused-plugin-source-audit',['rg','-n','vite-plugin-web-extension|copyExtensionAssets','package.json','vite.config.mts','src'],cwd,env)
run('324-remove-unused-plugin',['npm','uninstall','--save-dev','vite-plugin-web-extension'],cwd,env)
for label,cmd in [('325-review-final-ci',['npm','ci']),('326-review-final-tests',['npm','test']),('327-review-final-lint',['npm','run','lint']),('328-review-final-type',['npm','run','type-check']),('329-review-final-build',['npm','run','build']),('330-review-final-audit-prod',['npm','audit','--omit=dev','--json']),('331-review-final-audit-all',['npm','audit','--json'])]: run(label,cmd,cwd,env)
