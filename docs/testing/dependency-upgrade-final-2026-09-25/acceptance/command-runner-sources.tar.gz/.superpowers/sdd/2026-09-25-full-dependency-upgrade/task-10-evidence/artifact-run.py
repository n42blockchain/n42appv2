from run import run,OUT
import time
marker=OUT/'431-final-ios-release.exit'
while not marker.exists():time.sleep(2)
assert marker.read_text().strip()=='0'
run('434-native-artifact-audit',['python3','.superpowers/sdd/2026-09-25-full-dependency-upgrade/task-10-evidence/artifacts.py'])
