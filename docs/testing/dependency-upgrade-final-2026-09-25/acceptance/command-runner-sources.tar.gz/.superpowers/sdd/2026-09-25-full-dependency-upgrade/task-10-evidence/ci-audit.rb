require 'yaml'
require 'json'
ci = YAML.load_file('.github/workflows/ci.yml')
steps = ci.fetch('jobs').fetch('test').fetch('steps')
root = steps.find { |s| s['id'] == 'root_tests' }
coverage = steps.find { |s| s['name'] == 'Generate coverage report' }
chat = steps.find { |s| s['name'] == 'Test the resolved Chat package' }
raise 'root missing' unless root
raise 'gate conditional missing' unless coverage['if'].include?("always() && steps.root_tests.outcome == 'success'")
raise 'chat masked' if chat['continue-on-error']
raise 'threshold changed' unless ci['env']['COVERAGE_THRESHOLD'].to_s == '70'
base = YAML.load(IO.popen(['git','show','dee63931f:.github/workflows/ci.yml'], &:read))
raise 'new job' unless base['jobs'].keys.sort == ci['jobs'].keys.sort
puts JSON.pretty_generate({threshold: ci['env']['COVERAGE_THRESHOLD'], root_step: root['id'], coverage_condition: coverage['if'], chat_continue_on_error: chat['continue-on-error'], unchanged_job_names: ci['jobs'].keys})
