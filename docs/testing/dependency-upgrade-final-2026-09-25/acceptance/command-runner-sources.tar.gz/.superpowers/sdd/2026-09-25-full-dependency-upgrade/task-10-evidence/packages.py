from run import run, ROOT, OUT
import pathlib,json,subprocess,tempfile,urllib.parse,re
for i,(cwd,tool) in enumerate([('plugins/flutter_mining','flutter'),('plugins/flutter_mining/example','flutter'),('packages/audioplayers_darwin','flutter'),('packages/webview_flutter_wkwebview','flutter'),('packages/webview_flutter_wkwebview/example','flutter'),('packages/n42_jmt_verify','dart')]):
    run(f'{20+i*3:03}-local-pub-{pathlib.Path(cwd).name}',[tool,'pub','get','--enforce-lockfile'],cwd)
    run(f'{21+i*3:03}-local-analyze-{pathlib.Path(cwd).name}',[tool,'analyze']+(['--no-fatal-infos'] if tool=='flutter' else []),cwd)
for label,cwd,cmd in [('040-mining-test','.',['flutter','test','plugins/flutter_mining/test/','--reporter','expanded']),('041-mining-example-test','plugins/flutter_mining/example',['flutter','test','test/','--reporter','expanded']),('042-jmt-test','packages/n42_jmt_verify',['dart','test']),('043-webview-test','.',['flutter','test','packages/webview_flutter_wkwebview/test/','--concurrency=4','--reporter','expanded']),('044-web3auth-test','.',['flutter','test','test/features/wallet/mpc/web3auth_mpc_provider_test.dart','--reporter','expanded'])]: run(label,cmd,cwd)
config=ROOT/'.dart_tool/package_config.json'; entries={p['name']:p for p in json.loads(config.read_text())['packages']}
paths={name:pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(urllib.parse.urljoin(config.as_uri(),p['rootUri'])).path)).resolve() for name,p in entries.items()}
revision='3cc19c12a7c9bbf2031270acca8e3922730b55a5'
lock=(ROOT/'pubspec.lock').read_text(); block=re.search(r'^  n42_chat:\n(.*?)(?=^  \w+:)',lock,re.M|re.S).group(1)
assert 'source: git' in block and revision in block
assert revision in (ROOT/'pubspec.yaml').read_text()
assert subprocess.check_output(['git','-C',str(paths['n42_chat']),'rev-parse','HEAD'],text=True).strip()==revision
for name,expected in [('audioplayers_darwin','packages/audioplayers_darwin'),('webview_flutter_wkwebview','packages/webview_flutter_wkwebview'),('flutter_mining','plugins/flutter_mining')]: assert paths[name]==ROOT/expected,(name,paths[name])
export=pathlib.Path(tempfile.mkdtemp(prefix='n42-chat-task10-'))
archive=subprocess.check_output(['git','-C',str(paths['n42_chat']),'archive',revision])
subprocess.run(['tar','-x','-C',str(export)],input=archive,check=True)
(OUT/'045-chat-source.json').write_text(json.dumps({'sha':revision,'source':str(paths['n42_chat']),'export':str(export),'method':'git archive exact verified revision; cache read-only','path_overrides':{name:str(paths[name]) for name in ['audioplayers_darwin','webview_flutter_wkwebview','flutter_mining']}},indent=2)+'\n')
run('046-chat-pub-get',['flutter','pub','get'],str(export))
run('047-chat-analyze',['flutter','analyze','--no-fatal-infos'],str(export))
run('048-chat-tests',['sh','-c','ulimit -n 4096; flutter test test/ --concurrency=4 --reporter expanded'],str(export))
run('049-final-root-lock-check',['flutter','pub','get','--enforce-lockfile'])
