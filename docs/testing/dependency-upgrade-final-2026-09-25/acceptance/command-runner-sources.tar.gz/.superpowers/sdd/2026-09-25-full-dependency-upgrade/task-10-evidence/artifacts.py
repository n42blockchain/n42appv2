from run import ROOT,OUT
import pathlib,hashlib,json,subprocess,zipfile,re,tempfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def cmd(args): return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def tracked(p):
 current=cmd(['git','hash-object',p]);head=cmd(['git','rev-parse','26840b378:'+p]);old=cmd(['git','rev-parse','6f9505574:'+p]);assert current==head;assert current!=old
 return {'git_blob':current,'task8_blob_unchanged':True,'different_from_pre_task8':True}
apk=ROOT/'build/app/outputs/flutter-apk/app-debug.apk';android=[]
nm='/Users/jieliu/Library/Android/sdk/ndk/27.1.12297006/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-nm'
with zipfile.ZipFile(apk) as z:
 packaged=[p.split('/')[1] for p in z.namelist() if p.endswith('/libn42_mls.so')]
 assert set(packaged)=={'arm64-v8a','armeabi-v7a','x86_64'},packaged
 for abi in ['arm64-v8a','armeabi-v7a','x86','x86_64']:
  rel=f'android/app/src/main/jniLibs/{abi}/libn42_mls.so';source=ROOT/rel
  merged=ROOT/f'build/app/intermediates/merged_native_libs/debug/mergeDebugNativeLibs/out/lib/{abi}/libn42_mls.so'
  stripped=ROOT/f'build/app/intermediates/stripped_native_libs/debug/stripDebugDebugSymbols/out/lib/{abi}/libn42_mls.so'
  assert source.read_bytes()==merged.read_bytes()
  symbols=cmd([nm,'-D','--defined-only',str(source)])
  c=[x for x in symbols.splitlines() if re.search(r'\bn42_mls_',x)];jni=[x for x in symbols.splitlines() if 'Java_' in x]
  assert len(c)==13 and len(jni)==11
  row={'abi':abi,'source_sha256':sha(source.read_bytes()),'merged_matches_source':True,'jni_symbols':11,'c_symbols':13,'packaged':abi in packaged,**tracked(rel)}
  if abi in packaged:
   b=z.read(f'lib/{abi}/libn42_mls.so');assert b==stripped.read_bytes();row.update(apk_sha256=sha(b),apk_matches_gradle_stripped=True)
  android.append(row)
runner=ROOT/'build/ios/iphoneos/Runner.app/Runner';archive=ROOT/'ios/N42Mls.xcframework/ios-arm64/libn42_mls.a';copied=ROOT/'build/ios/Release-iphoneos/libn42_mls.a'
assert archive.read_bytes()==copied.read_bytes()
globalnm=cmd(['xcrun','nm','-gU',str(runner)]);localnm=cmd(['xcrun','nm','-m',str(runner)])
mls=[x for x in globalnm.splitlines() if re.search(r' T _n42_mls_',x)]
assert len(mls)==12,mls
assert re.search(r' T _sqlite3_key$',globalnm,re.M)
assert '_sqlcipher_exportFunc' in localnm and '_sqlcipher_export_init' in localnm
symbols=mls+[x for x in globalnm.splitlines() if re.search(r' T _sqlite3_key(?:_v2)?$',x)]+[x for x in localnm.splitlines() if '_sqlcipher_exportFunc' in x or '_sqlcipher_export_init' in x]
(OUT/'433-ios-link-symbols.txt').write_text('\n'.join(symbols)+'\n')
result={'android_apk':{'bytes':apk.stat().st_size,'sha256':sha(apk.read_bytes()),'mls':android,'note':'Flutter default APK runtime ABIs are arm64-v8a, armeabi-v7a, x86_64. The fourth x86 input remains rebuilt/tracked/merged but is not packaged by this default Flutter APK command. Gradle strips symbols, so APK library hashes match stripped outputs, not unstripped tracked inputs.'},'ios':{'runner_bytes':runner.stat().st_size,'runner_sha256':sha(runner.read_bytes()),'device_archive_sha256':sha(archive.read_bytes()),'xcode_copied_archive_matches_task8_source':True,'linked_mls_entry_points':len(mls),'note':'12 operational C entry points are retained by the app linker; the unused version helper is absent from the linked export table. All 13 C entries remain in the input archive per Task8 audit. SQLCipher key and local export functions are present. No device runtime claim.',**tracked('ios/N42Mls.xcframework/ios-arm64/libn42_mls.a')}}
(OUT/'432-final-native-artifacts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
