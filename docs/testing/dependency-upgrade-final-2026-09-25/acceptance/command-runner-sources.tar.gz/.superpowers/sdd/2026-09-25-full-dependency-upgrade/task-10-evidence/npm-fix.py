from run import run
import os
env={'PATH':'/Users/jieliu/.nvm/versions/node/v20.20.0/bin:'+os.environ['PATH']}; cwd='chrome-extension'
run('310-compatible-audit-fix',['npm','audit','fix'],cwd,env)
for label,cmd in [('311-final-ci',['npm','ci']),('312-final-tests',['npm','test']),('313-final-lint',['npm','run','lint']),('314-final-type',['npm','run','type-check']),('315-final-build',['npm','run','build']),('316-final-audit-prod',['npm','audit','--omit=dev','--json']),('317-final-audit-all',['npm','audit','--json'])]: run(label,cmd,cwd,env)
for i,name in enumerate(['vite-plugin-web-extension','web-ext-run','firefox-profile','fx-runner','node-notifier']): run(f'{318+i}-registry-{name}',['npm','view',name,'version','dependencies','engines','--json'],cwd,env)
